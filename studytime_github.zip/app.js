var __assign = (this && this.__assign) || function () {
 __assign = Object.assign || function(t) {
 for (var s, i = 1, n = arguments.length; i < n; i++) {
 s = arguments[i];
 for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
 t[p] = s[p];
 }
 return t;
 };
 return __assign.apply(this, arguments);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
 function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
 return new (P || (P = Promise))(function (resolve, reject) {
 function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
 function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
 function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
 step((generator = generator.apply(thisArg, _arguments || [])).next());
 });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
 var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
 return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
 function verb(n) { return function (v) { return step([n, v]); }; }
 function step(op) {
 if (f) throw new TypeError("Generator is already executing.");
 while (g && (g = 0, op[0] && (_ = 0)), _) try {
 if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
 if (y = 0, t) op = [op[0] & 2, t.value];
 switch (op[0]) {
 case 0: case 1: t = op; break;
 case 4: _.label++; return { value: op[1], done: false };
 case 5: _.label++; y = op[1]; op = [0]; continue;
 case 7: op = _.ops.pop(); _.trys.pop(); continue;
 default:
 if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
 if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
 if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
 if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
 if (t[2]) _.ops.pop();
 _.trys.pop(); continue;
 }
 op = body.call(thisArg, _);
 } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
 if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
 }
};
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
 if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
 if (ar || !(i in from)) {
 if (!ar) ar = Array.prototype.slice.call(from, 0, i);
 ar[i] = from[i];
 }
 }
 return to.concat(ar || Array.prototype.slice.call(from));
};
var genId = function () { return Math.random().toString(36).slice(2, 9); };
var DAYS = ["ראשון", "שני", "שלישי", "רביעי", "חמישי", "שישי"];
var THEMES = { dark: { bg: "#0f1117", card: "#1a1d2e", border: "#2a2d3e", accent: "#6c63ff", text: "#e2e8f0", muted: "#8892a4", green: "#48bb78", red: "#fc8181" }, light: { bg: "#f0f2f8", card: "#ffffff", border: "#b8bdd4", accent: "#5a52e0", text: "#0f1117", muted: "#1f2937", green: "#1a6b3a", red: "#b91c1c" } };
var C = THEMES.dark;
var getGradeInstructions = function (user) {
 if (!(user === null || user === void 0 ? void 0 : user.grade))
 return "";
 var g = user.gradeNum || parseInt(user.grade) || 7;
 var examples = {
 5: "כיתה ה (גיל 10-11): שפה פשוטה מאוד, משפטים קצרים, דוגמאות מחיי היומיום של ילד, אל תשתמש במינוח אקדמי.",
 6: "כיתה ו (גיל 11-12): שפה פשוטה, הסברים קצרים, דוגמאות קונקרטיות וחיות.",
 7: "כיתה ז (גיל 12-13): שפה ברורה, הסברים בינוניים, ניתן להשתמש במינוח בסיסי.",
 8: "כיתה ח (גיל 13-14): שפה תקנית, הסברים עם פרטים, ניתן להשתמש במינוח מקצועי בסיסי.",
 9: "כיתה ט (גיל 14-15): שפה תקנית, הסברים מפורטים, מינוח מקצועי.",
 10: "כיתה י (גיל 15-16): שפה מקצועית, הסברים מעמיקים, מינוח ברמת תיכון.",
 11: "כיתה יא (גיל 16-17): רמת בגרות, הסברים מורכבים, ניתוח עמוק.",
 12: "כיתה יב (גיל 17-18): רמת בגרות גבוהה, הסברים מקיפים ומדויקים."
 };
 return examples[g] || ("כיתה " + user.grade + ": התאם שפה ורמת קושי לגיל זה.");
};
var SUPA_URL = "https://ikchbozxjjkqswmaddry.supabase.co";
var SUPA_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlrY2hib3p4amprcXN3bWFkZHJ5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzI2MTU4NzEsImV4cCI6MjA4ODE5MTg3MX0.o8lHHulY8zjmxCVnjNdwlxH1-jNHYd1FknHF0Rj_AMs";
var GROQ_KEY = "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";
var callAI = function (_a) { return __awaiter(void 0, [_a], void 0, function (_b) {
 var msgs, res, data;
 var _c, _d, _e;
 var _f = _b.system, system = _f === void 0 ? "" : _f, _g = _b.messages, messages = _g === void 0 ? [] : _g, _h = _b.max_tokens, max_tokens = _h === void 0 ? 1000 : _h;
 return __generator(this, function (_j) {
 switch (_j.label) {
 case 0:
 msgs = [];
 if (system)
 msgs.push({ role: "system", content: system });
 messages.forEach(function (m) { return msgs.push({ role: m.role === "model" ? "assistant" : m.role, content: typeof m.content === "string" ? m.content : (m.content || []).map(function (c) { return c.text || ""; }).join("") }); });
 return [4 , fetch("https://api.groq.com/openai/v1/chat/completions", {
 method: "POST",
 headers: { "Content-Type": "application/json", "Authorization": "Bearer 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" },
 body: JSON.stringify({ model: "llama-3.3-70b-versatile", max_tokens: max_tokens, messages: msgs })
 })];
 case 1:
 res = _j.sent();
 return [4 , res.json()];
 case 2:
 data = _j.sent();
 if (data.error)
 throw new Error(data.error.message);
 return [2 , ((_e = (_d = (_c = data.choices) === null || _c === void 0 ? void 0 : _c[0]) === null || _d === void 0 ? void 0 : _d.message) === null || _e === void 0 ? void 0 : _e.content) || ""];
 }
 });
}); };
var supaFetch = function (url, opts) {
 if (opts === void 0) { opts = {}; }
 return fetch(url, opts);
};
var supa = {
 from: function (table) { return ({
 select: function (cols) {
 if (cols === void 0) { cols = "*"; }
 return supaFetch("".concat(SUPA_URL, "/rest/v1/").concat(table, "?select=").concat(cols), { headers: { "apikey": SUPA_KEY, "Authorization": "Bearer " + SUPA_KEY } }).then(function (r) { return r.json(); });
 },
 upsert: function (data) { return fetch("".concat(SUPA_URL, "/rest/v1/").concat(table), { method: "POST", headers: { "apikey": SUPA_KEY, "Authorization": "Bearer " + SUPA_KEY, "Content-Type": "application/json", "Prefer": "resolution=merge-duplicates" }, body: JSON.stringify(data) }).then(function (r) { return r.json(); }); },
 update: function (data) { return ({ eq: function (col, val) { return fetch("".concat(SUPA_URL, "/rest/v1/").concat(table, "?").concat(col, "=eq.").concat(val), { method: "PATCH", headers: { "apikey": SUPA_KEY, "Authorization": "Bearer " + SUPA_KEY, "Content-Type": "application/json" }, body: JSON.stringify(data) }).then(function (r) { return r.json(); }); } }); },
 delete: function () { return ({ eq: function (col, val) { return fetch("".concat(SUPA_URL, "/rest/v1/").concat(table, "?").concat(col, "=eq.").concat(val), { method: "DELETE", headers: { "apikey": SUPA_KEY, "Authorization": "Bearer " + SUPA_KEY } }).then(function (r) { return r.json(); }); } }); },
 eq: function (col, val) { return fetch("".concat(SUPA_URL, "/rest/v1/").concat(table, "?").concat(col, "=eq.").concat(val, "&select=*"), { headers: { "apikey": SUPA_KEY, "Authorization": "Bearer " + SUPA_KEY } }).then(function (r) { return r.json(); }); },
 }); }
};
var syncFromSupabase = function () { return __awaiter(void 0, void 0, void 0, function () {
 var _a, usersArr, classesArr, usersObj_1, classesObj_1, currentUserId_1, myClassesObj_1, e_1;
 return __generator(this, function (_b) {
 switch (_b.label) {
 case 0:
 _b.trys.push([0, 2, , 3]);
 return [4 , Promise.all([
 supa.from("st_users").select("*"),
 supa.from("classes").select("*")
 ])];
 case 1:
 _a = _b.sent(), usersArr = _a[0], classesArr = _a[1];
 if (Array.isArray(usersArr)) {
 usersObj_1 = {};
 usersArr.forEach(function (u) { usersObj_1[u.id] = __assign(__assign({}, u), { personal: u.personal || {}, personalChecks: u.personal_checks || {}, gradesData: u.grades_data || {}, createdAt: u.created_at || u.createdAt, lastLogin: u.last_login || u.lastLogin, gradeNum: u.grade_num || u.gradeNum, role: u.role || 'student' }); });
 _store["users"] = usersObj_1;
 try {
 localStorage.setItem("users", JSON.stringify(usersObj_1));
 }
 catch (_c) { }
 }
 if (Array.isArray(classesArr)) {
 classesObj_1 = {};
 classesArr.forEach(function (c) {
 var members = Array.isArray(c.members) ? c.members : (typeof c.members === "string" ? JSON.parse(c.members || "[]") : []);
 var helpers = (c.helpers && typeof c.helpers === "object" && !Array.isArray(c.helpers)) ? c.helpers : {};
 var teachers = (c.teachers && typeof c.teachers === "object" && !Array.isArray(c.teachers)) ? c.teachers : {};
 classesObj_1[c.id] = __assign(__assign({}, c), { adminId: c.admin_id, boardPhotos: c.board_photos || [], dictationSets: c.dictation_sets || [], members: members, helpers: helpers, teachers: teachers });
 });
 _store["classes"] = classesObj_1; 
 currentUserId_1 = (function () { var _a; try {
 return (_a = JSON.parse(localStorage.getItem("currentUser"))) === null || _a === void 0 ? void 0 : _a.id;
 }
 catch (_b) {
 return null;
 } })();
 myClassesObj_1 = {};
 Object.values(classesObj_1).forEach(function (c) {
 if (!currentUserId_1 || (c.members || []).includes(currentUserId_1))
 myClassesObj_1[c.id] = c;
 });
 try {
 localStorage.setItem("classes", JSON.stringify(myClassesObj_1));
 }
 catch (_d) { }
 }
 return [3 , 3];
 case 2:
 e_1 = _b.sent();
 console.warn("Supabase sync failed, using local data", e_1);
 return [3 , 3];
 case 3: return [2 ];
 }
 });
}); };
var syncUserToSupabase = function (user) { return __awaiter(void 0, void 0, void 0, function () {
 var res, t, e_2;
 return __generator(this, function (_a) {
 switch (_a.label) {
 case 0:
 _a.trys.push([0, 4, , 5]);
 return [4 , fetch("".concat(SUPA_URL, "/rest/v1/st_users"), {
 method: "POST",
 headers: {
 "apikey": SUPA_KEY,
 "Authorization": "Bearer " + SUPA_KEY,
 "Content-Type": "application/json",
 "Prefer": "resolution=merge-duplicates,return=minimal"
 },
 body: JSON.stringify({
 id: user.id, username: user.username, password: user.password,
 role: user.role || "student", grade: user.grade, grade_num: user.gradeNum || null,
 created_at: user.createdAt || null, last_login: user.lastLogin || Date.now(),
 personal: user.personal || {}, personal_checks: user.personalChecks || {},
 grades_data: user.gradesData || {}
 })
 })];
 case 1:
 res = _a.sent();
 if (!!res.ok) return [3 , 3];
 return [4 , res.text()];
 case 2:
 t = _a.sent();
 console.warn("User sync error:", t);
 _a.label = 3;
 case 3: return [3 , 5];
 case 4:
 e_2 = _a.sent();
 console.warn("User sync failed", e_2);
 return [3 , 5];
 case 5: return [2 ];
 }
 });
}); };
var syncClassToSupabase = function (cls) { return __awaiter(void 0, void 0, void 0, function () {
 var res, t, e_3;
 return __generator(this, function (_a) {
 switch (_a.label) {
 case 0:
 _a.trys.push([0, 4, , 5]);
 return [4 , fetch("".concat(SUPA_URL, "/rest/v1/classes"), {
 method: "POST",
 headers: {
 "apikey": SUPA_KEY,
 "Authorization": "Bearer " + SUPA_KEY,
 "Content-Type": "application/json",
 "Prefer": "resolution=merge-duplicates,return=minimal"
 },
 body: JSON.stringify({
 id: cls.id, name: cls.name, code: cls.code,
 admin_id: cls.adminId, members: cls.members || [],
 helpers: cls.helpers || {}, teachers: cls.teachers || {},
 homework: cls.homework || [], works: cls.works || [],
 tests: cls.tests || [], schedule: cls.schedule || {},
 dictation_sets: cls.dictationSets || [],
 board_photos: cls.boardPhotos || [], created_at: cls.createdAt || null
 })
 })];
 case 1:
 res = _a.sent();
 if (!!res.ok) return [3 , 3];
 return [4 , res.text()];
 case 2:
 t = _a.sent();
 console.warn("Class sync error:", t);
 _a.label = 3;
 case 3: return [3 , 5];
 case 4:
 e_3 = _a.sent();
 console.warn("Class sync failed", e_3);
 return [3 , 5];
 case 5: return [2 ];
 }
 });
}); };
var _store = {};
var ls = {
 get: function (k) {
 if (k in _store)
 return _store[k];
 try {
 var v = JSON.parse(localStorage.getItem(k));
 if (v !== null)
 _store[k] = v;
 return v || null;
 }
 catch (_a) {
 return null;
 }
 },
 set: function (k, v) {
 _store[k] = v;
 try {
 localStorage.setItem(k, JSON.stringify(v));
 }
 catch (_a) { }
 }
};
function App() {
 var _a = React.useState(null), user = _a[0], setUser = _a[1];
 var _b = React.useState("login"), page = _b[0], setPage = _b[1];
 var _c = React.useState("home"), mode = _c[0], setMode = _c[1];
 var _d = React.useState("homework"), tab = _d[0], setTab = _d[1];
 var _e = React.useState(true), syncing = _e[0], setSyncing = _e[1];
 React.useEffect(function () {
 var syncTimeout = setTimeout(function () { return setSyncing(false); }, 5000); 
 syncFromSupabase().finally(function () { clearTimeout(syncTimeout); setSyncing(false); });
 }, []);
 var _f = React.useState(null), classView = _f[0], setClassView = _f[1];
 var _g = React.useState([]), classes = _g[0], setClasses = _g[1];
 var _h = React.useState(false), showUserMenu = _h[0], setShowUserMenu = _h[1];
 var _j = React.useState(false), showAccountModal = _j[0], setShowAccountModal = _j[1];
 var _k = React.useState(ls.get("theme") || "dark"), theme = _k[0], setTheme = _k[1];
 C = THEMES[theme] || THEMES.dark;
 React.useEffect(function () {
 document.body.style.background = C.bg;
 document.body.style.color = C.text;
 var styleEl = document.getElementById("studytime-theme");
 if (!styleEl) {
 styleEl = document.createElement("style");
 styleEl.id = "studytime-theme";
 document.head.appendChild(styleEl);
 }
 if (theme === "light") {
 styleEl.textContent = "\n * { color: inherit; }\n input, select, textarea { color: #111827 !important; background-color: #f9fafb !important; border-color: #c5cade !important; }\n button { color: inherit !important; }\n ";
 }
 else {
 styleEl.textContent = "";
 }
 }, [theme]);
 var _l = React.useState(ls.get("lang") || "he"), lang = _l[0], setLang = _l[1];
 var userMenuRef = React.useRef(null);
 React.useEffect(function () {
 var handleClick = function (e) { if (userMenuRef.current && !userMenuRef.current.contains(e.target))
 setShowUserMenu(false); };
 document.addEventListener("mousedown", handleClick);
 return function () { return document.removeEventListener("mousedown", handleClick); };
 }, []);
 React.useEffect(function () {
 if (syncing)
 return;
 if (!ls.get("users"))
 ls.set("users", {});
 if (!ls.get("classes"))
 ls.set("classes", {});
 var saved = ls.get("currentUser");
 if (saved) {
 var freshUsers = ls.get("users") || {};
 var freshUser = freshUsers[saved.id] || saved;
 loadUser(freshUser);
 }
 else
 setPage("login");
 }, [syncing]);
 var loadUser = function (u) {
 if (!u)
 return;
 var safeU = __assign(__assign({}, u), { personal: u.personal || { homework: [], works: [], tests: [], schedule: {} }, classChecks: u.classChecks || {}, gradesData: u.gradesData || {}, role: u.role || "student" });
 var all = ls.get("classes") || {};
 var mine = Object.values(all).filter(function (c) { return (c.members || []).includes(safeU.id); });
 var seen = new Set();
 var uniqueMine = mine.filter(function (c) { if (seen.has(c.id))
 return false; seen.add(c.id); return true; });
 var users = ls.get("users") || {};
 if (users[safeU.id]) {
 users[safeU.id].lastLogin = Date.now();
 ls.set("users", users);
 syncUserToSupabase(users[safeU.id]);
 }
 setUser(safeU);
 setClasses(uniqueMine);
 setPage("app");
 };
 var refreshClasses = function (uid) {
 if (!uid)
 return;
 var all = ls.get("classes") || {};
 var mine = Object.values(all).filter(function (c) { return (c.members || []).includes(uid); });
 var seen = new Set();
 var unique = mine.filter(function (c) { if (seen.has(c.id))
 return false; seen.add(c.id); return true; });
 setClasses(unique);
 };
 var saveUser = function (u) { setUser(u); var users = ls.get("users") || {}; users[u.id] = u; ls.set("users", users); ls.set("currentUser", u); syncUserToSupabase(u); };
 var myClasses = classes;
 if (syncing)
 return (React.createElement("div", { style: { display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", height: "100vh", background: C.bg, gap: "1rem" } },
 React.createElement("div", { style: { fontSize: "2.5rem" } }, "\uD83D\uDCDA"),
 React.createElement("div", { style: { fontWeight: 700, color: C.text, fontSize: "1.1rem" } }, "StudyTime"),
 React.createElement("div", { style: { color: C.muted, fontSize: "0.85rem" } }, "\u05DE\u05E1\u05E0\u05DB\u05E8\u05DF \u05E0\u05EA\u05D5\u05E0\u05D9\u05DD..."),
 React.createElement("div", { style: { width: "40px", height: "4px", background: C.border, borderRadius: "4px", overflow: "hidden" } },
 React.createElement("div", { style: { width: "40%", height: "100%", background: C.accent, borderRadius: "4px", animation: "slide 1s infinite" } }))));
 if (page === "login")
 return React.createElement(Login, { onLogin: function (u) { ls.set("currentUser", u); loadUser(u); }, onRegister: function () { return setPage("register"); }, onForgot: function () { return setPage("forgot"); } });
 if (page === "register")
 return React.createElement(Register, { onRegister: function (u) { ls.set("currentUser", u); loadUser(u); }, onBack: function () { return setPage("login"); } });
 if (page === "forgot")
 return React.createElement(ForgotPassword, { onBack: function () { return setPage("login"); } });
 if (!user)
 return null;
 var cv = classView ? (myClasses.find(function (c) { return c.id === classView; }) || (_store["classes"] && _store["classes"][classView]) || null) : null;
 return (React.createElement("div", { style: { minHeight: "100vh", background: C.bg, color: C.text, direction: "rtl" } },
 React.createElement("header", { style: { background: C.card, borderBottom: "1px solid ".concat(C.border), padding: "0.65rem 1rem", display: "flex", alignItems: "center", gap: "0.75rem", position: "sticky", top: 0, zIndex: 50 } },
 React.createElement("span", { onClick: function () { setMode("home"); setClassView(null); }, style: { fontWeight: 800, fontSize: "1.1rem", color: C.accent, cursor: "pointer" } }, "\uD83D\uDCDA StudyTime"),
 React.createElement("div", { style: { flex: 1 } }),
 React.createElement("span", { style: { fontSize: "0.78rem", color: C.muted } },
 "\u05E9\u05DC\u05D5\u05DD, ",
 user.username),
 React.createElement("div", { ref: userMenuRef, style: { position: "relative" } },
 React.createElement("button", { onClick: function () { return setShowUserMenu(function (v) { return !v; }); }, style: { background: showUserMenu ? "".concat(C.accent, "22") : "transparent", border: "1px solid ".concat(showUserMenu ? C.accent : C.border), color: showUserMenu ? C.accent : C.muted, padding: "0.3rem 0.55rem", borderRadius: "8px", fontSize: "1rem", cursor: "pointer", lineHeight: 1 } }, "\uD83D\uDC64"),
 showUserMenu && (React.createElement("div", { style: { position: "absolute", top: "calc(100% + 8px)", left: 0, minWidth: "190px", background: C.card, border: "1px solid ".concat(C.border), borderRadius: "12px", boxShadow: "0 8px 24px #0008", zIndex: 200, overflow: "hidden", display: "flex", flexDirection: "column" } },
 React.createElement("button", { onClick: function () { setShowAccountModal(true); setShowUserMenu(false); }, style: { background: "transparent", border: "none", color: C.text, padding: "0.7rem 1rem", fontSize: "0.88rem", cursor: "pointer", textAlign: "right", display: "flex", alignItems: "center", gap: "0.5rem", borderBottom: "1px solid ".concat(C.border) } }, "\u2699\uFE0F \u05E9\u05D9\u05E0\u05D5\u05D9 \u05E4\u05E8\u05D8\u05D9 \u05D7\u05E9\u05D1\u05D5\u05DF"),
 React.createElement("div", { style: { padding: "0.6rem 1rem", borderBottom: "1px solid ".concat(C.border) } },
 React.createElement("div", { style: { fontSize: "0.75rem", color: C.muted, marginBottom: "0.4rem" } }, "\uD83C\uDFA8 \u05E2\u05E8\u05DB\u05EA \u05E0\u05D5\u05E9\u05D0"),
 React.createElement("div", { style: { display: "flex", gap: "0.4rem" } },
 React.createElement("button", { onClick: function () { setTheme("dark"); ls.set("theme", "dark"); }, style: { flex: 1, padding: "0.3rem", borderRadius: "8px", border: "1px solid " + (theme === "dark" ? C.accent : C.border), background: theme === "dark" ? C.accent + "33" : "transparent", color: theme === "dark" ? C.accent : C.muted, fontSize: "0.78rem", fontWeight: theme === "dark" ? 700 : 400, cursor: "pointer" } }, "\uD83C\uDF19 \u05DB\u05D4\u05D4"),
 React.createElement("button", { onClick: function () { setTheme("light"); ls.set("theme", "light"); }, style: { flex: 1, padding: "0.3rem", borderRadius: "8px", border: "1px solid " + (theme === "light" ? C.accent : C.border), background: theme === "light" ? C.accent + "33" : "transparent", color: theme === "light" ? C.accent : C.muted, fontSize: "0.78rem", fontWeight: theme === "light" ? 700 : 400, cursor: "pointer" } }, "\u2600\uFE0F \u05D1\u05D4\u05D9\u05E8"))),
 React.createElement("button", { onClick: function () { ls.set("currentUser", null); setUser(null); setPage("login"); setMode("home"); setClassView(null); setShowUserMenu(false); }, style: { background: "transparent", border: "none", color: "#fc8181", padding: "0.7rem 1rem", fontSize: "0.88rem", cursor: "pointer", textAlign: "right", display: "flex", alignItems: "center", gap: "0.5rem" } }, "\uD83D\uDEAA \u05D9\u05E6\u05D9\u05D0\u05D4")))),
 showAccountModal && React.createElement(AccountModal, { user: user, onSave: function (u) { saveUser(u); setShowAccountModal(false); }, onClose: function () { return setShowAccountModal(false); }, theme: theme, setTheme: function (t) { setTheme(t); ls.set("theme", t); } })),
 React.createElement("nav", { style: { background: C.card, borderBottom: "1px solid ".concat(C.border), padding: "0 1rem", display: "flex", gap: "0.1rem", overflowX: "auto" } }, [["home", "🏠 ראשי"], ["personal", "👤 אישי"], ["classes", "🏫 כיתות"], ["study", "📖 למידה"]].map(function (_a) {
 var m = _a[0], lbl = _a[1];
 return (React.createElement("button", { key: m, onClick: function () { setMode(m); if (m === "classes")
 refreshClasses(user === null || user === void 0 ? void 0 : user.id); if (m !== "classes")
 setClassView(null); }, style: { background: "transparent", border: "none", color: mode === m ? C.accent : C.muted, padding: "0.65rem 0.9rem", fontSize: "0.85rem", fontWeight: mode === m ? 700 : 400, cursor: "pointer", borderBottom: mode === m ? "2px solid ".concat(C.accent) : "2px solid transparent", whiteSpace: "nowrap" } }, lbl));
 })),
 React.createElement("main", { style: { padding: "1rem", maxWidth: "700px", margin: "0 auto" } },
 React.createElement("div", { style: { display: mode === "home" ? "block" : "none" } },
 React.createElement(Dashboard, { user: user, myClasses: myClasses, setMode: function (m) { setMode(m); }, mode: mode })),
 React.createElement("div", { style: { display: mode === "personal" ? "block" : "none" } },
 React.createElement(PersonalMode, { user: user, saveUser: saveUser, tab: tab, setTab: setTab })),
 React.createElement("div", { style: { display: mode === "classes" ? "block" : "none" } },
 React.createElement(ClassesMode, { user: user, saveUser: saveUser, myClasses: classes, setMyClasses: setClasses, refreshClasses: function () { return refreshClasses(user === null || user === void 0 ? void 0 : user.id); }, tab: tab, setTab: setTab, classView: classView, setClassView: setClassView })),
 React.createElement("div", { style: { display: mode === "study" ? "block" : "none" } },
 React.createElement(StudyMode, { user: user, myClasses: myClasses })))));
}
function AdminPanel(_a) {
 var _b, _c;
 var onClose = _a.onClose;
 var _d = React.useState("users"), tab = _d[0], setTab = _d[1];
 var _e = React.useState(function () { return Object.values(ls.get("users") || {}); }), allUsers = _e[0], setAllUsers = _e[1];
 var _f = React.useState(function () { return Object.values(ls.get("classes") || {}); }), allClasses = _f[0], setAllClasses = _f[1];
 var _g = React.useState(""), search = _g[0], setSearch = _g[1];
 var _h = React.useState(null), selected = _h[0], setSelected = _h[1];
 var _j = React.useState(""), editPass = _j[0], setEditPass = _j[1];
 var _k = React.useState(""), passCode = _k[0], setPassCode = _k[1];
 var _l = React.useState(""), passErr = _l[0], setPassErr = _l[1];
 var _m = React.useState(""), passSuccess = _m[0], setPassSuccess = _m[1];
 var _o = React.useState(false), showPassInput = _o[0], setShowPassInput = _o[1];
 var _p = React.useState(false), showPassword = _p[0], setShowPassword = _p[1];
 var _q = React.useState(""), editUsername = _q[0], setEditUsername = _q[1];
 var _r = React.useState(false), showEditUsername = _r[0], setShowEditUsername = _r[1];
 var _s = React.useState(""), editGrade = _s[0], setEditGrade = _s[1];
 var _t = React.useState(false), showEditGrade = _t[0], setShowEditGrade = _t[1];
 var _u = React.useState(""), editFieldErr = _u[0], setEditFieldErr = _u[1];
 var _v = React.useState(false), showMasterChange = _v[0], setShowMasterChange = _v[1];
 var _w = React.useState(false), showLoginHistory = _w[0], setShowLoginHistory = _w[1];
 var _x = React.useState(""), masterOldCode = _x[0], setMasterOldCode = _x[1];
 var _y = React.useState(""), masterNewCode = _y[0], setMasterNewCode = _y[1];
 var _z = React.useState(""), masterErr = _z[0], setMasterErr = _z[1];
 var _0 = React.useState(""), masterSuccess = _0[0], setMasterSuccess = _0[1];
 var _1 = React.useState(null), confirmModal = _1[0], setConfirmModal = _1[1]; 
 var _2 = React.useState(null), adminSelectedCls = _2[0], setAdminSelectedCls = _2[1];
 var _3 = React.useState(""), confirmCode = _3[0], setConfirmCode = _3[1];
 var _4 = React.useState(""), confirmErr = _4[0], setConfirmErr = _4[1];
 var askCode = function (msg, onConfirm) { setConfirmModal({ msg: msg, onConfirm: onConfirm }); setConfirmCode(""); setConfirmErr(""); };
 var getMasterCode = function () { return ls.get("adminMasterCode") || "040413"; };
 var submitConfirm = function () {
 if (confirmCode !== getMasterCode()) {
 setConfirmErr("קוד שגוי");
 return;
 }
 var action = confirmModal.onConfirm;
 setConfirmModal(null);
 setConfirmCode("");
 setConfirmErr("");
 action();
 };
 var refresh = function () {
 setAllUsers(__spreadArray([], Object.values(ls.get("users") || {}), true));
 setAllClasses(__spreadArray([], Object.values(ls.get("classes") || {}), true));
 setSelected(null);
 };
 var deleteUser = function (id) {
 var all = ls.get("users") || {};
 delete all[id];
 ls.set("users", all);
 supa.from("st_users").delete().eq("id", id);
 setSelected(null);
 refresh();
 };
 var changePassword = function () {
 if (passCode !== getMasterCode()) {
 setPassErr("קוד שגוי");
 setTimeout(function () { return setPassErr(""); }, 2000);
 return;
 }
 if (editPass.length < 4) {
 setPassErr("סיסמא חייבת להיות לפחות 4 תווים");
 return;
 }
 var all = ls.get("users") || {};
 all[selected.id] = __assign(__assign({}, all[selected.id]), { password: editPass });
 ls.set("users", all);
 setSelected(__assign(__assign({}, selected), { password: editPass }));
 refresh();
 setEditPass("");
 setPassCode("");
 setShowPassInput(false);
 setPassSuccess("סיסמא עודכנה ✓");
 setTimeout(function () { return setPassSuccess(""); }, 2500);
 };
 var saveUsername = function () {
 var trimmed = editUsername.trim();
 if (!trimmed) {
 setEditFieldErr("שם משתמש לא יכול להיות ריק");
 return;
 }
 var all = ls.get("users") || {};
 var taken = Object.values(all).find(function (u) { return u.username === trimmed && u.id !== selected.id; });
 if (taken) {
 setEditFieldErr("שם משתמש תפוס");
 return;
 }
 all[selected.id] = __assign(__assign({}, all[selected.id]), { username: trimmed });
 ls.set("users", all);
 syncUserToSupabase(all[selected.id]);
 setSelected(__assign(__assign({}, selected), { username: trimmed }));
 setAllUsers(__spreadArray([], Object.values(all), true));
 setShowEditUsername(false);
 setEditUsername("");
 setEditFieldErr("");
 };
 var saveGrade = function () {
 if (!editGrade) {
 setEditFieldErr("בחר כיתה");
 return;
 }
 var gradeMap = { "ה": 5, "ו": 6, "ז": 7, "ח": 8, "ט": 9, "י": 10, "יא": 11, "יב": 12 };
 var all = ls.get("users") || {};
 all[selected.id] = __assign(__assign({}, all[selected.id]), { grade: editGrade, gradeNum: gradeMap[editGrade] || null });
 ls.set("users", all);
 syncUserToSupabase(all[selected.id]);
 setSelected(__assign(__assign({}, selected), { grade: editGrade, gradeNum: gradeMap[editGrade] || null }));
 setAllUsers(__spreadArray([], Object.values(all), true));
 setShowEditGrade(false);
 setEditGrade("");
 setEditFieldErr("");
 };
 var changeMasterCode = function () {
 if (masterOldCode !== getMasterCode()) {
 setMasterErr("קוד נוכחי שגוי");
 setTimeout(function () { return setMasterErr(""); }, 2000);
 return;
 }
 if (masterNewCode.length < 4) {
 setMasterErr("קוד חדש חייב להיות לפחות 4 תווים");
 return;
 }
 ls.set("adminMasterCode", masterNewCode);
 setMasterSuccess("הקוד עודכן ✓");
 setMasterOldCode("");
 setMasterNewCode("");
 setTimeout(function () { setMasterSuccess(""); setShowMasterChange(false); }, 2000);
 };
 var setClassAdmin = function (cls, newAdminId) {
 var all = ls.get("classes") || {};
 all[cls.id] = __assign(__assign({}, cls), { adminId: newAdminId });
 ls.set("classes", all);
 syncClassToSupabase(all[cls.id]);
 refresh();
 };
 var filteredUsers = allUsers.filter(function (u) { var _a; return ((_a = u.username) === null || _a === void 0 ? void 0 : _a.toLowerCase().includes(search.toLowerCase())) || (u.grade || "").includes(search); });
 var filteredClasses = allClasses.filter(function (c) { var _a; return (_a = c.name) === null || _a === void 0 ? void 0 : _a.toLowerCase().includes(search.toLowerCase()); });
 return (React.createElement("div", { style: { position: "fixed", inset: 0, background: C.bg, zIndex: 700, display: "flex", flexDirection: "column", overflow: "hidden" } },
 React.createElement("div", { style: { background: C.card, borderBottom: "1px solid ".concat(C.border), padding: "0.85rem 1.25rem", display: "flex", alignItems: "center", gap: "0.75rem", flexShrink: 0, flexWrap: "wrap" } },
 React.createElement("div", { style: { flex: 1 } },
 React.createElement("div", { style: { fontSize: "1.1rem", fontWeight: 800, color: C.text } },
 "\uD83D\uDEE1\uFE0F \u05DC\u05D5\u05D7 \u05E0\u05D9\u05D4\u05D5\u05DC ",
 React.createElement("span", { style: { fontSize: "0.75rem", color: C.muted, fontWeight: 400 } },
 "(",
 allUsers.length,
 " \u05DE\u05E9\u05EA\u05DE\u05E9\u05D9\u05DD \u00B7 ",
 allClasses.length,
 " \u05DB\u05D9\u05EA\u05D5\u05EA)")),
 (function () { var locked = ls.get("adminLockLog"); if (!locked)
 return null; var t = new Date(locked.time).toLocaleString("he-IL"); return React.createElement("div", { style: { fontSize: "0.72rem", color: "#fc8181", marginTop: "0.15rem" } },
 "\u26A0\uFE0F ",
 locked.attempts,
 " \u05E0\u05D9\u05E1\u05D9\u05D5\u05E0\u05D5\u05EA \u05DB\u05E0\u05D9\u05E1\u05D4 \u05E9\u05D2\u05D5\u05D9\u05D9\u05DD \u2014 ",
 t); })()),
 React.createElement("button", { onClick: function () { return setShowLoginHistory(function (v) { return !v; }); }, style: { background: showLoginHistory ? C.accent + "22" : "transparent", border: "1px solid ".concat(showLoginHistory ? C.accent : C.border), color: showLoginHistory ? C.accent : C.muted, padding: "0.35rem 0.7rem", borderRadius: "8px", fontSize: "0.8rem", cursor: "pointer" } }, "\uD83D\uDCCB \u05D4\u05D9\u05E1\u05D8\u05D5\u05E8\u05D9\u05D4"),
 React.createElement("button", { onClick: function () { return setShowMasterChange(function (v) { return !v; }); }, style: { background: "transparent", border: "1px solid ".concat(C.border), color: C.muted, padding: "0.35rem 0.65rem", borderRadius: "8px", fontSize: "0.78rem", cursor: "pointer" } }, "\uD83D\uDD10 \u05E9\u05E0\u05D4 \u05E7\u05D5\u05D3"),
 React.createElement("button", { onClick: function () { return askCode("ניקוי כל הנתונים — פעולה בלתי הפיכה!", function () { ls.set("users", {}); ls.set("classes", {}); ls.set("currentUser", null); window.location.reload(); }); }, style: { background: "#fc818122", border: "1px solid #fc8181", color: "#fc8181", padding: "0.35rem 0.65rem", borderRadius: "8px", fontSize: "0.78rem", cursor: "pointer" } }, "\uD83D\uDDD1\uFE0F \u05E0\u05E7\u05D4 \u05D4\u05DB\u05DC"),
 React.createElement("button", { onClick: onClose, style: { background: "transparent", border: "1px solid ".concat(C.border), color: C.muted, padding: "0.35rem 0.75rem", borderRadius: "8px", fontSize: "0.85rem", cursor: "pointer" } }, "\u2190 \u05D9\u05E6\u05D9\u05D0\u05D4")),
 showMasterChange && (React.createElement("div", { style: { background: C.card, borderBottom: "1px solid ".concat(C.accent), padding: "0.85rem 1.25rem", display: "flex", gap: "0.6rem", alignItems: "center", flexWrap: "wrap" } },
 React.createElement("span", { style: { fontSize: "0.82rem", color: C.muted, fontWeight: 600 } }, "\uD83D\uDD10 \u05E9\u05D9\u05E0\u05D5\u05D9 \u05E7\u05D5\u05D3 \u05D2\u05D9\u05E9\u05D4:"),
 React.createElement("input", { type: "password", value: masterOldCode, onChange: function (e) { return setMasterOldCode(e.target.value); }, placeholder: "\u05E7\u05D5\u05D3 \u05E0\u05D5\u05DB\u05D7\u05D9", style: { background: C.bg, border: "1px solid ".concat(C.border), color: C.text, padding: "0.4rem 0.65rem", borderRadius: "7px", fontSize: "0.85rem", outline: "none", width: "120px" } }),
 React.createElement("input", { type: "password", value: masterNewCode, onChange: function (e) { return setMasterNewCode(e.target.value); }, placeholder: "\u05E7\u05D5\u05D3 \u05D7\u05D3\u05E9", onKeyDown: function (e) { return e.key === "Enter" && changeMasterCode(); }, style: { background: C.bg, border: "1px solid ".concat(C.border), color: C.text, padding: "0.4rem 0.65rem", borderRadius: "7px", fontSize: "0.85rem", outline: "none", width: "120px" } }),
 masterErr && React.createElement("span", { style: { color: "#fc8181", fontSize: "0.8rem" } }, masterErr),
 masterSuccess && React.createElement("span", { style: { color: C.green, fontSize: "0.8rem", fontWeight: 600 } }, masterSuccess),
 React.createElement("button", { onClick: changeMasterCode, style: { background: C.accent, color: "#fff", border: "none", padding: "0.4rem 0.9rem", borderRadius: "7px", fontWeight: 700, cursor: "pointer", fontSize: "0.82rem" } }, "\u05E2\u05D3\u05DB\u05DF"),
 React.createElement("button", { onClick: function () { setShowMasterChange(false); setMasterOldCode(""); setMasterNewCode(""); }, style: { background: "transparent", border: "1px solid ".concat(C.border), color: C.muted, padding: "0.4rem 0.65rem", borderRadius: "7px", cursor: "pointer", fontSize: "0.82rem" } }, "\u05D1\u05D9\u05D8\u05D5\u05DC"))),
 confirmModal && (React.createElement("div", { style: { position: "fixed", inset: 0, background: "#0009", zIndex: 800, display: "flex", alignItems: "center", justifyContent: "center" }, onClick: function () { return setConfirmModal(null); } },
 React.createElement("div", { style: { background: C.card, border: "1px solid ".concat(C.border), borderRadius: "16px", padding: "1.5rem", width: "300px", display: "flex", flexDirection: "column", gap: "0.75rem" }, onClick: function (e) { return e.stopPropagation(); } },
 React.createElement("div", { style: { fontWeight: 700, fontSize: "0.95rem", color: C.text } }, "\uD83D\uDD10 \u05D0\u05D9\u05E9\u05D5\u05E8 \u05E4\u05E2\u05D5\u05DC\u05D4"),
 React.createElement("div", { style: { fontSize: "0.85rem", color: C.muted } }, confirmModal.msg),
 React.createElement("input", { autoFocus: true, type: "password", value: confirmCode, onChange: function (e) { return setConfirmCode(e.target.value); }, onKeyDown: function (e) { return e.key === "Enter" && submitConfirm(); }, placeholder: "\u05D4\u05DB\u05E0\u05E1 \u05E7\u05D5\u05D3 \u05D2\u05D9\u05E9\u05D4", style: { background: C.bg, border: "1px solid ".concat(confirmErr ? '#fc8181' : C.border), color: C.text, padding: "0.5rem 0.75rem", borderRadius: "8px", fontSize: "0.9rem", outline: "none" } }),
 confirmErr && React.createElement("div", { style: { color: "#fc8181", fontSize: "0.8rem" } }, confirmErr),
 React.createElement("div", { style: { display: "flex", gap: "0.5rem" } },
 React.createElement("button", { onClick: submitConfirm, style: { flex: 1, background: "#fc8181", color: "#fff", border: "none", padding: "0.55rem", borderRadius: "8px", fontWeight: 700, cursor: "pointer" } }, "\u05D0\u05E9\u05E8"),
 React.createElement("button", { onClick: function () { return setConfirmModal(null); }, style: { background: "transparent", border: "1px solid ".concat(C.border), color: C.muted, padding: "0.55rem 0.9rem", borderRadius: "8px", cursor: "pointer" } }, "\u05D1\u05D9\u05D8\u05D5\u05DC"))))),
 showLoginHistory && (React.createElement("div", { style: { background: C.bg, borderBottom: "1px solid ".concat(C.border), padding: "1rem", flexShrink: 0, maxHeight: "320px", overflowY: "auto" } },
 React.createElement("div", { style: { fontSize: "0.85rem", fontWeight: 700, color: C.text, marginBottom: "0.75rem" } }, "\uD83D\uDCCB \u05D4\u05D9\u05E1\u05D8\u05D5\u05E8\u05D9\u05D9\u05EA \u05DB\u05E0\u05D9\u05E1\u05D5\u05EA \u05DC\u05DC\u05D5\u05D7 \u05D4\u05D0\u05D9\u05E9\u05D9"),
 (function () {
 var users = Object.values(ls.get("users") || {});
 var withLogin = users.filter(function (u) { return u.lastLogin; }).sort(function (a, b) { return b.lastLogin - a.lastLogin; });
 if (withLogin.length === 0)
 return React.createElement("div", { style: { color: C.muted, fontSize: "0.82rem" } }, "\u05D0\u05D9\u05DF \u05E0\u05EA\u05D5\u05E0\u05D9 \u05DB\u05E0\u05D9\u05E1\u05D4 \u05E2\u05D3\u05D9\u05D9\u05DF");
 return (React.createElement("table", { style: { width: "100%", borderCollapse: "collapse", fontSize: "0.8rem" } },
 React.createElement("thead", null,
 React.createElement("tr", { style: { borderBottom: "1px solid ".concat(C.border) } },
 React.createElement("th", { style: { padding: "0.3rem 0.5rem", textAlign: "right", color: C.muted, fontWeight: 600 } }, "\u05DE\u05E9\u05EA\u05DE\u05E9"),
 React.createElement("th", { style: { padding: "0.3rem 0.5rem", textAlign: "right", color: C.muted, fontWeight: 600 } }, "\u05DB\u05D9\u05EA\u05D4"),
 React.createElement("th", { style: { padding: "0.3rem 0.5rem", textAlign: "right", color: C.muted, fontWeight: 600 } }, "\u05EA\u05E4\u05E7\u05D9\u05D3"),
 React.createElement("th", { style: { padding: "0.3rem 0.5rem", textAlign: "right", color: C.muted, fontWeight: 600 } }, "\u05DB\u05E0\u05D9\u05E1\u05D4 \u05D0\u05D7\u05E8\u05D5\u05E0\u05D4"),
 React.createElement("th", { style: { padding: "0.3rem 0.5rem", textAlign: "right", color: C.muted, fontWeight: 600 } }, "\u05DC\u05E4\u05E0\u05D9"))),
 React.createElement("tbody", null, withLogin.map(function (u) {
 var ago = Date.now() - u.lastLogin;
 var mins = Math.floor(ago / 60000);
 var hrs = Math.floor(mins / 60);
 var days = Math.floor(hrs / 24);
 var agoStr = days > 0 ? "\u05DC\u05E4\u05E0\u05D9 ".concat(days, " \u05D9\u05DE\u05D9\u05DD") : hrs > 0 ? "\u05DC\u05E4\u05E0\u05D9 ".concat(hrs, " \u05E9\u05E2\u05D5\u05EA") : mins > 0 ? "\u05DC\u05E4\u05E0\u05D9 ".concat(mins, " \u05D3\u05E7\u05D5\u05EA") : "עכשיו";
 var isRecent = ago < 60 * 60 * 1000; 
 return (React.createElement("tr", { key: u.id, style: { borderBottom: "1px solid ".concat(C.border, "22"), background: isRecent ? C.green + "11" : "transparent" } },
 React.createElement("td", { style: { padding: "0.35rem 0.5rem", fontWeight: 600, color: C.text } },
 React.createElement("span", { style: { marginLeft: "0.4rem" } }, u.role === "admin" ? "👑" : u.role === "helper" ? "🤝" : "👤"),
 u.username,
 isRecent && React.createElement("span", { style: { background: C.green, color: "#fff", fontSize: "0.65rem", padding: "0.1rem 0.35rem", borderRadius: "10px", marginRight: "0.4rem" } }, "\u05E4\u05E2\u05D9\u05DC")),
 React.createElement("td", { style: { padding: "0.35rem 0.5rem", color: C.muted } },
 "\u05DB\u05D9\u05EA\u05D4 ",
 u.grade || "—"),
 React.createElement("td", { style: { padding: "0.35rem 0.5rem", color: u.role === "admin" ? C.accent : C.muted, fontWeight: u.role === "admin" ? 700 : 400 } }, u.role === "admin" ? "מנהל" : u.role === "helper" ? "עוזר" : "תלמיד"),
 React.createElement("td", { style: { padding: "0.35rem 0.5rem", color: C.muted, fontSize: "0.75rem" } }, new Date(u.lastLogin).toLocaleString("he-IL")),
 React.createElement("td", { style: { padding: "0.35rem 0.5rem", color: isRecent ? C.green : C.muted, fontWeight: isRecent ? 600 : 400, fontSize: "0.75rem" } }, agoStr)));
 }))));
 })())),
 React.createElement("div", { style: { display: "flex", borderBottom: "1px solid ".concat(C.border), background: C.card, flexShrink: 0 } }, [["users", "👥 משתמשים"], ["classes", "🏫 כיתות"]].map(function (_a) {
 var id = _a[0], lbl = _a[1];
 return (React.createElement("button", { key: id, onClick: function () { setTab(id); setSelected(null); setSearch(""); }, style: { padding: "0.7rem 1.5rem", border: "none", borderBottom: "2px solid ".concat(tab === id ? C.accent : "transparent"), background: "transparent", color: tab === id ? C.accent : C.muted, fontWeight: tab === id ? 700 : 400, fontSize: "0.9rem", cursor: "pointer" } }, lbl));
 })),
 React.createElement("div", { style: { padding: "0.65rem 1rem", borderBottom: "1px solid ".concat(C.border), flexShrink: 0 } },
 React.createElement("input", { value: search, onChange: function (e) { return setSearch(e.target.value); }, placeholder: "\uD83D\uDD0D \u05D7\u05D9\u05E4\u05D5\u05E9...", style: { width: "100%", background: C.card, border: "1px solid ".concat(C.border), color: C.text, padding: "0.5rem 0.75rem", borderRadius: "8px", fontSize: "0.88rem", outline: "none", boxSizing: "border-box" } })),
 React.createElement("div", { style: { display: "flex", flex: 1, overflow: "hidden" } },
 tab === "users" && (React.createElement(React.Fragment, null,
 React.createElement("div", { style: { flex: selected ? 0.45 : 1, borderLeft: "1px solid ".concat(C.border), overflowY: "auto", transition: "flex 0.2s" } },
 React.createElement("table", { style: { width: "100%", borderCollapse: "collapse" } },
 React.createElement("thead", { style: { position: "sticky", top: 0, background: C.card, zIndex: 1 } },
 React.createElement("tr", { style: { borderBottom: "2px solid ".concat(C.border) } },
 React.createElement("th", { style: { padding: "0.6rem 1rem", textAlign: "right", color: C.muted, fontWeight: 600, fontSize: "0.78rem" } }, "\u05DE\u05E9\u05EA\u05DE\u05E9"),
 React.createElement("th", { style: { padding: "0.6rem 1rem", textAlign: "right", color: C.muted, fontWeight: 600, fontSize: "0.78rem" } }, "\u05DB\u05D9\u05EA\u05D4"),
 React.createElement("th", { style: { padding: "0.6rem 1rem", textAlign: "right", color: C.muted, fontWeight: 600, fontSize: "0.78rem" } }, "\u05EA\u05E4\u05E7\u05D9\u05D3"))),
 React.createElement("tbody", null, filteredUsers.map(function (u) {
 var _a, _b;
 return (React.createElement("tr", { key: u.id, onClick: function () { setSelected((selected === null || selected === void 0 ? void 0 : selected.id) === u.id ? null : u); setShowPassInput(false); setEditPass(""); setPassCode(""); setPassSuccess(""); setShowPassword(false); }, style: { borderBottom: "1px solid ".concat(C.border), cursor: "pointer", background: (selected === null || selected === void 0 ? void 0 : selected.id) === u.id ? C.accent + "18" : "transparent" } },
 React.createElement("td", { style: { padding: "0.7rem 1rem" } },
 React.createElement("div", { style: { display: "flex", alignItems: "center", gap: "0.6rem" } },
 React.createElement("div", { style: { width: "32px", height: "32px", borderRadius: "50%", background: C.accent + "33", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700, color: C.accent, fontSize: "0.85rem", flexShrink: 0 } }, ((_b = (_a = u.username) === null || _a === void 0 ? void 0 : _a[0]) === null || _b === void 0 ? void 0 : _b.toUpperCase()) || "?"),
 React.createElement("span", { style: { fontWeight: 600, fontSize: "0.88rem", color: C.text } }, u.username))),
 React.createElement("td", { style: { padding: "0.7rem 1rem", fontSize: "0.85rem", color: C.muted } }, u.grade || "—"),
 React.createElement("td", { style: { padding: "0.7rem 1rem" } },
 React.createElement("span", { style: { background: u.role === "admin" ? "#f6ad5522" : u.role === "helper" ? "#63b3ed22" : "#6c63ff22", color: u.role === "admin" ? "#f6ad55" : u.role === "helper" ? "#63b3ed" : C.accent, padding: "0.18rem 0.5rem", borderRadius: "20px", fontSize: "0.75rem", fontWeight: 600 } }, u.role === "admin" ? "👑 מנהל" : u.role === "helper" ? "🤝 עוזר" : "🎓 תלמיד"))));
 }))),
 filteredUsers.length === 0 && React.createElement("div", { style: { textAlign: "center", color: C.muted, padding: "3rem" } }, "\u05D0\u05D9\u05DF \u05EA\u05D5\u05E6\u05D0\u05D5\u05EA")),
 selected && (React.createElement("div", { style: { flex: 0.55, overflowY: "auto", padding: "1.25rem", borderRight: "1px solid ".concat(C.border), display: "flex", flexDirection: "column", gap: "0.85rem" } },
 React.createElement("div", { style: { display: "flex", alignItems: "center", gap: "0.75rem" } },
 React.createElement("div", { style: { width: "52px", height: "52px", borderRadius: "50%", background: C.accent + "33", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "1.4rem", fontWeight: 800, color: C.accent } }, ((_c = (_b = selected.username) === null || _b === void 0 ? void 0 : _b[0]) === null || _c === void 0 ? void 0 : _c.toUpperCase()) || "?"),
 React.createElement("div", null,
 React.createElement("div", { style: { fontWeight: 800, fontSize: "1.1rem", color: C.text } }, selected.username),
 React.createElement("div", { style: { fontSize: "0.78rem", color: C.muted } },
 selected.role === "admin" ? "👑 מנהל" : selected.role === "helper" ? "🤝 עוזר" : "🎓 תלמיד",
 " \u00B7 ",
 selected.grade || "ללא כיתה")),
 React.createElement("button", { onClick: function () { return setSelected(null); }, style: { marginRight: "auto", background: "transparent", border: "none", color: C.muted, fontSize: "1.1rem", cursor: "pointer" } }, "\u2715")),
 [
 ["👤 שם משתמש", React.createElement("span", { style: { display: "flex", alignItems: "center", gap: "0.5rem" } },
 selected.username,
 React.createElement("button", { onClick: function () { setShowEditUsername(true); setEditUsername(selected.username); setEditFieldErr(""); setShowEditGrade(false); }, style: { background: C.accent + "22", border: "1px solid ".concat(C.accent), color: C.accent, padding: "0.1rem 0.4rem", borderRadius: "5px", fontSize: "0.75rem", cursor: "pointer" } }, "\u270F\uFE0F"))],
 ["🎓 כיתה", React.createElement("span", { style: { display: "flex", alignItems: "center", gap: "0.5rem" } },
 selected.grade || "לא צוין",
 React.createElement("button", { onClick: function () { setShowEditGrade(true); setEditGrade(selected.grade || ""); setEditFieldErr(""); setShowEditUsername(false); }, style: { background: C.accent + "22", border: "1px solid ".concat(C.accent), color: C.accent, padding: "0.1rem 0.4rem", borderRadius: "5px", fontSize: "0.75rem", cursor: "pointer" } }, "\u270F\uFE0F"))],
 ["🏷️ תפקיד", selected.role === "admin" ? "מנהל" : selected.role === "helper" ? "עוזר" : "תלמיד"],
 ["📅 נרשם", selected.createdAt ? new Date(selected.createdAt).toLocaleDateString("he-IL") : "לא ידוע"],
 ["🕐 כניסה אחרונה", selected.lastLogin ? new Date(selected.lastLogin).toLocaleString("he-IL") : "לא זמין"],
 ].map(function (_a) {
 var lbl = _a[0], val = _a[1];
 return (React.createElement("div", { key: lbl, style: { display: "flex", justifyContent: "space-between", alignItems: "center", background: C.card, border: "1px solid ".concat(C.border), borderRadius: "10px", padding: "0.6rem 0.9rem" } },
 React.createElement("span", { style: { fontSize: "0.8rem", color: C.muted } }, lbl),
 React.createElement("span", { style: { fontSize: "0.88rem", color: C.text, fontWeight: 600 } }, val)));
 }),
 React.createElement("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center", background: C.card, border: "1px solid ".concat(C.border), borderRadius: "10px", padding: "0.6rem 0.9rem" } },
 React.createElement("span", { style: { fontSize: "0.8rem", color: C.muted } }, "\uD83D\uDD11 \u05E1\u05D9\u05E1\u05DE\u05D0"),
 React.createElement("div", { style: { display: "flex", alignItems: "center", gap: "0.5rem" } },
 React.createElement("span", { style: { fontSize: "0.88rem", color: C.text, fontWeight: 600, fontFamily: "monospace" } }, showPassword ? selected.password : "••••••••"),
 React.createElement("button", { onClick: function () { return setShowPassword(function (v) { return !v; }); }, style: { background: "transparent", border: "none", cursor: "pointer", fontSize: "1rem", color: C.muted, padding: 0, lineHeight: 1 } }, showPassword ? "🙈" : "👁️"))),
 passSuccess && React.createElement("div", { style: { background: "#48bb7822", border: "1px solid #48bb78", borderRadius: "10px", padding: "0.5rem 0.9rem", color: "#48bb78", fontSize: "0.85rem", textAlign: "center", fontWeight: 600 } }, passSuccess),
 showEditUsername && (React.createElement("div", { style: { background: C.bg, border: "1px solid ".concat(C.accent), borderRadius: "10px", padding: "0.75rem", marginBottom: "0.75rem" } },
 React.createElement("div", { style: { fontSize: "0.85rem", fontWeight: 600, marginBottom: "0.5rem", color: C.accent } }, "\u270F\uFE0F \u05E9\u05D9\u05E0\u05D5\u05D9 \u05E9\u05DD \u05DE\u05E9\u05EA\u05DE\u05E9"),
 React.createElement("input", { value: editUsername, onChange: function (e) { return setEditUsername(e.target.value); }, onKeyDown: function (e) { return e.key === "Enter" && saveUsername(); }, style: { width: "100%", background: C.card, border: "1px solid ".concat(C.border), color: C.text, padding: "0.5rem 0.7rem", borderRadius: "8px", fontSize: "0.88rem", outline: "none", marginBottom: "0.5rem" }, placeholder: "\u05E9\u05DD \u05DE\u05E9\u05EA\u05DE\u05E9 \u05D7\u05D3\u05E9" }),
 editFieldErr && React.createElement("div", { style: { color: "#fc8181", fontSize: "0.8rem", marginBottom: "0.4rem" } }, editFieldErr),
 React.createElement("div", { style: { display: "flex", gap: "0.5rem" } },
 React.createElement("button", { onClick: saveUsername, style: { flex: 1, background: C.accent, color: "#fff", border: "none", padding: "0.5rem", borderRadius: "8px", fontWeight: 700, cursor: "pointer", fontSize: "0.85rem" } }, "\u05E9\u05DE\u05D5\u05E8"),
 React.createElement("button", { onClick: function () { setShowEditUsername(false); setEditFieldErr(""); }, style: { background: "transparent", border: "1px solid ".concat(C.border), color: C.muted, padding: "0.5rem 0.75rem", borderRadius: "8px", cursor: "pointer", fontSize: "0.85rem" } }, "\u05D1\u05D9\u05D8\u05D5\u05DC")))),
 showEditGrade && (React.createElement("div", { style: { background: C.bg, border: "1px solid ".concat(C.accent), borderRadius: "10px", padding: "0.75rem", marginBottom: "0.75rem" } },
 React.createElement("div", { style: { fontSize: "0.85rem", fontWeight: 600, marginBottom: "0.5rem", color: C.accent } }, "\u270F\uFE0F \u05E9\u05D9\u05E0\u05D5\u05D9 \u05DB\u05D9\u05EA\u05D4"),
 React.createElement("select", { value: editGrade, onChange: function (e) { return setEditGrade(e.target.value); }, style: { width: "100%", background: C.card, border: "1px solid ".concat(C.border), color: C.text, padding: "0.5rem 0.7rem", borderRadius: "8px", fontSize: "0.88rem", outline: "none", marginBottom: "0.5rem" } },
 React.createElement("option", { value: "" }, "\u05D1\u05D7\u05E8 \u05DB\u05D9\u05EA\u05D4"),
 ["ה", "ו", "ז", "ח", "ט", "י", "יא", "יב"].map(function (g) { return React.createElement("option", { key: g, value: g },
 "\u05DB\u05D9\u05EA\u05D4 ",
 g); })),
 editFieldErr && React.createElement("div", { style: { color: "#fc8181", fontSize: "0.8rem", marginBottom: "0.4rem" } }, editFieldErr),
 React.createElement("div", { style: { display: "flex", gap: "0.5rem" } },
 React.createElement("button", { onClick: saveGrade, style: { flex: 1, background: C.accent, color: "#fff", border: "none", padding: "0.5rem", borderRadius: "8px", fontWeight: 700, cursor: "pointer", fontSize: "0.85rem" } }, "\u05E9\u05DE\u05D5\u05E8"),
 React.createElement("button", { onClick: function () { setShowEditGrade(false); setEditFieldErr(""); }, style: { background: "transparent", border: "1px solid ".concat(C.border), color: C.muted, padding: "0.5rem 0.75rem", borderRadius: "8px", cursor: "pointer", fontSize: "0.85rem" } }, "\u05D1\u05D9\u05D8\u05D5\u05DC")))),
 !showPassInput ? (React.createElement("button", { onClick: function () { return setShowPassInput(true); }, style: { background: C.accent + "22", border: "1px solid ".concat(C.accent), color: C.accent, padding: "0.6rem", borderRadius: "10px", fontSize: "0.88rem", fontWeight: 700, cursor: "pointer" } }, "\uD83D\uDD11 \u05E9\u05E0\u05D4 \u05E1\u05D9\u05E1\u05DE\u05D0")) : (React.createElement("div", { style: { background: C.card, border: "1px solid ".concat(C.border), borderRadius: "12px", padding: "0.85rem", display: "flex", flexDirection: "column", gap: "0.55rem" } },
 React.createElement("div", { style: { fontSize: "0.8rem", color: C.muted, fontWeight: 600 } }, "\u05E9\u05D9\u05E0\u05D5\u05D9 \u05E1\u05D9\u05E1\u05DE\u05D0"),
 React.createElement("input", { type: "password", value: editPass, onChange: function (e) { return setEditPass(e.target.value); }, placeholder: "\u05E1\u05D9\u05E1\u05DE\u05D0 \u05D7\u05D3\u05E9\u05D4", style: { background: C.bg, border: "1px solid ".concat(C.border), color: C.text, padding: "0.5rem 0.7rem", borderRadius: "8px", fontSize: "0.88rem", outline: "none" } }),
 React.createElement("input", { type: "password", value: passCode, onChange: function (e) { return setPassCode(e.target.value); }, placeholder: "\u05E7\u05D5\u05D3 \u05D0\u05D9\u05E9\u05D5\u05E8", onKeyDown: function (e) { return e.key === "Enter" && changePassword(); }, style: { background: C.bg, border: "1px solid ".concat(C.border), color: C.text, padding: "0.5rem 0.7rem", borderRadius: "8px", fontSize: "0.88rem", outline: "none" } }),
 passErr && React.createElement("div", { style: { color: "#fc8181", fontSize: "0.8rem" } }, passErr),
 React.createElement("div", { style: { display: "flex", gap: "0.5rem" } },
 React.createElement("button", { onClick: changePassword, style: { flex: 1, background: C.accent, color: "#fff", border: "none", padding: "0.5rem", borderRadius: "8px", fontWeight: 700, cursor: "pointer", fontSize: "0.85rem" } }, "\u05D0\u05E9\u05E8"),
 React.createElement("button", { onClick: function () { setShowPassInput(false); setEditPass(""); setPassCode(""); setPassErr(""); }, style: { background: "transparent", border: "1px solid ".concat(C.border), color: C.muted, padding: "0.5rem 0.8rem", borderRadius: "8px", cursor: "pointer", fontSize: "0.85rem" } }, "\u05D1\u05D9\u05D8\u05D5\u05DC")))),
 (function () {
 var userClasses = Object.values(ls.get("classes") || {}).filter(function (c) { return (c.members || []).includes(selected.id); });
 if (userClasses.length === 0)
 return null;
 var getClsRole = function (c, uid) { return c.adminId === uid ? "admin" : (c.teachers || {})[uid] ? "teacher" : (c.helpers || {})[uid] ? "helper" : "student"; };
 var setClsRole = function (c, uid, role) {
 var all = ls.get("classes") || {};
 var cls = __assign({}, all[c.id]);
 var h = __assign({}, cls.helpers || {});
 var t = __assign({}, cls.teachers || {});
 if (role === "admin") {
 delete h[uid];
 delete t[uid];
 cls.adminId = uid;
 cls.helpers = h;
 cls.teachers = t;
 }
 else if (role === "teacher") {
 delete h[uid];
 t[uid] = true;
 cls.helpers = h;
 cls.teachers = t;
 }
 else if (role === "helper") {
 delete t[uid];
 h[uid] = { perms: [] };
 cls.helpers = h;
 cls.teachers = t;
 }
 else {
 delete h[uid];
 delete t[uid];
 cls.helpers = h;
 cls.teachers = t;
 }
 all[c.id] = cls;
 ls.set("classes", all);
 refresh();
 };
 var ROLE_COLORS = { admin: C.accent, teacher: "#f6ad55", helper: "#63b3ed", student: C.muted };
 var ROLE_LABELS = { admin: "👑 מנהל", teacher: "👨‍🏫 מורה", helper: "🤝 עוזר", student: "👤 תלמיד" };
 return (React.createElement("div", { style: { background: C.card, border: "1px solid ".concat(C.border), borderRadius: "12px", overflow: "hidden" } },
 React.createElement("div", { style: { padding: "0.55rem 0.8rem", borderBottom: "1px solid ".concat(C.border), fontSize: "0.78rem", fontWeight: 700, color: C.muted } }, "\uD83C\uDFEB \u05EA\u05E4\u05E7\u05D9\u05D3\u05D9\u05DD \u05D1\u05DB\u05D9\u05EA\u05D5\u05EA"),
 userClasses.map(function (c) {
 var role = getClsRole(c, selected.id);
 var rc = ROLE_COLORS[role];
 return (React.createElement("div", { key: c.id, style: { display: "flex", alignItems: "center", gap: "0.6rem", padding: "0.5rem 0.8rem", borderBottom: "1px solid ".concat(C.border, "22") } },
 React.createElement("span", { style: { flex: 1, fontSize: "0.85rem", color: C.text, fontWeight: 600 } }, c.name),
 React.createElement("select", { value: role, onChange: function (e) { return setClsRole(c, selected.id, e.target.value); }, style: { background: C.bg, border: "1px solid ".concat(rc, "66"), color: rc, borderRadius: "8px", padding: "0.25rem 0.4rem", fontSize: "0.78rem", fontWeight: 600, cursor: "pointer" } },
 React.createElement("option", { value: "student" }, "\uD83D\uDC64 \u05EA\u05DC\u05DE\u05D9\u05D3"),
 React.createElement("option", { value: "helper" }, "\uD83E\uDD1D \u05E2\u05D5\u05D6\u05E8"),
 React.createElement("option", { value: "teacher" }, "\uD83D\uDC68\u200D\uD83C\uDFEB \u05DE\u05D5\u05E8\u05D4"),
 React.createElement("option", { value: "admin" }, "\uD83D\uDC51 \u05DE\u05E0\u05D4\u05DC"))));
 })));
 })(),
 React.createElement("button", { onClick: function () { return askCode("מחיקת המשתמש " + selected.username, function () { return deleteUser(selected.id); }); }, style: { background: "#fc818122", border: "1px solid #fc8181", color: "#fc8181", padding: "0.6rem", borderRadius: "10px", fontSize: "0.85rem", fontWeight: 600, cursor: "pointer" } }, "\uD83D\uDDD1\uFE0F \u05DE\u05D7\u05E7 \u05DE\u05E9\u05EA\u05DE\u05E9"))))),
 tab === "classes" && (function () {
 var selectedCls = adminSelectedCls;
 if (selectedCls) {
 var cls_1 = (function () { var all = ls.get("classes") || {}; return Object.values(all).find(function (c) { return c.id === selectedCls; }); })();
 if (!cls_1)
 return React.createElement("div", { style: { padding: "2rem", color: C.muted, textAlign: "center" } }, "\u05DB\u05D9\u05EA\u05D4 \u05DC\u05D0 \u05E0\u05DE\u05E6\u05D0\u05D4");
 var members = cls_1.members || [];
 var helpers_1 = cls_1.helpers || {};
 var teachers_1 = cls_1.teachers || {};
 var usersMap_1 = ls.get("users") || {};
 var memberCount = members.length;
 var allUsersArr_1 = Object.values(usersMap_1);
 var findUser_1 = function (id) { return usersMap_1[id] || allUsersArr_1.find(function (x) { return x.id === id || x.id === String(id); }); };
 var getRole_1 = function (id) { var rid = typeof id === "object" ? id.id : id; return rid === cls_1.adminId ? "admin" : teachers_1[rid] ? "teacher" : helpers_1[rid] ? "helper" : "student"; };
 var ROLES_1 = { admin: { label: "👑 מנהל", color: C.accent }, teacher: { label: "👨‍🏫 מורה", color: "#f6ad55" }, helper: { label: "🤝 עוזר", color: "#63b3ed" }, student: { label: "👤 תלמיד", color: C.muted } };
 var setRole_1 = function (uid, role) {
 var all = ls.get("classes") || {};
 var c = __assign({}, all[cls_1.id]);
 var h = __assign({}, c.helpers || {});
 var t = __assign({}, c.teachers || {});
 if (role === "admin") {
 delete h[uid];
 delete t[uid];
 c.adminId = uid;
 c.helpers = h;
 c.teachers = t;
 }
 else if (role === "teacher") {
 delete h[uid];
 t[uid] = true;
 c.helpers = h;
 c.teachers = t;
 }
 else if (role === "helper") {
 delete t[uid];
 h[uid] = { perms: [] };
 c.helpers = h;
 c.teachers = t;
 }
 else {
 delete h[uid];
 delete t[uid];
 c.helpers = h;
 c.teachers = t;
 }
 all[cls_1.id] = c;
 ls.set("classes", all);
 refresh();
 };
 return (React.createElement("div", { style: { flex: 1, overflowY: "auto" } },
 React.createElement("div", { style: { display: "flex", alignItems: "center", gap: "0.75rem", padding: "0.75rem 1rem", borderBottom: "1px solid ".concat(C.border), position: "sticky", top: 0, background: C.card, zIndex: 1 } },
 React.createElement("button", { onClick: function () { return setAdminSelectedCls(null); }, style: { background: "transparent", border: "1px solid ".concat(C.border), color: C.muted, padding: "0.3rem 0.7rem", borderRadius: "8px", fontSize: "0.82rem", cursor: "pointer" } }, "\u2190 \u05D7\u05D6\u05E8\u05D4"),
 React.createElement("div", { style: { flex: 1 } },
 React.createElement("div", { style: { fontWeight: 700, color: C.text } }, cls_1.name),
 React.createElement("div", { style: { fontSize: "0.75rem", color: C.muted } },
 members.length,
 " \u05D7\u05D1\u05E8\u05D9\u05DD")),
 React.createElement("button", { onClick: function () { return refresh(); }, style: { background: C.accent + "22", border: "1px solid ".concat(C.accent, "44"), color: C.accent, padding: "0.3rem 0.6rem", borderRadius: "8px", fontSize: "0.8rem", cursor: "pointer" } }, "\uD83D\uDD04 \u05E8\u05E2\u05E0\u05DF"),
 React.createElement("button", { onClick: function () { return askCode('מחיקת הכיתה "' + cls_1.name + '"', function () {
 var all = ls.get("classes") || {};
 delete all[cls_1.id];
 ls.set("classes", all); 
 fetch("".concat(SUPA_URL, "/rest/v1/classes?id=eq.").concat(cls_1.id), { method: "DELETE", headers: { "apikey": SUPA_KEY, "Authorization": "Bearer " + SUPA_KEY } }).catch(function (e) { return console.warn("delete class supabase failed", e); });
 setAdminSelectedCls(null);
 refresh();
 }); }, style: { background: "#fc818122", border: "1px solid #fc818144", color: "#fc8181", padding: "0.3rem 0.6rem", borderRadius: "8px", fontSize: "0.8rem", cursor: "pointer" } }, "\uD83D\uDDD1\uFE0F \u05DE\u05D7\u05E7")),
 members.length === 0 && React.createElement("div", { style: { padding: "2rem", textAlign: "center", color: C.muted } }, "\u05D0\u05D9\u05DF \u05D7\u05D1\u05E8\u05D9\u05DD \u05D1\u05DB\u05D9\u05EA\u05D4"),
 members.map(function (uid, idx) {
 var actualId = typeof uid === "object" ? uid.id : uid;
 var u = findUser_1(actualId) || (typeof uid === "object" ? uid : null);
 if (!u)
 return (React.createElement("div", { key: actualId || idx, style: { display: "flex", alignItems: "center", gap: "0.75rem", padding: "0.65rem 1rem", borderBottom: "1px solid ".concat(C.border, "22"), opacity: 0.6 } },
 React.createElement("div", { style: { width: "34px", height: "34px", borderRadius: "50%", background: C.border, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.85rem", flexShrink: 0 } }, "?"),
 React.createElement("div", { style: { flex: 1 } },
 React.createElement("div", { style: { fontSize: "0.82rem", color: C.muted } }, "\u05DE\u05E9\u05EA\u05DE\u05E9 \u05DC\u05D0 \u05E0\u05DE\u05E6\u05D0"),
 React.createElement("div", { style: { fontSize: "0.7rem", color: C.muted } },
 "ID: ",
 String(actualId)))));
 var role = getRole_1(actualId);
 var rc = ROLES_1[role];
 return (React.createElement("div", { key: actualId || idx, style: { display: "flex", alignItems: "center", gap: "0.75rem", padding: "0.65rem 1rem", borderBottom: "1px solid ".concat(C.border, "22") } },
 React.createElement("div", { style: { width: "34px", height: "34px", borderRadius: "50%", background: rc.color + "22", border: "1px solid ".concat(rc.color, "44"), display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.85rem", flexShrink: 0 } }, rc.label.split(" ")[0]),
 React.createElement("div", { style: { flex: 1, minWidth: 0 } },
 React.createElement("div", { style: { fontWeight: 600, fontSize: "0.88rem", color: C.text } }, u.username),
 React.createElement("div", { style: { fontSize: "0.73rem", color: C.muted } },
 "\u05DB\u05D9\u05EA\u05D4 ",
 u.grade || "—",
 " \u00B7 ",
 u.lastLogin ? (function () { var diff = Date.now() - u.lastLogin; var mins = Math.floor(diff / 60000); var hours = Math.floor(diff / 3600000); var days = Math.floor(diff / 86400000); return mins < 1 ? "עכשיו" : mins < 60 ? "\u05DC\u05E4\u05E0\u05D9 ".concat(mins, " \u05D3\u05E7'") : hours < 24 ? "\u05DC\u05E4\u05E0\u05D9 ".concat(hours, " \u05E9\u05E2'") : "\u05DC\u05E4\u05E0\u05D9 ".concat(days, " \u05D9\u05DE\u05D9\u05DD"); })() : "לא נכנס")),
 React.createElement("select", { value: role, onChange: function (e) { return setRole_1(typeof uid === "object" ? uid.id : uid, e.target.value); }, style: { background: C.bg, border: "1px solid ".concat(rc.color, "66"), color: rc.color, borderRadius: "8px", padding: "0.3rem 0.5rem", fontSize: "0.8rem", fontWeight: 600, cursor: "pointer" } },
 React.createElement("option", { value: "student" }, "\uD83D\uDC64 \u05EA\u05DC\u05DE\u05D9\u05D3"),
 React.createElement("option", { value: "helper" }, "\uD83E\uDD1D \u05E2\u05D5\u05D6\u05E8"),
 React.createElement("option", { value: "teacher" }, "\uD83D\uDC68\u200D\uD83C\uDFEB \u05DE\u05D5\u05E8\u05D4"),
 React.createElement("option", { value: "admin" }, "\uD83D\uDC51 \u05DE\u05E0\u05D4\u05DC"))));
 })));
 }
 return (React.createElement("div", { style: { flex: 1, overflowY: "auto" } },
 filteredClasses.length === 0 && React.createElement("div", { style: { textAlign: "center", color: C.muted, padding: "3rem" } }, "\u05D0\u05D9\u05DF \u05DB\u05D9\u05EA\u05D5\u05EA"),
 filteredClasses.map(function (cls) {
 var admin = allUsers.find(function (u) { return u.id === cls.adminId; });
 var members = cls.members || [];
 return (React.createElement("div", { key: cls.id, onClick: function () { return setAdminSelectedCls(cls.id); }, style: { display: "flex", alignItems: "center", gap: "0.75rem", padding: "0.75rem 1rem", borderBottom: "1px solid ".concat(C.border), cursor: "pointer", background: "transparent", transition: "background 0.15s" }, onMouseEnter: function (e) { return e.currentTarget.style.background = C.border + "33"; }, onMouseLeave: function (e) { return e.currentTarget.style.background = "transparent"; } },
 React.createElement("div", { style: { width: "40px", height: "40px", borderRadius: "12px", background: C.accent + "22", border: "1px solid ".concat(C.accent, "44"), display: "flex", alignItems: "center", justifyContent: "center", fontSize: "1.2rem", flexShrink: 0 } }, "\uD83C\uDFEB"),
 React.createElement("div", { style: { flex: 1, minWidth: 0 } },
 React.createElement("div", { style: { fontWeight: 700, fontSize: "0.92rem", color: C.text } }, cls.name),
 React.createElement("div", { style: { fontSize: "0.75rem", color: C.muted, marginTop: "0.1rem" } },
 "\u05DE\u05E0\u05D4\u05DC: ",
 (admin === null || admin === void 0 ? void 0 : admin.username) || "—",
 " \u00B7 ",
 members.length,
 " \u05D7\u05D1\u05E8\u05D9\u05DD")),
 React.createElement("div", { style: { fontSize: "0.75rem", color: C.muted } }, "\u2190")));
 })));
 })())));
}
function AccountModal(_a) {
 var user = _a.user, onSave = _a.onSave, onClose = _a.onClose, theme = _a.theme, setTheme = _a.setTheme;
 var _b = React.useState(user.username || ""), username = _b[0], setUsername = _b[1];
 var _c = React.useState(""), oldPass = _c[0], setOldPass = _c[1];
 var _d = React.useState(""), newPass = _d[0], setNewPass = _d[1];
 var _e = React.useState(""), newPass2 = _e[0], setNewPass2 = _e[1];
 var _f = React.useState(""), err = _f[0], setErr = _f[1];
 var _g = React.useState(""), success = _g[0], setSuccess = _g[1];
 var _h = React.useState(0), secretClicks = _h[0], setSecretClicks = _h[1];
 var _j = React.useState(false), showAdminInput = _j[0], setShowAdminInput = _j[1];
 var _k = React.useState(""), adminCode = _k[0], setAdminCode = _k[1];
 var _l = React.useState(""), adminErr = _l[0], setAdminErr = _l[1];
 var _m = React.useState(false), showAdmin = _m[0], setShowAdmin = _m[1];
 var _o = React.useState(0), adminAttempts = _o[0], setAdminAttempts = _o[1];
 var _p = React.useState(null), adminLockedUntil = _p[0], setAdminLockedUntil = _p[1];
 var handleSecretClick = function () {
 var next = secretClicks + 1;
 setSecretClicks(next);
 if (next >= 5) {
 setShowAdminInput(true);
 setSecretClicks(0);
 }
 };
 var checkAdmin = function () {
 var now = Date.now();
 if (adminLockedUntil && now < adminLockedUntil) {
 var secs = Math.ceil((adminLockedUntil - now) / 1000);
 setAdminErr("\u05E0\u05E2\u05D5\u05DC \u05E2\u05D5\u05D3 ".concat(secs, " \u05E9\u05E0\u05D9\u05D5\u05EA"));
 return;
 }
 var masterCode = ls.get("adminMasterCode") || "040413";
 if (adminCode === masterCode) {
 setShowAdmin(true);
 setShowAdminInput(false);
 setAdminCode("");
 setAdminAttempts(0);
 setAdminLockedUntil(null);
 }
 else {
 var newAttempts = adminAttempts + 1;
 setAdminAttempts(newAttempts);
 if (newAttempts >= 3) {
 var lockUntil = now + 5 * 60 * 1000;
 setAdminLockedUntil(lockUntil);
 ls.set("adminLockLog", { time: now, attempts: newAttempts });
 setAdminErr("3 ניסיונות שגויים — נעול ל-5 דקות");
 setAdminCode("");
 }
 else {
 setAdminErr("\u05E7\u05D5\u05D3 \u05E9\u05D2\u05D5\u05D9 (".concat(newAttempts, "/3 \u05E0\u05D9\u05E1\u05D9\u05D5\u05E0\u05D5\u05EA)"));
 setTimeout(function () { return setAdminErr(""); }, 2000);
 }
 }
 };
 var inp = { background: C.card, border: "1px solid ".concat(C.border), color: C.text, padding: "0.65rem 0.9rem", borderRadius: "8px", fontSize: "0.88rem", outline: "none", width: "100%" };
 var save = function () {
 setErr("");
 setSuccess("");
 if (!username.trim()) {
 setErr("שם משתמש לא יכול להיות ריק");
 return;
 }
 var users = ls.get("users") || {};
 if (username !== user.username && Object.values(users).find(function (u) { return u.id !== user.id && u.username === username; })) {
 setErr("שם משתמש כבר קיים");
 return;
 }
 var updUser = __assign(__assign({}, user), { username: username.trim() });
 if (newPass) {
 if (oldPass !== user.password) {
 setErr("סיסמא נוכחית שגויה");
 return;
 }
 if (newPass.length < 4) {
 setErr("סיסמא חדשה חייבת להיות לפחות 4 תווים");
 return;
 }
 if (newPass !== newPass2) {
 setErr("הסיסמאות החדשות לא תואמות");
 return;
 }
 updUser = __assign(__assign({}, updUser), { password: newPass });
 }
 onSave(updUser);
 setSuccess("הפרטים עודכנו בהצלחה ✓");
 setTimeout(onClose, 1000);
 };
 return (React.createElement(React.Fragment, null,
 React.createElement("div", { style: { position: "fixed", inset: 0, background: "#000a", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 500, padding: "1rem" }, onClick: onClose },
 React.createElement("div", { style: { background: C.card, border: "1px solid ".concat(C.border), borderRadius: "20px", padding: "1.75rem", width: "100%", maxWidth: "380px", display: "flex", flexDirection: "column", gap: "0.9rem" }, onClick: function (e) { return e.stopPropagation(); } },
 React.createElement("div", { style: { display: "flex", alignItems: "center", justifyContent: "space-between" } },
 React.createElement("h2", { style: { fontSize: "1.1rem", fontWeight: 700, margin: 0 } }, "\u2699\uFE0F \u05E4\u05E8\u05D8\u05D9 \u05D7\u05E9\u05D1\u05D5\u05DF"),
 React.createElement("button", { onClick: onClose, style: { background: "transparent", border: "none", color: C.muted, fontSize: "1.3rem", cursor: "pointer", lineHeight: 1 } }, "\u2715")),
 React.createElement("div", null,
 React.createElement("div", { style: { fontSize: "0.78rem", color: C.muted, marginBottom: "0.35rem", fontWeight: 600 } }, "\u05E9\u05DD \u05DE\u05E9\u05EA\u05DE\u05E9"),
 React.createElement("input", { style: inp, value: username, onChange: function (e) { return setUsername(e.target.value); } })),
 React.createElement("div", { style: { borderTop: "1px solid ".concat(C.border), paddingTop: "0.75rem" } },
 React.createElement("div", { onClick: handleSecretClick, style: { fontSize: "0.78rem", color: C.muted, marginBottom: "0.5rem", fontWeight: 600, cursor: "default", userSelect: "none" } }, "\u05E9\u05D9\u05E0\u05D5\u05D9 \u05E1\u05D9\u05E1\u05DE\u05D0 (\u05D4\u05E9\u05D0\u05E8 \u05E8\u05D9\u05E7 \u05D0\u05DD \u05DC\u05D0 \u05E8\u05D5\u05E6\u05D4 \u05DC\u05E9\u05E0\u05D5\u05EA)"),
 React.createElement("div", { style: { display: "flex", flexDirection: "column", gap: "0.4rem" } },
 React.createElement("input", { type: "password", style: inp, placeholder: "\u05E1\u05D9\u05E1\u05DE\u05D0 \u05E0\u05D5\u05DB\u05D7\u05D9\u05EA", value: oldPass, onChange: function (e) { return setOldPass(e.target.value); } }),
 React.createElement("input", { type: "password", style: inp, placeholder: "\u05E1\u05D9\u05E1\u05DE\u05D0 \u05D7\u05D3\u05E9\u05D4", value: newPass, onChange: function (e) { return setNewPass(e.target.value); } }),
 React.createElement("input", { type: "password", style: inp, placeholder: "\u05D0\u05D9\u05DE\u05D5\u05EA \u05E1\u05D9\u05E1\u05DE\u05D0 \u05D7\u05D3\u05E9\u05D4", value: newPass2, onChange: function (e) { return setNewPass2(e.target.value); } }))),
 err && React.createElement("div", { style: { color: C.red, fontSize: "0.83rem", textAlign: "center" } }, err),
 success && React.createElement("div", { style: { color: C.green, fontSize: "0.83rem", textAlign: "center" } }, success),
 React.createElement("div", { style: { borderTop: "1px solid ".concat(C.border), paddingTop: "0.75rem", marginBottom: "0.5rem" } },
 React.createElement("div", { style: { fontSize: "0.78rem", color: C.muted, marginBottom: "0.5rem", fontWeight: 600 } }, "\uD83C\uDF13 \u05DE\u05E6\u05D1 \u05EA\u05E6\u05D5\u05D2\u05D4"),
 React.createElement("div", { style: { display: "flex", gap: "0.4rem" } },
 React.createElement("button", { onClick: function () { return setTheme("dark"); }, style: { flex: 1, padding: "0.45rem", borderRadius: "10px", border: "1px solid " + (theme === "dark" ? C.accent : C.border), background: theme === "dark" ? C.accent + "33" : "transparent", color: theme === "dark" ? C.accent : C.muted, fontSize: "0.85rem", fontWeight: theme === "dark" ? 700 : 400, cursor: "pointer" } }, "\uD83C\uDF19 \u05DB\u05D4\u05D4"),
 React.createElement("button", { onClick: function () { return setTheme("light"); }, style: { flex: 1, padding: "0.45rem", borderRadius: "10px", border: "1px solid " + (theme === "light" ? C.accent : C.border), background: theme === "light" ? C.accent + "33" : "transparent", color: theme === "light" ? C.accent : C.muted, fontSize: "0.85rem", fontWeight: theme === "light" ? 700 : 400, cursor: "pointer" } }, "\u2600 \u05D1\u05D4\u05D9\u05E8"))),
 React.createElement("div", { style: { display: "flex", gap: "0.5rem" } },
 React.createElement("button", { onClick: save, style: { flex: 1, background: C.accent, color: "#fff", border: "none", padding: "0.65rem", borderRadius: "10px", fontSize: "0.9rem", fontWeight: 700, cursor: "pointer" } }, "\u05E9\u05DE\u05D5\u05E8"),
 React.createElement("button", { onClick: onClose, style: { background: "transparent", border: "1px solid ".concat(C.border), color: C.muted, padding: "0.65rem 1rem", borderRadius: "10px", fontSize: "0.9rem", cursor: "pointer" } }, "\u05D1\u05D9\u05D8\u05D5\u05DC")))),
 showAdminInput && (React.createElement("div", { style: { position: "fixed", inset: 0, background: "#000c", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 600 }, onClick: function () { setShowAdminInput(false); setAdminCode(""); } },
 React.createElement("div", { style: { background: C.card, border: "1px solid ".concat(C.border), borderRadius: "16px", padding: "1.5rem", width: "280px", display: "flex", flexDirection: "column", gap: "0.75rem" }, onClick: function (e) { return e.stopPropagation(); } },
 React.createElement("div", { style: { fontSize: "1rem", fontWeight: 700, color: C.text, textAlign: "center" } }, "\uD83D\uDD10 \u05E7\u05D5\u05D3 \u05D2\u05D9\u05E9\u05D4"),
 React.createElement("input", { autoFocus: true, type: "password", value: adminCode, onChange: function (e) { return setAdminCode(e.target.value); }, onKeyDown: function (e) { return e.key === "Enter" && checkAdmin(); }, placeholder: "\u05D4\u05DB\u05E0\u05E1 \u05E7\u05D5\u05D3...", disabled: !!(adminLockedUntil && Date.now() < adminLockedUntil), style: { background: C.bg, border: "1px solid ".concat(adminLockedUntil && Date.now() < adminLockedUntil ? "#fc8181" : C.border), color: C.text, padding: "0.65rem", borderRadius: "8px", fontSize: "1rem", outline: "none", textAlign: "center", letterSpacing: "0.2em", opacity: adminLockedUntil && Date.now() < adminLockedUntil ? 0.5 : 1 } }),
 adminErr && React.createElement("div", { style: { color: "#fc8181", fontSize: "0.82rem", textAlign: "center" } }, adminErr),
 React.createElement("button", { onClick: checkAdmin, style: { background: C.accent, color: "#fff", border: "none", padding: "0.6rem", borderRadius: "8px", fontWeight: 700, cursor: "pointer" } }, "\u05DB\u05E0\u05D9\u05E1\u05D4")))),
 showAdmin && React.createElement(AdminPanel, { onClose: function () { return setShowAdmin(false); } })));
}
function Dashboard(_a) {
 var userProp = _a.user, myClasses = _a.myClasses, setMode = _a.setMode, mode = _a.mode;
 var user = ls.get("currentUser") || userProp;
 var personal = user.personal || {};
 var today = new Date().toISOString().split("T")[0];
 var upcoming = function (arr) { return (arr || []).filter(function (x) { return !x.done && (!x.dueDate || x.dueDate >= today); }).sort(function (a, b) { return (a.dueDate || "9999") > (b.dueDate || "9999") ? 1 : -1; }).slice(0, 3); };
 var allHwFull = __spreadArray(__spreadArray([], upcoming(personal.homework).map(function (x) { return (__assign(__assign({}, x), { _cls: null })); }), true), upcoming((myClasses || []).flatMap(function (c) { return (c.homework || []).map(function (x) { return (__assign(__assign({}, x), { _cls: c.name })); }); })), true);
 var allWkFull = __spreadArray(__spreadArray([], upcoming(personal.works).map(function (x) { return (__assign(__assign({}, x), { _cls: null })); }), true), upcoming((myClasses || []).flatMap(function (c) { return (c.works || []).map(function (x) { return (__assign(__assign({}, x), { _cls: c.name })); }); })), true);
 var allTsFull = __spreadArray(__spreadArray([], upcoming(personal.tests).map(function (x) { return (__assign(__assign({}, x), { _cls: null })); }), true), upcoming((myClasses || []).flatMap(function (c) { return (c.tests || []).map(function (x) { return (__assign(__assign({}, x), { _cls: c.name })); }); })), true);
 var allHw = allHwFull.slice(0, 3);
 var allWk = allWkFull.slice(0, 3);
 var allTs = allTsFull.slice(0, 3);
 var getNextLesson = function () {
 var now = new Date();
 var nowMin = now.getHours() * 60 + now.getMinutes();
 var dayIdx = now.getDay(); 
 var todayHeb = DAYS[dayIdx === 0 ? 6 : dayIdx - 1]; 
 var parseTime = function (t) { if (!t)
 return null; var _a = (t || "").split(":").map(Number), h = _a[0], m = _a[1]; return isNaN(h) ? null : h * 60 + (m || 0); };
 var schedules = __spreadArray([
 { schedule: personal.schedule, label: "אישי", color: C.accent }
 ], (myClasses || []).map(function (c) { return ({ schedule: c.schedule, label: c.name, color: "#63b3ed" }); }), true);
 var best = null;
 for (var _i = 0, schedules_1 = schedules; _i < schedules_1.length; _i++) {
 var _a = schedules_1[_i], schedule = _a.schedule, label = _a.label, color = _a.color;
 if (!(schedule === null || schedule === void 0 ? void 0 : schedule.rows) || !(schedule === null || schedule === void 0 ? void 0 : schedule.days))
 continue;
 var dayData = schedule.days[todayHeb] || {};
 for (var _b = 0, _c = schedule.rows; _b < _c.length; _b++) {
 var row = _c[_b];
 var subj = dayData[row.id];
 if (!subj || !subj.trim())
 continue;
 var start = parseTime(row.from);
 if (start === null)
 continue;
 if (start > nowMin) {
 if (!best || start < best.start)
 best = { subj: subj, from: row.from, to: row.to, label: label, color: color, start: start };
 }
 }
 }
 return best;
 };
 var nextLesson = getNextLesson();
 var Section = function (_a) {
 var title = _a.title, items = _a.items, color = _a.color, icon = _a.icon, count = _a.count;
 return (React.createElement("div", { style: { background: C.card, border: "1px solid ".concat(C.border), borderRadius: "14px", padding: "1rem 1.25rem", flex: 1, minWidth: "180px" } },
 React.createElement("div", { style: { display: "flex", alignItems: "center", gap: "0.5rem", marginBottom: "0.75rem" } },
 React.createElement("span", { style: { fontSize: "1.1rem" } }, icon),
 React.createElement("span", { style: { fontWeight: 700, fontSize: "0.92rem", color: color, flex: 1 } }, title),
 React.createElement("span", { style: { background: color, color: "#fff", borderRadius: "999px", fontSize: "0.72rem", fontWeight: 700, minWidth: "20px", height: "20px", display: "flex", alignItems: "center", justifyContent: "center", padding: "0 6px" } }, count || 0)),
 items.length === 0
 ? React.createElement("div", { style: { fontSize: "0.82rem", color: C.muted, textAlign: "center", padding: "0.75rem 0" } }, "\u05D0\u05D9\u05DF \u05E7\u05E8\u05D5\u05D1\u05D9\u05DD \u2728")
 : items.map(function (item) {
 var d = item.dueDate ? Math.ceil((new Date(item.dueDate) - new Date()) / (1000 * 60 * 60 * 24)) : null;
 return (React.createElement("div", { key: item.id + (item._cls || ""), style: { borderBottom: "1px solid ".concat(C.border, "33"), padding: "0.4rem 0" } },
 React.createElement("div", { style: { fontSize: "0.85rem", fontWeight: 600 } }, item.title),
 item._cls && React.createElement("div", { style: { fontSize: "0.7rem", color: "#63b3ed" } },
 "\uD83C\uDFEB ",
 item._cls),
 d !== null && React.createElement("div", { style: { fontSize: "0.72rem", color: d <= 2 ? "#fc8181" : d <= 5 ? "#f6ad55" : C.muted } },
 "\u05E2\u05D5\u05D3 ",
 d,
 " \u05D9\u05DE\u05D9\u05DD")));
 })));
 };
 return (React.createElement("div", null,
 React.createElement("div", { style: { marginBottom: "1.5rem" } },
 React.createElement("h2", { style: { fontSize: "1.2rem", fontWeight: 700, margin: "0 0 0.2rem" } },
 "\u05E9\u05DC\u05D5\u05DD, ",
 user.username,
 " \uD83D\uDC4B"),
 React.createElement("p", { style: { color: C.muted, fontSize: "0.84rem", margin: 0 } }, new Date().toLocaleDateString("he-IL", { weekday: "long" }))),
 React.createElement("div", { style: { display: "flex", gap: "0.6rem", marginBottom: "1.25rem", flexWrap: "wrap" } }, (function () {
 var nextTest = allTsFull[0];
 var nextHw = allHwFull[0];
 var nextWk = allWkFull[0];
 var allDictation = (myClasses || []).flatMap(function (c) { return (c.dictationSets || []); });
 var hasDictation = allDictation.length > 0 || (ls.get("studySets_" + user.id) || []).length > 0;
 var recs = [];
 if (nextTest) {
 var d = nextTest.dueDate ? Math.ceil((new Date(nextTest.dueDate) - new Date()) / (1000 * 60 * 60 * 24)) : null;
 var urgent = d !== null && d <= 5;
 recs.push({
 onClick: function () { return setMode("study"); },
 icon: "🧠",
 label: "הכנה למבחן",
 sub: nextTest.title + (d !== null ? " \u2014 \u05E2\u05D5\u05D3 ".concat(d, " \u05D9\u05DE\u05D9\u05DD") : ""),
 color: "#f6855a",
 urgent: urgent
 });
 }
 if (hasDictation) {
 recs.push({
 onClick: function () { return setMode("study"); },
 icon: "📝",
 label: "למידה להכתבה",
 sub: "יש ערכות מילים ללמידה",
 color: C.accent,
 urgent: false
 });
 }
 if (nextHw && recs.length < 2) {
 var d = nextHw.dueDate ? Math.ceil((new Date(nextHw.dueDate) - new Date()) / (1000 * 60 * 60 * 24)) : null;
 recs.push({
 onClick: function () { return setMode("personal"); },
 icon: "📚",
 label: "שיעורי בית",
 sub: nextHw.title + (d !== null ? " \u2014 \u05E2\u05D5\u05D3 ".concat(d, " \u05D9\u05DE\u05D9\u05DD") : ""),
 color: "#6c63ff",
 urgent: d !== null && d <= 2
 });
 }
 if (nextWk && recs.length < 2) {
 var d = nextWk.dueDate ? Math.ceil((new Date(nextWk.dueDate) - new Date()) / (1000 * 60 * 60 * 24)) : null;
 recs.push({
 onClick: function () { return setMode("personal"); },
 icon: "📁",
 label: "עבודה להגשה",
 sub: nextWk.title + (d !== null ? " \u2014 \u05E2\u05D5\u05D3 ".concat(d, " \u05D9\u05DE\u05D9\u05DD") : ""),
 color: "#f6ad55",
 urgent: d !== null && d <= 3
 });
 }
 if (recs.length === 0) {
 recs.push({ onClick: function () { return setMode("study"); }, icon: "📖", label: "מצב למידה", sub: "אין פריטים קרובים", color: C.accent, urgent: false });
 }
 return recs.slice(0, 2).map(function (r, idx) { return (React.createElement("button", { key: idx, onClick: r.onClick, style: { display: "flex", alignItems: "center", gap: "0.6rem", background: r.urgent ? r.color + "22" : C.card, border: "1px solid ".concat(r.urgent ? r.color + "88" : C.border), color: C.text, padding: "0.5rem 0.9rem", borderRadius: "12px", fontSize: "0.84rem", fontWeight: 600, cursor: "pointer", textAlign: "right", flex: 1, minWidth: "160px", position: "relative", overflow: "hidden" } },
 r.urgent && React.createElement("div", { style: { position: "absolute", top: 0, left: 0, right: 0, height: "2px", background: r.color } }),
 React.createElement("span", { style: { fontSize: "1.2rem" } }, r.icon),
 React.createElement("div", { style: { textAlign: "right" } },
 React.createElement("div", { style: { color: r.color, fontWeight: 700, fontSize: "0.82rem" } }, r.label),
 React.createElement("div", { style: { color: C.muted, fontSize: "0.72rem", fontWeight: 400 } }, r.sub)))); });
 })()),
 React.createElement("div", { style: { display: "flex", gap: "0.75rem", flexWrap: "wrap" } },
 React.createElement(Section, { title: "\u05E9\u05D9\u05E2\u05D5\u05E8\u05D9 \u05D1\u05D9\u05EA", items: allHw, color: "#6c63ff", icon: "\uD83D\uDCDD", count: allHwFull.length }),
 React.createElement(Section, { title: "\u05E2\u05D1\u05D5\u05D3\u05D5\u05EA", items: allWk, color: "#f6ad55", icon: "\uD83D\uDCC1", count: allWkFull.length }),
 React.createElement(Section, { title: "\u05DE\u05D1\u05D7\u05E0\u05D9\u05DD", items: allTs, color: "#fc8181", icon: "\uD83D\uDCCB", count: allTsFull.length })),
 React.createElement("div", { style: { background: C.card, border: "1px solid ".concat(nextLesson ? nextLesson.color + "55" : C.border), borderRadius: "12px", padding: "0.65rem 1rem", marginTop: "1rem", display: "flex", alignItems: "center", gap: "0.75rem" } },
 React.createElement("span", { style: { fontSize: "1.1rem" } }, "\uD83D\uDD50"),
 React.createElement("div", { style: { flex: 1 } }, nextLesson
 ? React.createElement(React.Fragment, null,
 React.createElement("span", { style: { fontWeight: 700, fontSize: "0.9rem", color: nextLesson.color } }, nextLesson.subj),
 React.createElement("span", { style: { fontSize: "0.78rem", color: C.muted, marginRight: "0.5rem" } },
 " \u00B7 ",
 nextLesson.from,
 "\u2013",
 nextLesson.to),
 nextLesson.label !== "אישי" && React.createElement("span", { style: { fontSize: "0.72rem", color: "#63b3ed", marginRight: "0.4rem" } },
 "\uD83C\uDFEB ",
 nextLesson.label))
 : React.createElement("span", { style: { fontSize: "0.84rem", color: C.muted } }, "\u05D0\u05D9\u05DF \u05E9\u05D9\u05E2\u05D5\u05E8\u05D9\u05DD \u05E0\u05D5\u05E1\u05E4\u05D9\u05DD \u05D4\u05D9\u05D5\u05DD")),
 React.createElement("span", { style: { fontSize: "0.75rem", color: C.muted, whiteSpace: "nowrap" } }, "\u05E9\u05D9\u05E2\u05D5\u05E8 \u05D4\u05D1\u05D0"))));
}
function PersonalMode(_a) {
 var user = _a.user, saveUser = _a.saveUser, tab = _a.tab, setTab = _a.setTab;
 var personal = user.personal || {};
 var isAdmin = user.role === "admin";
 var isTeacher = user.role === "teacher";
 var upd = function (f, v) {
 var _a;
 return saveUser(__assign(__assign({}, user), { personal: __assign(__assign({}, personal), (_a = {}, _a[f] = v, _a)) }));
 };
 var getC = function (t) { return (user.personalChecks || {})[t] || {}; };
 var setC = function (t, id, v) { var c = __assign({}, (user.personalChecks || {})); if (!c[t])
 c[t] = {}; c[t][id] = v; saveUser(__assign(__assign({}, user), { personalChecks: c })); };
 var tabs = [["homework", "📝 שיעורי בית"], ["works", "📁 עבודות"], ["tests", "📋 מבחנים"], ["schedule", "🗓️ לוח שעות"], ["done", "✅ בוצע"], ["grades", "📊 ציונים"]];
 return (React.createElement("div", null,
 React.createElement("div", { style: { display: "flex", gap: "0.2rem", marginBottom: "1rem", borderBottom: "1px solid ".concat(C.border), overflowX: "auto" } }, tabs.map(function (_a) {
 var k = _a[0], lbl = _a[1];
 return (React.createElement("button", { key: k, onClick: function () { return setTab(k); }, style: { background: "transparent", border: "none", color: tab === k ? C.accent : C.muted, padding: "0.55rem 0.8rem", fontSize: "0.82rem", fontWeight: tab === k ? 700 : 400, cursor: "pointer", borderBottom: tab === k ? "2px solid ".concat(C.accent) : "2px solid transparent", whiteSpace: "nowrap" } }, lbl));
 })),
 tab === "homework" && React.createElement(ItemList, { items: personal.homework, onSave: function (v) { return upd("homework", v); }, title: "\u05E9\u05D9\u05E2\u05D5\u05E8\u05D9 \u05D1\u05D9\u05EA", checks: getC("homework"), onCheck: function (id, v) { return setC("homework", id, v); }, showCheck: true }),
 tab === "works" && React.createElement(ItemList, { items: personal.works, onSave: function (v) { return upd("works", v); }, title: "\u05E2\u05D1\u05D5\u05D3\u05D5\u05EA", checks: getC("works"), onCheck: function (id, v) { return setC("works", id, v); }, showCheck: true }),
 tab === "tests" && React.createElement(ItemList, { items: personal.tests, onSave: function (v) { return upd("tests", v); }, title: "\u05DE\u05D1\u05D7\u05E0\u05D9\u05DD", checks: getC("tests"), onCheck: function (id, v) { return setC("tests", id, v); }, isTests: true }),
 tab === "schedule" && React.createElement(Schedule, { data: personal.schedule, onSave: function (v) { return upd("schedule", v); }, editable: true, userChecks: getC("schedule"), onUserCheck: function (k, v) { return setC("schedule", k, v); } }),
 tab === "done" && React.createElement(DoneList, { sections: [{ title: "שיעורי בית", items: personal.homework, checks: getC("homework"), color: "#6c63ff" }, { title: "עבודות", items: personal.works, checks: getC("works"), color: "#f6ad55" }, { title: "מבחנים", items: personal.tests, checks: getC("tests"), color: "#fc8181" }], onUncheck: function (t, id) { return setC(t, id, false); } }),
 tab === "grades" && React.createElement(GradesTracker, { user: user, saveUser: saveUser })));
}
function ClassesMode(_a) {
 var user = _a.user, saveUser = _a.saveUser, myClasses = _a.myClasses, setMyClasses = _a.setMyClasses, refreshClasses = _a.refreshClasses, tab = _a.tab, setTab = _a.setTab, classView = _a.classView, setClassView = _a.setClassView;
 var uid = user === null || user === void 0 ? void 0 : user.id;
 var _b = React.useState(""), newName = _b[0], setNewName = _b[1];
 var _c = React.useState(""), joinCode = _c[0], setJoinCode = _c[1];
 var _d = React.useState(""), msg = _d[0], setMsg = _d[1];
 var inp = { background: C.card, border: "1px solid ".concat(C.border), color: C.text, padding: "0.6rem 0.9rem", borderRadius: "8px", fontSize: "0.88rem", outline: "none", width: "100%" };
 var createClass = function () {
 if (!newName.trim() || !uid)
 return;
 var id = genId(), code = Math.random().toString(36).slice(2, 7).toUpperCase();
 var cls = { id: id, name: newName.trim(), code: code, adminId: uid, members: [uid], helpers: {}, homework: [], works: [], tests: [], schedule: {}, dictationSets: [], boardPhotos: [], photographers: [] };
 var all = ls.get("classes") || {};
 all[id] = cls;
 ls.set("classes", all);
 syncClassToSupabase(cls);
 setMyClasses(function (prev) { return __spreadArray(__spreadArray([], prev, true), [cls], false); });
 setNewName("");
 setMsg("כיתה נוצרה! קוד: " + code);
 setTimeout(function () { return setMsg(""); }, 15000);
 };
 var joinClass = function () {
 if (!uid)
 return;
 var code = joinCode.toUpperCase().trim();
 var allFromStore = _store["classes"] || {};
 var allLocal = ls.get("classes") || {};
 var allCombined = __assign(__assign({}, allLocal), allFromStore);
 var cls = Object.values(allCombined).find(function (c) { return c.code === code; });
 if (!cls) {
 setMsg("קוד לא נמצא");
 return;
 }
 if ((cls.members || []).includes(uid)) {
 setClassView(cls.id);
 return;
 }
 var updatedCls = __assign(__assign({}, cls), { members: __spreadArray(__spreadArray([], (cls.members || []), true), [uid], false) });
 allLocal[updatedCls.id] = updatedCls;
 ls.set("classes", allLocal);
 if (_store["classes"])
 _store["classes"][updatedCls.id] = updatedCls;
 syncClassToSupabase(updatedCls);
 setMyClasses(function (prev) {
 var exists = prev.find(function (c) { return c.id === updatedCls.id; });
 return exists ? prev.map(function (c) { return c.id === updatedCls.id ? updatedCls : c; }) : __spreadArray(__spreadArray([], prev, true), [updatedCls], false);
 });
 setJoinCode("");
 setMsg("הצטרפת לכיתה: " + updatedCls.name);
 setTimeout(function () { return setClassView(updatedCls.id); }, 300);
 };
 var cv = classView ? (myClasses.find(function (c) { return c.id === classView; }) || (_store["classes"] && _store["classes"][classView]) || null) : null;
 if (cv)
 return React.createElement(ClassDetail, { cls: cv, user: user, saveUser: saveUser, refreshClasses: refreshClasses, onBack: function () { return setClassView(null); }, tab: tab, setTab: setTab });
 return (React.createElement("div", null,
 React.createElement("div", { style: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.75rem", marginBottom: "1.5rem" } },
 React.createElement("div", { style: { background: C.card, border: "1px solid ".concat(C.border), borderRadius: "14px", padding: "1rem" } },
 React.createElement("div", { style: { fontWeight: 700, fontSize: "0.9rem", marginBottom: "0.6rem" } }, "\u2795 \u05E6\u05D5\u05E8 \u05DB\u05D9\u05EA\u05D4 \u05D7\u05D3\u05E9\u05D4"),
 React.createElement("div", { style: { display: "flex", gap: "0.5rem" } },
 React.createElement("input", { style: __assign(__assign({}, inp), { flex: 1 }), placeholder: "\u05E9\u05DD \u05D4\u05DB\u05D9\u05EA\u05D4", value: newName, onChange: function (e) { return setNewName(e.target.value); }, onKeyDown: function (e) { return e.key === "Enter" && createClass(); } }),
 React.createElement("button", { onClick: createClass, style: { background: C.accent, color: "#fff", border: "none", padding: "0.6rem 1rem", borderRadius: "8px", fontSize: "0.88rem", fontWeight: 600, cursor: "pointer", whiteSpace: "nowrap" } }, "\u05E6\u05D5\u05E8"))),
 React.createElement("div", { style: { background: C.card, border: "1px solid ".concat(C.border), borderRadius: "14px", padding: "1rem" } },
 React.createElement("div", { style: { fontWeight: 700, fontSize: "0.9rem", marginBottom: "0.6rem" } }, "\uD83D\uDD17 \u05D4\u05E6\u05D8\u05E8\u05E3 \u05DC\u05DB\u05D9\u05EA\u05D4"),
 React.createElement("div", { style: { display: "flex", gap: "0.5rem" } },
 React.createElement("input", { style: __assign(__assign({}, inp), { flex: 1 }), placeholder: "\u05E7\u05D5\u05D3 \u05DB\u05D9\u05EA\u05D4", value: joinCode, onChange: function (e) { return setJoinCode(e.target.value); }, onKeyDown: function (e) { return e.key === "Enter" && joinClass(); } }),
 React.createElement("button", { onClick: joinClass, style: { background: "#2a9d8f", color: "#fff", border: "none", padding: "0.6rem 1rem", borderRadius: "8px", fontSize: "0.88rem", fontWeight: 600, cursor: "pointer", whiteSpace: "nowrap" } }, "\u05D4\u05E6\u05D8\u05E8\u05E3")))),
 msg && React.createElement("div", { style: { background: C.card, border: "1px solid ".concat(C.green), borderRadius: "10px", padding: "0.6rem 1rem", fontSize: "0.85rem", color: C.green, marginBottom: "1rem" } }, msg),
 myClasses.length === 0 ? React.createElement("div", { style: { textAlign: "center", padding: "3rem", color: C.muted } }, "\u05D0\u05D9\u05DF \u05DB\u05D9\u05EA\u05D5\u05EA \u05E2\u05D3\u05D9\u05D9\u05DF") : (React.createElement("div", { style: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.6rem" } }, myClasses.map(function (c) {
 var isAdmin = c.adminId === user.id;
 var helpers = c.helpers || {};
 var isHelper = !!helpers[user.id];
 return (React.createElement("div", { key: c.id, onClick: function () { return setClassView(c.id); }, style: { background: C.card, border: "1px solid ".concat(C.border), borderRadius: "16px", padding: "1.4rem 1.25rem", cursor: "pointer" } },
 React.createElement("div", { style: { fontSize: "1.5rem", marginBottom: "0.5rem" } }, "\uD83C\uDFEB"),
 React.createElement("div", { style: { fontWeight: 700, fontSize: "1.05rem", marginBottom: "0.3rem" } }, c.name),
 React.createElement("div", { style: { fontSize: "0.78rem", color: C.muted, marginBottom: "0.6rem" } },
 "\u05E7\u05D5\u05D3: ",
 c.code,
 " \u00B7 ",
 (c.members || []).length,
 " \u05D7\u05D1\u05E8\u05D9\u05DD"),
 React.createElement("div", { style: { display: "flex", alignItems: "center", justifyContent: "space-between" } },
 isAdmin && React.createElement("span", { style: { background: C.accent, color: "#fff", fontSize: "0.68rem", padding: "0.15rem 0.5rem", borderRadius: "20px" } }, "\uD83D\uDC51 \u05DE\u05E0\u05D4\u05DC"),
 !isAdmin && isTeacher && React.createElement("span", { style: { background: "#f6ad55", color: "#fff", fontSize: "0.68rem", padding: "0.15rem 0.5rem", borderRadius: "20px" } }, "\uD83D\uDC68\u200D\uD83C\uDFEB \u05DE\u05D5\u05E8\u05D4"),
 !isAdmin && !isTeacher && isHelper && React.createElement("span", { style: { background: "#63b3ed", color: "#fff", fontSize: "0.68rem", padding: "0.15rem 0.5rem", borderRadius: "20px" } }, "\uD83E\uDD1D \u05E2\u05D5\u05D6\u05E8"),
 !isAdmin && !isTeacher && !isHelper && React.createElement("span", { style: { fontSize: "0.68rem", color: C.muted } }, "\uD83D\uDC64 \u05EA\u05DC\u05DE\u05D9\u05D3"),
 React.createElement("span", { style: { color: C.muted, fontSize: "0.85rem" } }, "\u2190"))));
 })))));
}
var PERM_OPTIONS = [
 { id: "homework", label: "📝 שיעורי בית" },
 { id: "works", label: "📁 עבודות" },
 { id: "tests", label: "📋 מבחנים" },
 { id: "schedule", label: "🗓️ לוח שעות" },
 { id: "dictation", label: "📖 הכתבה" },
 { id: "photos", label: "📷 צילומי לוח" },
];
function ClassDetail(_a) {
 var _b;
 var cls = _a.cls, user = _a.user, saveUser = _a.saveUser, refreshClasses = _a.refreshClasses, onBack = _a.onBack, tab = _a.tab, setTab = _a.setTab;
 var isAdmin = cls.adminId === user.id;
 var helpers = cls.helpers || {};
 var teachers = cls.teachers || {};
 var myPerms = ((_b = helpers[user.id]) === null || _b === void 0 ? void 0 : _b.perms) || [];
 var isHelper = !!helpers[user.id];
 var isTeacher = !!teachers[user.id];
 var can = function (p) { return isAdmin || isTeacher || myPerms.includes(p); };
 var photographers = cls.photographers || [];
 var canPhoto = can("photos") || photographers.includes(user.username);
 var updCls = function (f, v) { var all = ls.get("classes") || {}; if (all[cls.id])
 all[cls.id][f] = v; ls.set("classes", all); refreshClasses(user === null || user === void 0 ? void 0 : user.id); syncClassToSupabase(all[cls.id]); };
 var leaveClass = function () {
 if (cls.adminId === user.id) {
 alert("מנהל לא יכול לעזוב כיתה. מחק את הכיתה במקום.");
 return;
 }
 var all = ls.get("classes") || {};
 if (!all[cls.id])
 return;
 all[cls.id].members = (all[cls.id].members || []).filter(function (m) { return m !== user.id; });
 delete (all[cls.id].helpers || {})[user.id];
 delete (all[cls.id].teachers || {})[user.id];
 ls.set("classes", all);
 syncClassToSupabase(all[cls.id]);
 refreshClasses(user === null || user === void 0 ? void 0 : user.id);
 onBack();
 };
 var removeMember = function (memberId) {
 var all = ls.get("classes") || {};
 if (!all[cls.id])
 return;
 all[cls.id].members = (all[cls.id].members || []).filter(function (m) { return m !== memberId; });
 delete (all[cls.id].helpers || {})[memberId];
 ls.set("classes", all);
 syncClassToSupabase(all[cls.id]);
 refreshClasses(user === null || user === void 0 ? void 0 : user.id);
 };
 var getC = function (t) { var _a, _b; return ((_b = (_a = user.classChecks) === null || _a === void 0 ? void 0 : _a[cls.id]) === null || _b === void 0 ? void 0 : _b[t]) || {}; };
 var setC = function (t, id, v) { var c = __assign({}, (user.classChecks || {})); if (!c[cls.id])
 c[cls.id] = {}; if (!c[cls.id][t])
 c[cls.id][t] = {}; c[cls.id][t][id] = v; saveUser(__assign(__assign({}, user), { classChecks: c })); };
 var dictationSets = cls.dictationSets || [];
 var saveSet = function (set) { var ex = dictationSets.find(function (s) { return s.id === set.id; }); updCls("dictationSets", ex ? dictationSets.map(function (s) { return s.id === set.id ? set : s; }) : __spreadArray(__spreadArray([], dictationSets, true), [set], false)); };
 var delSet = function (id) { return updCls("dictationSets", dictationSets.filter(function (s) { return s.id !== id; })); };
 var tabs = [["homework", "📝 שיעורי בית"], ["works", "📁 עבודות"], ["tests", "📋 מבחנים"], ["schedule", "🗓️ לוח שעות"], ["dictation", "📖 הכתבה"], ["photos", "📷 צילומי לוח"]];
 if (isAdmin || isTeacher || isHelper)
 tabs.push(["members", "👥 חברים"]);
 tabs.push(["done", "✅ בוצע"]);
 return (React.createElement("div", null,
 React.createElement("div", { style: { display: "flex", alignItems: "center", gap: "0.6rem", marginBottom: "1rem", flexWrap: "wrap" } },
 React.createElement("button", { onClick: onBack, style: { background: "transparent", border: "1px solid ".concat(C.border), color: C.muted, padding: "0.35rem 0.7rem", borderRadius: "8px", fontSize: "0.85rem", cursor: "pointer" } }, "\u2190 \u05D7\u05D6\u05E8\u05D4"),
 React.createElement("h2", { style: { fontSize: "1.05rem", fontWeight: 700, margin: 0 } }, cls.name),
 isAdmin && React.createElement("span", { style: { background: C.accent, color: "#fff", fontSize: "0.65rem", padding: "0.1rem 0.4rem", borderRadius: "20px" } }, "\uD83D\uDC51 \u05DE\u05E0\u05D4\u05DC"),
 !isAdmin && isTeacher && React.createElement("span", { style: { background: "#f6ad55", color: "#fff", fontSize: "0.65rem", padding: "0.2rem 0.55rem", borderRadius: "20px", fontWeight: 600 } }, "\uD83D\uDC68\u200D\uD83C\uDFEB \u05DE\u05D5\u05E8\u05D4"),
 !isAdmin && !isTeacher && isHelper && React.createElement("span", { style: { background: "#63b3ed", color: "#fff", fontSize: "0.65rem", padding: "0.2rem 0.55rem", borderRadius: "20px", fontWeight: 600 } }, "\uD83E\uDD1D \u05E2\u05D5\u05D6\u05E8"),
 cls.adminId !== user.id && React.createElement("button", { onClick: function () { if (window.confirm("לעזוב את הכיתה " + cls.name + "?"))
 leaveClass(); }, style: { marginRight: "auto", background: "#fc818122", border: "1px solid #fc8181", color: "#fc8181", padding: "0.3rem 0.7rem", borderRadius: "8px", fontSize: "0.8rem", cursor: "pointer" } }, "\uD83D\uDEAA \u05E2\u05D6\u05D5\u05D1 \u05DB\u05D9\u05EA\u05D4"),
 React.createElement("span", { style: { background: C.card, border: "1px solid ".concat(C.border), color: C.muted, fontSize: "0.72rem", padding: "0.1rem 0.4rem", borderRadius: "8px" } },
 "\u05E7\u05D5\u05D3: ",
 cls.code)),
 React.createElement("div", { style: { display: "flex", gap: "0.2rem", marginBottom: "1rem", borderBottom: "1px solid ".concat(C.border), overflowX: "auto" } }, tabs.map(function (_a) {
 var k = _a[0], lbl = _a[1];
 return (React.createElement("button", { key: k, onClick: function () { return setTab(k); }, style: { background: "transparent", border: "none", color: tab === k ? C.accent : C.muted, padding: "0.55rem 0.75rem", fontSize: "0.8rem", fontWeight: tab === k ? 700 : 400, cursor: "pointer", borderBottom: tab === k ? "2px solid ".concat(C.accent) : "2px solid transparent", whiteSpace: "nowrap" } }, lbl));
 })),
 tab === "homework" && React.createElement(ItemList, { items: cls.homework, onSave: can("homework") ? function (v) { return updCls("homework", v); } : null, title: "\u05E9\u05D9\u05E2\u05D5\u05E8\u05D9 \u05D1\u05D9\u05EA", readOnly: !can("homework"), checks: getC("homework"), onCheck: function (id, v) { return setC("homework", id, v); }, showCheck: true }),
 tab === "works" && React.createElement(ItemList, { items: cls.works, onSave: can("works") ? function (v) { return updCls("works", v); } : null, title: "\u05E2\u05D1\u05D5\u05D3\u05D5\u05EA", readOnly: !can("works"), checks: getC("works"), onCheck: function (id, v) { return setC("works", id, v); }, showCheck: true }),
 tab === "tests" && React.createElement(ItemList, { items: cls.tests, onSave: isAdmin ? function (v) { return updCls("tests", v); } : null, title: "\u05DE\u05D1\u05D7\u05E0\u05D9\u05DD", readOnly: !isAdmin, checks: getC("tests"), onCheck: function (id, v) { return setC("tests", id, v); }, isTests: true }),
 tab === "schedule" && React.createElement(Schedule, { data: cls.schedule, onSave: can("schedule") ? function (v) { return updCls("schedule", v); } : null, editable: can("schedule"), userChecks: getC("schedule"), onUserCheck: function (k, v) { return setC("schedule", k, v); } }),
 tab === "dictation" && React.createElement(ClassDictation, { sets: dictationSets, isAdmin: can("dictation"), onSave: saveSet, onDelete: delSet, clsName: cls.name }),
 tab === "photos" && React.createElement(ClassBoardPhotos, { cls: cls, isAdmin: isAdmin, canAdd: canPhoto, updCls: updCls }),
 tab === "members" && (isAdmin || isHelper) && React.createElement(ClassMembers, { cls: cls, user: user, updCls: isAdmin || isTeacher ? updCls : null, isAdmin: isAdmin, isTeacher: isTeacher }),
 tab === "done" && React.createElement(DoneList, { sections: [{ title: "שיעורי בית", items: cls.homework, checks: getC("homework"), color: "#6c63ff" }, { title: "עבודות", items: cls.works, checks: getC("works"), color: "#f6ad55" }, { title: "מבחנים", items: cls.tests, checks: getC("tests"), color: "#fc8181" }], onUncheck: function (t, id) { return setC(t, id, false); } })));
}
function ClassMembers(_a) {
 var cls = _a.cls, user = _a.user, updCls = _a.updCls, isAdmin = _a.isAdmin, _b = _a.isTeacher, isTeacher = _b === void 0 ? false : _b;
 var members = cls.members || [];
 var helpers = cls.helpers || {};
 var teachers = cls.teachers || {};
 var BLUE = "#63b3ed";
 var _c = React.useState(null), expandedId = _c[0], setExpandedId = _c[1];
 var allUsers = ls.get("users") || {};
 var getName = function (id) { var u = allUsers[id]; return u ? u.username : "משתמש"; };
 var getRole = function (id) { return id === cls.adminId ? "admin" : teachers[id] ? "teacher" : helpers[id] ? "helper" : "student"; };
 var getPerms = function (id) { var _a; return ((_a = helpers[id]) === null || _a === void 0 ? void 0 : _a.perms) || []; };
 var setRole = function (id, role) {
 var _a, _b;
 if (role === "teacher") {
 var h = __assign({}, helpers);
 delete h[id];
 var t = __assign(__assign({}, teachers), (_a = {}, _a[id] = true, _a));
 updCls("helpers", h);
 updCls("teachers", t);
 setExpandedId(null);
 }
 else if (role === "helper") {
 var t = __assign({}, teachers);
 delete t[id];
 updCls("teachers", t);
 updCls("helpers", __assign(__assign({}, helpers), (_b = {}, _b[id] = { perms: [] }, _b)));
 setExpandedId(id);
 }
 else if (role === "student") {
 var h = __assign({}, helpers);
 delete h[id];
 var t = __assign({}, teachers);
 delete t[id];
 updCls("helpers", h);
 updCls("teachers", t);
 setExpandedId(null);
 }
 else if (role === "admin") {
 var h = __assign({}, helpers);
 delete h[id];
 var t = __assign({}, teachers);
 delete t[id];
 updCls("adminId", id);
 updCls("helpers", h);
 updCls("teachers", t);
 setExpandedId(null);
 }
 };
 var togglePerm = function (id, perm) {
 var _a;
 var cur = getPerms(id);
 var next = cur.includes(perm) ? cur.filter(function (p) { return p !== perm; }) : __spreadArray(__spreadArray([], cur, true), [perm], false);
 updCls("helpers", __assign(__assign({}, helpers), (_a = {}, _a[id] = { perms: next }, _a)));
 };
 var remove = function (id) { if (id === cls.adminId)
 return; var h = __assign({}, helpers); delete h[id]; updCls("members", members.filter(function (m) { return m !== id; })); updCls("helpers", h); setExpandedId(null); };
 var RS = function (active, color) { return ({ padding: "0.22rem 0.6rem", borderRadius: "20px", fontSize: "0.74rem", fontWeight: active ? 700 : 400, cursor: "pointer", border: "1px solid " + (active ? color : C.border), background: active ? color + "33" : "transparent", color: active ? color : C.muted }); };
 return (React.createElement("div", null,
 React.createElement("h3", { style: { fontSize: "1rem", fontWeight: 700, margin: "0 0 1rem" } }, "\uD83D\uDC65",
 " \u05E0\u05D9\u05D4\u05D5\u05DC \u05D7\u05D1\u05E8\u05D9\u05DD"),
 React.createElement("div", { style: { display: "flex", flexDirection: "column", gap: "0.6rem" } },
 members.map(function (id) {
 var role = getRole(id);
 var perms = getPerms(id);
 var expanded = expandedId === id;
 var isMe = id === user.id;
 return (React.createElement("div", { key: id, style: { background: C.card, border: "1px solid " + (role === "admin" ? C.accent + "66" : role === "teacher" ? "#f6ad5566" : role === "helper" ? BLUE + "66" : C.border), borderRadius: "14px", overflow: "hidden" } },
 React.createElement("div", { style: { padding: "0.75rem 1rem", display: "flex", alignItems: "center", gap: "0.6rem", flexWrap: "wrap" } },
 React.createElement("span", { style: { fontSize: "1.1rem" } }, role === "admin" ? "&#128081;" : role === "helper" ? "&#129309;" : "&#128100;"),
 React.createElement("div", { style: { flex: 1, minWidth: 0 } },
 React.createElement("div", { style: { fontWeight: 700, fontSize: "0.9rem" } },
 getName(id),
 isMe && React.createElement("span", { style: { fontSize: "0.68rem", color: C.muted, marginRight: "0.3rem" } }, "(\u05D0\u05EA\u05D4)")),
 role === "helper" && React.createElement("div", { style: { fontSize: "0.7rem", color: BLUE, marginTop: "0.15rem", display: "flex", flexWrap: "wrap", gap: "0.2rem" } }, perms.length === 0 ? React.createElement("span", { style: { color: C.red } }, "\u05D0\u05D9\u05DF \u05D4\u05E8\u05E9\u05D0\u05D5\u05EA") : perms.map(function (p) { var o = PERM_OPTIONS.find(function (x) { return x.id === p; }); return o ? React.createElement("span", { key: p, style: { background: BLUE + "22", borderRadius: "20px", padding: "0.05rem 0.3rem" } }, o.label) : null; })),
 role === "student" && React.createElement("div", { style: { fontSize: "0.7rem", color: C.muted } }, "\u05EA\u05DC\u05DE\u05D9\u05D3")),
 (isAdmin || isTeacher) && !isMe ? (React.createElement("div", { style: { display: "flex", gap: "0.25rem", flexWrap: "wrap", alignItems: "center" } },
 React.createElement("button", { onClick: function () { return setRole(id, "student"); }, style: RS(role === "student", C.muted) }, "\uD83D\uDC64 \u05EA\u05DC\u05DE\u05D9\u05D3"),
 React.createElement("button", { onClick: function () { return setRole(id, "helper"); }, style: RS(role === "helper", BLUE) }, "\uD83E\uDD1D \u05E2\u05D5\u05D6\u05E8"),
 React.createElement("button", { onClick: function () { return setRole(id, "teacher"); }, style: RS(role === "teacher", "#f6ad55") }, "\uD83D\uDC68\u200D\uD83C\uDFEB \u05DE\u05D5\u05E8\u05D4"),
 React.createElement("button", { onClick: function () { return setRole(id, "admin"); }, disabled: !isAdmin, style: __assign(__assign({}, RS(role === "admin", C.accent)), { opacity: isAdmin ? 1 : 0.4, cursor: isAdmin ? "pointer" : "not-allowed" }) }, "\uD83D\uDC51 \u05DE\u05E0\u05D4\u05DC"),
 role === "helper" && React.createElement("button", { onClick: function () { return setExpandedId(expanded ? null : id); }, style: { padding: "0.22rem 0.55rem", borderRadius: "8px", fontSize: "0.74rem", cursor: "pointer", border: "1px solid " + BLUE, background: expanded ? BLUE + "33" : "transparent", color: BLUE } }, expanded ? "סגור ✓" : "✏ הרשאות"),
 React.createElement("button", { onClick: function () { if (window.confirm("להסיר?"))
 remove(id); }, style: { padding: "0.22rem 0.55rem", borderRadius: "8px", fontSize: "0.74rem", cursor: "pointer", border: "1px solid #c53030", background: "#c5303022", color: "#fc8181" } }, "\u2715"))) : (React.createElement("span", { style: { fontSize: "0.72rem", padding: "0.15rem 0.5rem", borderRadius: "20px", background: role === "admin" ? C.accent + "22" : role === "teacher" ? "#f6ad5522" : role === "helper" ? BLUE + "22" : "#ffffff0a", color: role === "admin" ? C.accent : role === "teacher" ? "#f6ad55" : role === "helper" ? BLUE : C.muted, border: "1px solid " + (role === "admin" ? C.accent + "44" : role === "helper" ? BLUE + "44" : C.border) } }, role === "admin" ? "👑 מנהל" : role === "teacher" ? "👨‍🏫 מורה" : role === "helper" ? "🤝 עוזר" : "👤 תלמיד"))),
 isAdmin && role === "helper" && expanded && (React.createElement("div", { style: { borderTop: "1px solid " + BLUE + "33", background: BLUE + "0d", padding: "0.75rem 1rem" } },
 React.createElement("div", { style: { fontSize: "0.78rem", color: BLUE, fontWeight: 700, marginBottom: "0.5rem" } }, "\u270F \u05D4\u05E8\u05E9\u05D0\u05D5\u05EA \u05E2\u05D5\u05D6\u05E8 \u2014 \u05DC\u05D7\u05E5 \u05DB\u05D3\u05D9 \u05DC\u05D4\u05E4\u05E2\u05D9\u05DC/\u05DC\u05DB\u05D1\u05D5\u05EA:"),
 React.createElement("div", { style: { display: "flex", flexWrap: "wrap", gap: "0.4rem" } }, PERM_OPTIONS.map(function (opt) { var active = perms.includes(opt.id); return (React.createElement("button", { key: opt.id, onClick: function () { return togglePerm(id, opt.id); }, style: { background: active ? BLUE + "33" : "transparent", border: "1px solid " + (active ? BLUE : C.border), color: active ? BLUE : C.muted, padding: "0.3rem 0.75rem", borderRadius: "20px", fontSize: "0.8rem", fontWeight: active ? 700 : 400, cursor: "pointer" } },
 active ? "✓ " : "",
 opt.label)); }))))));
 }),
 members.length <= 1 && React.createElement("div", { style: { textAlign: "center", padding: "2rem", color: C.muted, fontSize: "0.85rem" } }, "\u05D0\u05D9\u05DF \u05D7\u05D1\u05E8\u05D9\u05DD \u05E0\u05D5\u05E1\u05E4\u05D9\u05DD"))));
}
function ClassBoardPhotos(_a) {
 var cls = _a.cls, isAdmin = _a.isAdmin, canAdd = _a.canAdd, updCls = _a.updCls;
 var photos = cls.boardPhotos || [];
 var photographers = cls.photographers || [];
 var _b = React.useState({ subject: "", date: "", imgData: null }), form = _b[0], setForm = _b[1];
 var _c = React.useState(false), adding = _c[0], setAdding = _c[1];
 var _d = React.useState(null), viewing = _d[0], setViewing = _d[1];
 var teal = "#38b2ac";
 var handleFile = function (e) { var f = e.target.files[0]; if (!f)
 return; var r = new FileReader(); r.onload = function (ev) { return setForm(function (x) { return (__assign(__assign({}, x), { imgData: ev.target.result })); }); }; r.readAsDataURL(f); };
 var addPhoto = function () { if (!form.imgData)
 return; var p = { id: genId(), subject: form.subject, date: form.date || new Date().toLocaleDateString("he-IL"), imgData: form.imgData, addedBy: "" }; updCls("boardPhotos", __spreadArray(__spreadArray([], photos, true), [p], false)); setForm({ subject: "", date: "", imgData: null }); setAdding(false); };
 var delPhoto = function (id) { return updCls("boardPhotos", photos.filter(function (p) { return p.id !== id; })); };
 var addPhotographer = function (name) { if (!name.trim() || photographers.includes(name.trim()))
 return; updCls("photographers", __spreadArray(__spreadArray([], photographers, true), [name.trim()], false)); };
 var removePhotographer = function (name) { return updCls("photographers", photographers.filter(function (p) { return p !== name; })); };
 var inp = { background: C.card, border: "1px solid ".concat(C.border), color: C.text, padding: "0.55rem 0.75rem", borderRadius: "8px", fontSize: "0.85rem", outline: "none", width: "100%" };
 return (React.createElement("div", null,
 React.createElement("div", { style: { display: "flex", alignItems: "center", gap: "0.75rem", marginBottom: "1rem", flexWrap: "wrap" } },
 React.createElement("h3", { style: { fontSize: "1rem", fontWeight: 700, margin: 0 } }, "\uD83D\uDCF7 \u05E6\u05D9\u05DC\u05D5\u05DE\u05D9 \u05DC\u05D5\u05D7"),
 canAdd && React.createElement("button", { onClick: function () { return setAdding(!adding); }, style: { background: adding ? teal + "33" : teal + "22", border: "1px solid ".concat(teal), color: teal, padding: "0.3rem 0.75rem", borderRadius: "8px", fontSize: "0.82rem", cursor: "pointer" } }, "+ \u05D4\u05D5\u05E1\u05E3 \u05EA\u05DE\u05D5\u05E0\u05D4")),
 adding && (React.createElement("div", { style: { background: C.card, border: "1px solid ".concat(teal, "44"), borderRadius: "14px", padding: "1rem", marginBottom: "1rem", display: "flex", flexDirection: "column", gap: "0.65rem" } },
 React.createElement("input", { style: inp, placeholder: "\u05E0\u05D5\u05E9\u05D0 (\u05DC\u05DE\u05E9\u05DC: \u05E4\u05E8\u05E7 3 - \u05DB\u05D5\u05D7\u05D5\u05EA)", value: form.subject, onChange: function (e) { return setForm(function (x) { return (__assign(__assign({}, x), { subject: e.target.value })); }); } }),
 React.createElement("input", { type: "date", style: inp, value: form.date, onChange: function (e) { return setForm(function (x) { return (__assign(__assign({}, x), { date: e.target.value })); }); } }),
 React.createElement("div", { style: { border: "2px dashed ".concat(form.imgData ? teal : C.border), borderRadius: "10px", padding: "1rem", textAlign: "center", cursor: "pointer" }, onClick: function () { return document.getElementById("photoInput").click(); } }, form.imgData ? React.createElement("img", { src: form.imgData, alt: "preview", style: { maxHeight: "180px", maxWidth: "100%", borderRadius: "8px" } }) : React.createElement("div", { style: { color: C.muted } }, "\uD83D\uDCC1 \u05DC\u05D7\u05E5 \u05DC\u05D1\u05D7\u05D9\u05E8\u05EA \u05EA\u05DE\u05D5\u05E0\u05D4")),
 React.createElement("input", { id: "photoInput", type: "file", accept: "image, callAI({ messages: [{ role: "user", content: prompt }], max_tokens: 2000 })];
 case 2:
 txt = _a.sent();
 clean = txt.replace(/```json|```/g, "").trim();
 qs = JSON.parse(clean);
 setQuestions(qs);
 return [3 , 4];
 case 3:
 e_4 = _a.sent();
 setQuestions([]);
 setAiError("שגיאה: " + e_4.message);
 return [3 , 4];
 case 4:
 setGenerating(false);
 return [2 ];
 }
 });
 }); };
 var getHint = function () { return __awaiter(_this, void 0, void 0, function () {
 var q, hintTxt;
 return __generator(this, function (_a) {
 switch (_a.label) {
 case 0:
 if (showHint)
 return [2 ];
 setLoading(true);
 q = questions[idx];
 return [4 , callAI({ messages: [{ role: "user", content: "תן רמז קצר (משפט אחד) לשאלה: " + q.q + ((user === null || user === void 0 ? void 0 : user.grade) ? " (תלמיד כיתה " + user.grade + ", התאם רמה)" : "") }], max_tokens: 100 })];
 case 1:
 hintTxt = _a.sent();
 setHint(q.hint || (hintTxt || ""));
 setShowHint(true);
 setLoading(false);
 return [2 ];
 }
 });
 }); };
 var submit = function () {
 if (!answer.trim())
 return;
 var q = questions[idx];
 var isC = qType === "multiple" ? answer === q.ans : answer.trim().length > 2;
 setCorrect(isC);
 setSubmitted(true);
 if (isC)
 setScore(function (s) { return s + 1; });
 setHistory(function (h) { return __spreadArray(__spreadArray([], h, true), [{ idx: idx, answer: answer, correct: isC }], false); });
 };
 var goTo = function (newIdx) {
 if (newIdx < 0 || newIdx >= questions.length)
 return;
 var prev = history.find(function (h) { return h.idx === newIdx; });
 setIdx(newIdx);
 setAnswer(prev ? prev.answer : "");
 setSubmitted(!!prev);
 setCorrect(prev ? prev.correct : null);
 setShowHint(false);
 setHint("");
 };
 if (questions.length === 0 && !generating)
 return (React.createElement("div", null,
 React.createElement("div", { style: { display: "flex", alignItems: "center", gap: "0.75rem", marginBottom: "1.5rem" } },
 React.createElement("button", { onClick: onBack, style: { background: "transparent", border: "1px solid ".concat(C.border), color: C.muted, padding: "0.35rem 0.7rem", borderRadius: "8px", fontSize: "0.85rem", cursor: "pointer" } }, "\u2190 \u05D7\u05D6\u05E8\u05D4"),
 React.createElement("h2", { style: { fontSize: "1.1rem", fontWeight: 700, margin: 0 } }, "\u270F\uFE0F \u05DE\u05D1\u05D7\u05DF AI")),
 React.createElement("div", { style: { background: C.card, border: "2px solid ".concat(AI, "44"), borderRadius: "20px", padding: "1.75rem", display: "flex", flexDirection: "column", gap: "1.1rem" } },
 React.createElement("div", { style: { textAlign: "center" } },
 React.createElement("div", { style: { fontSize: "2.5rem", marginBottom: "0.4rem" } }, "\u270F\uFE0F"),
 React.createElement("div", { style: { fontWeight: 700, fontSize: "1.1rem", color: AI } }, test.title),
 topics && React.createElement("div", { style: { fontSize: "0.78rem", color: C.muted, marginTop: "0.2rem" } },
 "\uD83D\uDCCB ",
 topics)),
 React.createElement("div", null,
 React.createElement("div", { style: { fontSize: "0.8rem", color: C.muted, fontWeight: 600, marginBottom: "0.5rem" } }, "\u05E8\u05DE\u05EA \u05E7\u05D5\u05E9\u05D9:"),
 React.createElement("div", { style: { display: "flex", gap: "0.5rem" } }, Object.entries(DIFF).map(function (_a) {
 var k = _a[0], v = _a[1];
 return (React.createElement("button", { key: k, onClick: function () { return setDifficulty(k); }, style: { flex: 1, background: difficulty === k ? diffColor[k] + "33" : "transparent", border: "1px solid ".concat(difficulty === k ? diffColor[k] : C.border), color: difficulty === k ? diffColor[k] : C.muted, padding: "0.5rem", borderRadius: "10px", fontSize: "0.85rem", fontWeight: difficulty === k ? 700 : 400, cursor: "pointer" } }, v));
 }))),
 React.createElement("div", null,
 React.createElement("div", { style: { fontSize: "0.8rem", color: C.muted, fontWeight: 600, marginBottom: "0.5rem" } }, "\u05E1\u05D5\u05D2 \u05E9\u05D0\u05DC\u05D5\u05EA:"),
 React.createElement("div", { style: { display: "flex", gap: "0.5rem" } },
 React.createElement("button", { onClick: function () { return setQType("multiple"); }, style: { flex: 1, background: qType === "multiple" ? AI + "33" : "transparent", border: "1px solid ".concat(qType === "multiple" ? AI : C.border), color: qType === "multiple" ? AI : C.muted, padding: "0.5rem", borderRadius: "10px", fontSize: "0.85rem", fontWeight: qType === "multiple" ? 700 : 400, cursor: "pointer" } }, "\uD83D\uDD18 \u05D0\u05DE\u05E8\u05D9\u05E7\u05D0\u05D9"),
 React.createElement("button", { onClick: function () { return setQType("open"); }, style: { flex: 1, background: qType === "open" ? AI + "33" : "transparent", border: "1px solid ".concat(qType === "open" ? AI : C.border), color: qType === "open" ? AI : C.muted, padding: "0.5rem", borderRadius: "10px", fontSize: "0.85rem", fontWeight: qType === "open" ? 700 : 400, cursor: "pointer" } }, "\u270D\uFE0F \u05E4\u05EA\u05D5\u05D7"))),
 React.createElement("button", { onClick: function () { setAiError(""); generateQuestions(); }, style: { background: C.accent, color: "#fff", border: "1px solid ".concat(AI), padding: "0.75rem", borderRadius: "12px", fontSize: "0.95rem", fontWeight: 700, cursor: "pointer" } }, "\uD83D\uDE80 \u05E6\u05D5\u05E8 \u05DE\u05D1\u05D7\u05DF"))));
 if (aiError)
 return (React.createElement("div", { style: { textAlign: "center", padding: "3rem 2rem" } },
 React.createElement("div", { style: { fontSize: "2.5rem", marginBottom: "1rem" } }, "\u274C"),
 React.createElement("div", { style: { color: "#fc8181", fontWeight: 600, marginBottom: "1rem" } }, aiError),
 React.createElement("button", { onClick: function () { return setAiError(""); }, style: { background: C.accent, color: "#fff", border: "none", padding: "0.6rem 1.5rem", borderRadius: "10px", cursor: "pointer" } }, "\u05E0\u05E1\u05D4 \u05E9\u05D5\u05D1")));
 if (generating)
 return (React.createElement("div", { style: { textAlign: "center", padding: "4rem 2rem" } },
 React.createElement("div", { style: { fontSize: "3rem", marginBottom: "1rem" } }, "\u23F3"),
 React.createElement("div", { style: { color: AI, fontWeight: 700, fontSize: "1.1rem" } }, "\u05DE\u05D9\u05D9\u05E6\u05E8 \u05E9\u05D0\u05DC\u05D5\u05EA..."),
 React.createElement("div", { style: { color: C.muted, fontSize: "0.85rem", marginTop: "0.5rem" } }, "\u05D6\u05D4 \u05D9\u05E7\u05D7 \u05DB\u05DE\u05D4 \u05E9\u05E0\u05D9\u05D5\u05EA")));
 var q = questions[idx];
 var done = idx >= questions.length;
 if (done)
 return (React.createElement("div", { style: { textAlign: "center", padding: "3rem" } },
 React.createElement("div", { style: { fontSize: "3rem", marginBottom: "1rem" } }, score / questions.length >= 0.8 ? "🎉" : "📚"),
 React.createElement("div", { style: { fontSize: "1.3rem", fontWeight: 700, marginBottom: "0.5rem" } },
 score,
 "/",
 questions.length,
 " \u05E0\u05DB\u05D5\u05DF"),
 React.createElement("div", { style: { color: C.muted, marginBottom: "1.5rem" } }, score / questions.length >= 0.8 ? "מצוין!" : score / questions.length >= 0.5 ? "טוב, המשך" : "כדאי לחזור שוב"),
 React.createElement("div", { style: { display: "flex", gap: "0.75rem", justifyContent: "center" } },
 React.createElement("button", { onClick: function () { setQuestions([]); setScore(0); setHistory([]); }, style: { background: AI, color: "#fff", border: "none", padding: "0.6rem 1.25rem", borderRadius: "10px", fontSize: "0.9rem", fontWeight: 600, cursor: "pointer" } }, "\uD83D\uDD04 \u05DE\u05D1\u05D7\u05DF \u05D7\u05D3\u05E9"),
 React.createElement("button", { onClick: onBack, style: { background: "transparent", border: "1px solid ".concat(C.border), color: C.text, padding: "0.6rem 1.25rem", borderRadius: "10px", fontSize: "0.9rem", cursor: "pointer" } }, "\u2190 \u05D7\u05D6\u05E8\u05D4"))));
 return (React.createElement("div", { style: { display: "flex", flexDirection: "column", gap: "0.75rem" } },
 React.createElement("div", { style: { display: "flex", alignItems: "center", justifyContent: "space-between", gap: "0.5rem", flexWrap: "wrap" } },
 React.createElement("div", { style: { display: "flex", alignItems: "center", gap: "0.5rem" } },
 React.createElement("span", { style: { fontWeight: 700, fontSize: "0.95rem", color: AI } },
 "\u05E9\u05D0\u05DC\u05D4 ",
 idx + 1,
 " \u05DE\u05EA\u05D5\u05DA ",
 questions.length),
 React.createElement("span", { style: { fontSize: "0.7rem", background: diffColor[difficulty] + "22", color: diffColor[difficulty], border: "1px solid ".concat(diffColor[difficulty], "44"), padding: "0.1rem 0.4rem", borderRadius: "20px" } }, DIFF[difficulty])),
 React.createElement("div", { style: { display: "flex", gap: "0.4rem", alignItems: "center" } },
 React.createElement("select", { value: difficulty, onChange: function (e) { setDifficulty(e.target.value); setQuestions([]); }, style: { background: C.card, border: "1px solid ".concat(C.border), color: C.text, padding: "0.25rem 0.4rem", borderRadius: "6px", fontSize: "0.75rem", outline: "none" } }, Object.entries(DIFF).map(function (_a) {
 var k = _a[0], v = _a[1];
 return React.createElement("option", { key: k, value: k }, v);
 })),
 React.createElement("select", { value: qType, onChange: function (e) { setQType(e.target.value); setQuestions([]); }, style: { background: C.card, border: "1px solid ".concat(C.border), color: C.text, padding: "0.25rem 0.4rem", borderRadius: "6px", fontSize: "0.75rem", outline: "none" } },
 React.createElement("option", { value: "multiple" }, "\u05D0\u05DE\u05E8\u05D9\u05E7\u05D0\u05D9"),
 React.createElement("option", { value: "open" }, "\u05E4\u05EA\u05D5\u05D7")))),
 React.createElement("div", { style: { height: "4px", background: C.border, borderRadius: "4px", overflow: "hidden" } },
 React.createElement("div", { style: { height: "100%", width: ((idx) / questions.length * 100) + "%", background: AI, borderRadius: "4px", transition: "width 0.3s" } })),
 React.createElement("div", { style: { background: C.card, border: "1px solid ".concat(C.border), borderRadius: "16px", padding: "1.25rem", minHeight: "80px" } },
 React.createElement("div", { style: { fontSize: "1rem", fontWeight: 600, lineHeight: 1.6 } }, q.q)),
 qType === "multiple" ? (React.createElement("div", { style: { display: "flex", flexDirection: "column", gap: "0.5rem" } }, (q.opts || []).map(function (opt, i) {
 var isSelected = answer === opt;
 var isCorrect = submitted && opt === q.ans;
 var isWrong = submitted && isSelected && !isCorrect;
 return (React.createElement("button", { key: i, onClick: function () { if (!submitted)
 setAnswer(opt); }, style: { background: isCorrect ? "#48bb7822" : isWrong ? "#fc818122" : isSelected ? AI + "22" : C.card, border: "1px solid ".concat(isCorrect ? C.green : isWrong ? "#fc8181" : isSelected ? AI : C.border), color: C.text, padding: "0.75rem 1rem", borderRadius: "12px", fontSize: "0.9rem", textAlign: "right", cursor: submitted ? "default" : "pointer", fontWeight: isCorrect || isSelected ? 600 : 400 } },
 isCorrect ? "✓ " : isWrong ? "✗ " : "",
 opt));
 }))) : (React.createElement("textarea", { value: answer, onChange: function (e) { if (!submitted)
 setAnswer(e.target.value); }, disabled: submitted, placeholder: "\u05DB\u05EA\u05D5\u05D1 \u05D0\u05EA \u05EA\u05E9\u05D5\u05D1\u05EA\u05DA \u05DB\u05D0\u05DF...", style: { background: C.card, border: "2px solid ".concat(submitted ? (correct ? C.green : "#fc8181") : C.border), color: C.text, padding: "0.85rem", borderRadius: "12px", fontSize: "0.9rem", outline: "none", width: "100%", minHeight: "100px", resize: "vertical", direction: "rtl" } })),
 submitted && (React.createElement("div", { style: { background: correct ? C.green + "22" : "#fc818122", border: "1px solid ".concat(correct ? C.green : "#fc8181"), borderRadius: "12px", padding: "0.75rem 1rem", color: correct ? C.green : "#fc8181", fontWeight: 600, fontSize: "0.9rem" } },
 correct ? "✓ נכון!" : "✗ לא נכון",
 !correct && q.ans && qType === "multiple" ? " — התשובה: " + q.ans : "",
 q.explain && React.createElement("div", { style: { fontSize: "0.82rem", fontWeight: 400, color: C.muted, marginTop: "0.3rem" } }, q.explain))),
 showHint && React.createElement("div", { style: { background: "#f6ad5522", border: "1px solid #f6ad5544", borderRadius: "10px", padding: "0.65rem 1rem", fontSize: "0.85rem", color: "#f6ad55" } },
 "\uD83D\uDCA1 ",
 hint),
 React.createElement("div", { style: { display: "flex", alignItems: "center", justifyContent: "space-between", marginTop: "0.25rem" } },
 React.createElement("div", { style: { display: "flex", gap: "0.5rem" } },
 React.createElement("button", { onClick: function () { return goTo(idx - 1); }, disabled: idx === 0, style: { background: "transparent", border: "1px solid ".concat(C.border), color: idx === 0 ? C.border : C.muted, padding: "0.5rem 1rem", borderRadius: "10px", fontSize: "0.85rem", cursor: idx === 0 ? "default" : "pointer" } }, "\u2190 \u05D0\u05D7\u05D5\u05E8\u05D4"),
 submitted && idx < questions.length - 1 && React.createElement("button", { onClick: function () { return goTo(idx + 1); }, style: { background: AI, color: "#fff", border: "none", padding: "0.5rem 1rem", borderRadius: "10px", fontSize: "0.85rem", fontWeight: 600, cursor: "pointer" } }, "\u05E7\u05D3\u05D9\u05DE\u05D4 \u2192"),
 submitted && idx === questions.length - 1 && React.createElement("button", { onClick: function () { return setIdx(questions.length); }, style: { background: C.green, color: "#fff", border: "none", padding: "0.5rem 1rem", borderRadius: "10px", fontSize: "0.85rem", fontWeight: 600, cursor: "pointer" } }, "\u05E1\u05D9\u05D5\u05DD \uD83C\uDF89")),
 React.createElement("div", { style: { display: "flex", gap: "0.5rem" } },
 !submitted && React.createElement("button", { onClick: getHint, disabled: loading || showHint, style: { background: "#f6ad5522", border: "1px solid #f6ad5544", color: "#f6ad55", padding: "0.5rem 0.9rem", borderRadius: "10px", fontSize: "0.85rem", cursor: loading || showHint ? "default" : "pointer", opacity: showHint ? 0.5 : 1 } }, "\uD83D\uDCA1 \u05E8\u05DE\u05D6"),
 !submitted && React.createElement("button", { onClick: submit, disabled: !answer.trim(), style: { background: AI, color: "#fff", border: "none", padding: "0.5rem 1.1rem", borderRadius: "10px", fontSize: "0.85rem", fontWeight: 600, cursor: "pointer", opacity: !answer.trim() ? 0.4 : 1 } }, "\u05D1\u05D3\u05D5\u05E7 \u2713")))));
}
function ExamAIMode(_a) {
 var _this = this;
 var initialTest = _a.test, onBack = _a.onBack, user = _a.user;
 var _b = React.useState(false), confirmed = _b[0], setConfirmed = _b[1];
 var _c = React.useState(initialTest.topics || ""), editedTopics = _c[0], setEditedTopics = _c[1];
 var _d = React.useState(initialTest.subject || ""), editedSubject = _d[0], setEditedSubject = _d[1];
 var _e = React.useState(false), editingSubject = _e[0], setEditingSubject = _e[1];
 var _f = React.useState(""), extraTopics = _f[0], setExtraTopics = _f[1];
 var _g = React.useState([]), messages = _g[0], setMessages = _g[1];
 var _h = React.useState(""), input = _h[0], setInput = _h[1];
 var _j = React.useState(false), loading = _j[0], setLoading = _j[1];
 var _k = React.useState(false), started = _k[0], setStarted = _k[1];
 var bottomRef = React.useRef(null);
 var AI = "#f6855a";
 var test = confirmed ? __assign(__assign({}, initialTest), { topics: [editedTopics, extraTopics].filter(Boolean).join(", ") || initialTest.topics }) : initialTest;
 var call = function (msgs) { return __awaiter(_this, void 0, void 0, function () { var raw, _a; return __generator(this, function (_b) {
 switch (_b.label) {
 case 0:
 setLoading(true);
 _b.label = 1;
 case 1:
 _b.trys.push([1, 3, 4, 5]);
 return [4 , callAI({ system: SYSTEM, messages: msgs.map(function (m) { return ({ role: m.role, content: m.text }); }), max_tokens: 1000 })];
 case 2:
 raw = _b.sent();
 return [2 , raw.replace(/#{1,6}\s?/g, "").replace(/\*\*(.+?)\*\*/g, "").replace(/\*(.+?)\*/g, "").replace(/^\s*[-•]\s/gm, "• ").trim()];
 case 3:
 _a = _b.sent();
 return [2 , "שגיאה בחיבור."];
 case 4:
 setLoading(false);
 return [7 ];
 case 5: return [2 ];
 }
 }); }); };
 var topics = [editedTopics, extraTopics].filter(Boolean).join(", ") || initialTest.topics || "";
 var gradeStr = (user === null || user === void 0 ? void 0 : user.grade) ? "כיתה " + user.grade : "";
 var SYSTEM = "אתה מורה AI שעוזר לתלמיד להתכונן למבחן." + (gradeStr ? "\\n" + getGradeInstructions(user) : "") + " מבחן: " + initialTest.title + ((editedSubject || initialTest.subject) ? "\nמקצוע: " + (editedSubject || initialTest.subject) : "\nמקצוע: לא צוין — שאל את התלמיד באיזה מקצוע מדובר") + (topics ? "\nנושאים: " + topics : "") + (initialTest.dueDate ? "\nתאריך: " + initialTest.dueDate : "") + "\n\nחוקים:\n- אל תשתמש ב-# * ** או markdown. כתוב טקסט רגיל.\n- אל תנחש מקצוע. אם לא צוין, שאל.\n- התאם רמת קושי לכיתה של התלמיד.\n- הסבר מפורט=4-6 משפטים, סיכום=4-5 נקודות, טיפים=1-2 משפטים, אחרת=2-3 משפטים.\n- בסוף כל תשובה הוסף שאלה קצרה.\n- אם הנושאים שהתלמיד כתב לא ברורים לגמרי, מותר לשאול שאלת הבהרה אחת בלבד — רק אם באמת נחוץ. אל תשאל שאלות הבהרה כדרך שגרה.\nדבר בעברית ידידותית.";
 var _l = React.useState([]), selected = _l[0], setSelected = _l[1];
 var _m = React.useState(false), quizMode = _m[0], setQuizMode = _m[1];
 var _o = React.useState(false), flashcardMode = _o[0], setFlashcardMode = _o[1];
 var _p = React.useState([]), flashcards = _p[0], setFlashcards = _p[1];
 var _q = React.useState(0), fcIndex = _q[0], setFcIndex = _q[1];
 var _r = React.useState(false), fcFlipped = _r[0], setFcFlipped = _r[1];
 var OPTIONS = [
 { id: "explain", label: "📖 הסבר מפורט", text: "תן לי הסבר מפורט על החומר" },
 { id: "quiz", label: "✏️ מבחן", text: "" },
 { id: "summary", label: "📋 סיכום נושאים", text: "תסכם לי את הנושאים העיקריים" },
 { id: "tips", label: "💡 טיפים למבחן", text: "תן לי טיפים איך לגשת למבחן" },
 ];
 var _s = React.useState(""), customText = _s[0], setCustomText = _s[1];
 var _t = React.useState([]), chosenOptions = _t[0], setChosenOptions = _t[1];
 var _u = React.useState(false), topicScreen = _u[0], setTopicScreen = _u[1];
 var _v = React.useState(""), selectedTopic = _v[0], setSelectedTopic = _v[1];
 var toggleOption = function (id) { return setSelected(function (s) { return s.includes(id) ? s.filter(function (x) { return x !== id; }) : __spreadArray(__spreadArray([], s, true), [id], false); }); };
 var _w = React.useState([]), pendingChoices = _w[0], setPendingChoices = _w[1];
 var topicsList = topics ? topics.split(/[,،\n]/).map(function (t) { return t.trim(); }).filter(Boolean) : [];
 var startWithChoices = function () { return __awaiter(_this, void 0, void 0, function () {
 var chosen, hasQuiz, allChosen;
 return __generator(this, function (_a) {
 chosen = OPTIONS.filter(function (o) { return selected.includes(o.id) && o.id !== "quiz"; });
 if (customText.trim())
 chosen.push({ id: "custom", label: customText.trim(), text: customText.trim() });
 hasQuiz = selected.includes("quiz");
 if (hasQuiz && chosen.length === 0) {
 setQuizMode(true);
 setStarted(true);
 return [2 ];
 }
 if (!hasQuiz && chosen.length === 0)
 return [2 ];
 allChosen = __spreadArray(__spreadArray([], chosen, true), (hasQuiz ? [{ id: "quiz", label: "✏️ מבחן", text: "quiz" }] : []), true);
 setChosenOptions(allChosen);
 if (allChosen.length > 1) {
 setTopicScreen(true);
 }
 else {
 launchChat(allChosen, allChosen[0]);
 }
 return [2 ];
 });
 }); };
 var parseFlashcards = function (text) {
 var lines = text.split("\n").filter(function (l) { return l.includes("שאלה:") && l.includes("תשובה:"); });
 return lines.map(function (l, i) {
 var q = (l.match(/שאלה:\s*([^|]+)/) || [])[1];
 var a = (l.match(/תשובה:\s*(.+)/) || [])[1];
 return { id: i, q: (q || l).trim(), a: (a || "").trim() };
 });
 };
 var launchChat = function (chosen, first) { return __awaiter(_this, void 0, void 0, function () {
 var remaining, t;
 return __generator(this, function (_a) {
 switch (_a.label) {
 case 0:
 setTopicScreen(false);
 setStarted(true);
 if (first.id === "quiz") {
 setQuizMode(true);
 return [2 ];
 }
 remaining = chosen.filter(function (c) { return c.id !== first.id; });
 setPendingChoices(remaining);
 return [4 , call([{ role: "user", text: first.text }])];
 case 1:
 t = _a.sent();
 setMessages([{ role: "assistant", text: t, remaining: remaining.length > 0 ? remaining : null }]);
 return [2 ];
 }
 });
 }); };
 var pickChoice = function (choice) { return __awaiter(_this, void 0, void 0, function () {
 var remaining, m, t, newMsg, cards;
 return __generator(this, function (_a) {
 switch (_a.label) {
 case 0:
 setPendingChoices([]);
 remaining = pendingChoices.filter(function (c) { return c.id !== choice.id; });
 m = [{ role: "user", text: choice.text }];
 setMessages(function (prev) { return __spreadArray(__spreadArray([], prev, true), [{ role: "user", text: choice.label }], false); });
 return [4 , call(m)];
 case 1:
 t = _a.sent();
 newMsg = { role: "assistant", text: t, remaining: remaining.length > 0 ? remaining : null };
 setMessages(function (prev) { return __spreadArray(__spreadArray([], prev, true), [newMsg], false); });
 if (first.id === "flashcards") {
 cards = parseFlashcards(t);
 if (cards.length > 0) {
 setFlashcards(cards);
 setFlashcardMode(true);
 }
 }
 return [2 ];
 }
 });
 }); };
 var send = function () { return __awaiter(_this, void 0, void 0, function () { var m, t; return __generator(this, function (_a) {
 switch (_a.label) {
 case 0:
 if (!input.trim() || loading)
 return [2 ];
 m = __spreadArray(__spreadArray([], messages, true), [{ role: "user", text: input.trim() }], false);
 setMessages(m);
 setInput("");
 return [4 , call(m)];
 case 1:
 t = _a.sent();
 setMessages(function (x) { return __spreadArray(__spreadArray([], x, true), [{ role: "assistant", text: t }], false); });
 return [2 ];
 }
 }); }); };
 React.useEffect(function () { var _a; return (_a = bottomRef.current) === null || _a === void 0 ? void 0 : _a.scrollIntoView({ behavior: "smooth" }); }, [messages, loading]);
 if (!confirmed) {
 var inp = { background: C.card, border: "1px solid ".concat(C.border), color: "#fff", padding: "0.65rem 0.85rem", borderRadius: "10px", fontSize: "0.88rem", outline: "none", width: "100%" };
 var canConfirm_1 = editedSubject.trim() || initialTest.subject;
 return (React.createElement("div", null,
 React.createElement("div", { style: { display: "flex", alignItems: "center", gap: "0.75rem", marginBottom: "1.5rem" } },
 React.createElement("button", { onClick: onBack, style: { background: "transparent", border: "1px solid ".concat(C.border), color: C.muted, padding: "0.35rem 0.7rem", borderRadius: "8px", fontSize: "0.85rem", cursor: "pointer" } }, "\u2190 \u05D7\u05D6\u05E8\u05D4"),
 React.createElement("h2", { style: { fontSize: "1.1rem", fontWeight: 700, margin: 0 } }, "\uD83D\uDCCB \u05D0\u05D9\u05E9\u05D5\u05E8 \u05E0\u05D5\u05E9\u05D0\u05D9\u05DD")),
 React.createElement("div", { style: { background: C.card, border: "2px solid ".concat(AI, "44"), borderRadius: "20px", padding: "1.5rem", display: "flex", flexDirection: "column", gap: "1rem" } },
 React.createElement("div", { style: { textAlign: "center" } },
 React.createElement("div", { style: { fontSize: "2.5rem" } }, "\uD83D\uDCCB"),
 React.createElement("div", { style: { fontWeight: 700, color: AI, fontSize: "1.05rem" } }, initialTest.title)),
 React.createElement("div", null,
 React.createElement("div", { style: { fontSize: "0.8rem", color: C.muted, marginBottom: "0.4rem", fontWeight: 600 } }, "\u05E0\u05D5\u05E9\u05D0\u05D9\u05DD \u05E0\u05D5\u05DB\u05D7\u05D9\u05D9\u05DD:"),
 editedTopics ? React.createElement("div", { style: { background: C.border + "44", borderRadius: "8px", padding: "0.55rem 0.85rem", fontSize: "0.85rem", color: C.text } }, editedTopics) : React.createElement("div", { style: { fontSize: "0.82rem", color: C.muted } }, "\u05DC\u05D0 \u05E6\u05D5\u05D9\u05E0\u05D5 \u05E0\u05D5\u05E9\u05D0\u05D9\u05DD")),
 React.createElement("div", null,
 React.createElement("div", { style: { fontSize: "0.8rem", color: C.muted, marginBottom: "0.4rem", fontWeight: 600 } }, "\u2795 \u05D4\u05D5\u05E1\u05E3 \u05E0\u05D5\u05E9\u05D0\u05D9\u05DD:"),
 React.createElement("textarea", { value: extraTopics, onChange: function (e) { return setExtraTopics(e.target.value); }, style: __assign(__assign({}, inp), { minHeight: "55px" }), placeholder: "\u05E0\u05D5\u05E9\u05D0\u05D9\u05DD \u05E0\u05D5\u05E1\u05E4\u05D9\u05DD..." })),
 React.createElement("div", null,
 React.createElement("div", { style: { fontSize: "0.8rem", color: C.muted, marginBottom: "0.4rem", fontWeight: 600 } }, "\uD83D\uDCDA \u05DE\u05E7\u05E6\u05D5\u05E2:"),
 initialTest.subject
 ? React.createElement("div", null,
 React.createElement("div", { style: { display: "flex", alignItems: "center", gap: "0.5rem" } },
 React.createElement("div", { style: { flex: 1, background: C.border + "44", borderRadius: "8px", padding: "0.55rem 0.85rem", fontSize: "0.9rem", color: AI, fontWeight: 600 } }, editedSubject || initialTest.subject),
 React.createElement("button", { onClick: function () { return setEditingSubject(function (s) { return !s; }); }, style: { background: "transparent", border: "1px solid ".concat(C.border), color: C.muted, padding: "0.25rem 0.5rem", borderRadius: "6px", fontSize: "0.72rem", cursor: "pointer", flexShrink: 0 } }, "\u270F\uFE0F \u05E9\u05E0\u05D4")),
 editingSubject && React.createElement("input", { value: editedSubject, onChange: function (e) { return setEditedSubject(e.target.value); }, style: __assign(__assign({}, inp), { marginTop: "0.4rem" }), placeholder: "\u05E8\u05E9\u05D5\u05DD \u05DE\u05E7\u05E6\u05D5\u05E2 \u05D7\u05D3\u05E9..." }))
 : React.createElement("input", { value: editedSubject, onChange: function (e) { return setEditedSubject(e.target.value); }, placeholder: "\u05E8\u05E9\u05D5\u05DD \u05DE\u05E7\u05E6\u05D5\u05E2 (\u05DC\u05DE\u05E9\u05DC: \u05D4\u05D9\u05E1\u05D8\u05D5\u05E8\u05D9\u05D4, \u05D0\u05E0\u05D2\u05DC\u05D9\u05EA...)", style: inp })),
 React.createElement("button", { onClick: function () { if (!canConfirm_1)
 return; setConfirmed(true); }, disabled: !canConfirm_1, style: { background: canConfirm_1 ? C.accent : "#555", color: "#fff", border: "1px solid ".concat(AI), padding: "0.75rem", borderRadius: "12px", fontSize: "0.95rem", fontWeight: 700, cursor: canConfirm_1 ? "pointer" : "default", opacity: canConfirm_1 ? 1 : 0.4 } }, "\u05D0\u05D9\u05E9\u05D5\u05E8 \u2713"))));
 }
 if (topicScreen) {
 return (React.createElement("div", null,
 React.createElement("div", { style: { display: "flex", alignItems: "center", gap: "0.75rem", marginBottom: "1.5rem" } },
 React.createElement("button", { onClick: function () { return setTopicScreen(false); }, style: { background: "transparent", border: "1px solid ".concat(C.border), color: C.muted, padding: "0.35rem 0.7rem", borderRadius: "8px", fontSize: "0.85rem", cursor: "pointer" } }, "\u2190 \u05D7\u05D6\u05E8\u05D4"),
 React.createElement("h2", { style: { fontSize: "1.1rem", fontWeight: 700, margin: 0, color: C.text } }, "\u05D1\u05DE\u05D4 \u05EA\u05E8\u05E6\u05D4 \u05DC\u05D4\u05EA\u05D7\u05D9\u05DC \u05E7\u05D5\u05D3\u05DD?")),
 React.createElement("div", { style: { background: C.card, border: "2px solid ".concat(AI, "44"), borderRadius: "20px", padding: "1.75rem", display: "flex", flexDirection: "column", gap: "0.6rem" } },
 React.createElement("div", { style: { fontSize: "0.85rem", color: C.muted, marginBottom: "0.25rem" } }, "\u05D1\u05D7\u05E8 \u05DE\u05D0\u05D9\u05E4\u05D4 \u05DC\u05D4\u05EA\u05D7\u05D9\u05DC:"),
 chosenOptions.map(function (opt) { return (React.createElement("button", { key: opt.id, onClick: function () { return launchChat(chosenOptions, opt); }, style: { background: "transparent", border: "1px solid ".concat(C.border), color: C.text, padding: "0.7rem 1rem", borderRadius: "12px", fontSize: "0.9rem", textAlign: "right", cursor: "pointer", transition: "all 0.15s" }, onMouseEnter: function (e) { e.currentTarget.style.border = "1px solid ".concat(AI); e.currentTarget.style.color = AI; }, onMouseLeave: function (e) { e.currentTarget.style.border = "1px solid ".concat(C.border); e.currentTarget.style.color = C.text; } }, opt.label)); }))));
 }
 if (!started) {
 return (React.createElement("div", null,
 React.createElement("div", { style: { display: "flex", alignItems: "center", gap: "0.75rem", marginBottom: "1.5rem" } },
 React.createElement("button", { onClick: onBack, style: { background: "transparent", border: "1px solid ".concat(C.border), color: C.muted, padding: "0.35rem 0.7rem", borderRadius: "8px", fontSize: "0.85rem", cursor: "pointer" } }, "\u2190 \u05D7\u05D6\u05E8\u05D4"),
 React.createElement("h2", { style: { fontSize: "1.1rem", fontWeight: 700, margin: 0 } }, "\uD83E\uDDE0 \u05D4\u05DB\u05E0\u05D4 \u05DC\u05DE\u05D1\u05D7\u05DF \u05E2\u05DD AI")),
 React.createElement("div", { style: { background: C.card, border: "2px solid ".concat(AI, "44"), borderRadius: "20px", padding: "2rem", textAlign: "center" } },
 React.createElement("div", { style: { fontSize: "3rem", marginBottom: "0.75rem" } }, "\uD83E\uDDE0"),
 React.createElement("div", { style: { fontSize: "1.2rem", fontWeight: 700, color: AI, marginBottom: "0.5rem" } }, "\u05DE\u05D5\u05E8\u05D4 AI \u05D0\u05D9\u05E9\u05D9"),
 React.createElement("div", { style: { background: C.border + "44", borderRadius: "12px", padding: "0.85rem 1rem", marginBottom: "1.5rem", textAlign: "right" } },
 React.createElement("div", { style: { fontWeight: 700 } }, test.title),
 test.topics && React.createElement("div", { style: { fontSize: "0.8rem", color: AI, marginTop: "0.3rem" } },
 "\uD83D\uDCCB ",
 test.topics),
 test.dueDate && React.createElement("div", { style: { fontSize: "0.8rem", color: C.muted, marginTop: "0.2rem" } },
 "\uD83D\uDCC5 ",
 test.dueDate)),
 React.createElement("div", { style: { fontSize: "0.88rem", color: C.text, marginBottom: "0.75rem" } }, "\u05D1\u05D7\u05E8 \u05DE\u05D4 \u05EA\u05E8\u05E6\u05D4 (\u05D0\u05E4\u05E9\u05E8 \u05DB\u05DE\u05D4):"),
 React.createElement("div", { style: { display: "flex", flexWrap: "wrap", gap: "0.5rem", marginBottom: "0.75rem" } }, OPTIONS.map(function (opt) {
 var active = selected.includes(opt.id);
 return React.createElement("button", { key: opt.id, onClick: function () { return toggleOption(opt.id); }, style: { background: active ? AI + "33" : C.card, border: "1px solid ".concat(active ? AI : C.border), color: active ? AI : C.text, padding: "0.5rem 0.9rem", borderRadius: "20px", fontSize: "0.85rem", fontWeight: active ? 700 : 400, cursor: "pointer" } },
 active ? "✓ " : "",
 opt.label);
 })),
 React.createElement("div", { style: { display: "flex", gap: "0.5rem", marginBottom: "0.75rem" } },
 React.createElement("input", { value: customText, onChange: function (e) { return setCustomText(e.target.value); }, placeholder: "\u05DE\u05E9\u05D4\u05D5 \u05D0\u05D7\u05E8...", style: { flex: 1, background: C.card, border: "1px solid ".concat(C.border), color: C.text, padding: "0.55rem 0.85rem", borderRadius: "10px", fontSize: "0.85rem", outline: "none" }, onKeyDown: function (e) { return e.key === "Enter" && startWithChoices(); } })),
 React.createElement("button", { onClick: startWithChoices, disabled: selected.length === 0 && !customText.trim(), style: { background: C.accent, color: "#fff", border: "1px solid ".concat(AI), padding: "0.65rem", borderRadius: "12px", fontSize: "0.95rem", fontWeight: 700, cursor: "pointer", width: "100%", opacity: selected.length === 0 && !customText.trim() ? 0.4 : 1 } }, "\uD83D\uDE80 \u05D4\u05EA\u05D7\u05DC \u05E6\u05F3\u05D0\u05D8"))));
 }
 if (started && flashcardMode && flashcards.length > 0)
 return (React.createElement("div", { style: { padding: "0.5rem" } },
 React.createElement("div", { style: { display: "flex", alignItems: "center", gap: "0.75rem", marginBottom: "1.5rem" } },
 React.createElement("button", { onClick: function () { setFlashcardMode(false); setFlashcards([]); setFcIndex(0); setFcFlipped(false); setStarted(false); setSelected([]); }, style: { background: "transparent", border: "1px solid ".concat(C.border), color: C.muted, padding: "0.35rem 0.7rem", borderRadius: "8px", fontSize: "0.85rem", cursor: "pointer" } }, "\u2190 \u05D7\u05D6\u05E8\u05D4"),
 React.createElement("h2", { style: { fontSize: "1.1rem", fontWeight: 700, margin: 0, color: C.text } }, "\uD83D\uDCDD \u05DB\u05E8\u05D8\u05D9\u05E1\u05D9\u05D5\u05EA \u05E9\u05D9\u05E0\u05D5\u05DF"),
 React.createElement("span", { style: { fontSize: "0.82rem", color: C.muted, marginRight: "auto" } },
 fcIndex + 1,
 " / ",
 flashcards.length)),
 React.createElement("div", { style: { display: "flex", justifyContent: "center", marginBottom: "1.5rem" } },
 React.createElement("div", { onClick: function () { return setFcFlipped(function (v) { return !v; }); }, style: { width: "100%", maxWidth: "480px", minHeight: "200px", background: fcFlipped ? AI + "22" : C.card, border: "2px solid ".concat(fcFlipped ? AI : C.border), borderRadius: "20px", padding: "2rem", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", cursor: "pointer", transition: "all 0.2s", textAlign: "center" } },
 React.createElement("div", { style: { fontSize: "0.72rem", color: C.muted, marginBottom: "0.75rem", fontWeight: 600 } }, fcFlipped ? "✅ תשובה" : "❓ שאלה — לחץ להפוך"),
 React.createElement("div", { style: { fontSize: "1.05rem", fontWeight: fcFlipped ? 400 : 700, color: fcFlipped ? AI : C.text, lineHeight: 1.5 } }, fcFlipped ? flashcards[fcIndex].a : flashcards[fcIndex].q))),
 React.createElement("div", { style: { display: "flex", gap: "0.75rem", justifyContent: "center" } },
 React.createElement("button", { onClick: function () { setFcIndex(function (i) { return Math.max(0, i - 1); }); setFcFlipped(false); }, disabled: fcIndex === 0, style: { padding: "0.5rem 1.5rem", borderRadius: "10px", border: "1px solid ".concat(C.border), background: "transparent", color: fcIndex === 0 ? C.muted : C.text, cursor: fcIndex === 0 ? "default" : "pointer", fontSize: "0.9rem" } }, "\u2190 \u05D4\u05E7\u05D5\u05D3\u05DE\u05EA"),
 React.createElement("button", { onClick: function () { setFcFlipped(false); if (fcIndex + 1 < flashcards.length)
 setFcIndex(function (i) { return i + 1; }); }, style: { padding: "0.5rem 1.5rem", borderRadius: "10px", border: "1px solid ".concat(AI), background: AI + "22", color: AI, cursor: "pointer", fontSize: "0.9rem", fontWeight: 600 } }, fcIndex + 1 < flashcards.length ? "הבאה →" : "סיום 🎉")),
 React.createElement("div", { style: { display: "flex", gap: "0.4rem", justifyContent: "center", marginTop: "1rem", flexWrap: "wrap" } }, flashcards.map(function (fc, idx) { return (React.createElement("button", { key: fc.id, onClick: function () { setFcIndex(idx); setFcFlipped(false); }, style: { width: "28px", height: "28px", borderRadius: "50%", border: "1px solid ".concat(idx === fcIndex ? AI : C.border), background: idx === fcIndex ? AI + "33" : "transparent", color: idx === fcIndex ? AI : C.muted, fontSize: "0.72rem", cursor: "pointer" } }, idx + 1)); }))));
 if (started && quizMode)
 return React.createElement(AIQuizMode, { test: initialTest, topics: topics, onBack: function () { setStarted(false); setQuizMode(false); setSelected([]); }, user: user });
 return (React.createElement("div", { style: { display: "flex", flexDirection: "column", height: "calc(100vh - 120px)", maxHeight: "700px" } },
 React.createElement("div", { style: { display: "flex", alignItems: "center", justifyContent: "space-between", gap: "0.6rem", marginBottom: "0.75rem", flexShrink: 0 } },
 React.createElement("div", { style: { display: "flex", alignItems: "center", gap: "0.6rem" } },
 React.createElement("button", { onClick: onBack, style: { background: "transparent", border: "1px solid ".concat(C.border), color: C.muted, padding: "0.35rem 0.7rem", borderRadius: "8px", fontSize: "0.82rem", cursor: "pointer" } }, "\u2190 \u05D7\u05D6\u05E8\u05D4"),
 React.createElement("span", { style: { fontWeight: 700, color: AI } },
 "\uD83E\uDDE0 ",
 test.title)),
 React.createElement("button", { onClick: function () { setStarted(false); setMessages([]); setSelected([]); setPendingChoices([]); }, style: { background: "transparent", border: "1px solid ".concat(AI, "44"), color: AI, padding: "0.3rem 0.7rem", borderRadius: "8px", fontSize: "0.78rem", cursor: "pointer" } }, "\uD83D\uDD04 \u05E9\u05E0\u05D4 \u05D3\u05E8\u05DA \u05DC\u05DE\u05D9\u05D3\u05D4")),
 React.createElement("div", { style: { flex: 1, overflowY: "auto", display: "flex", flexDirection: "column", gap: "0.75rem", padding: "0.5rem 0" } },
 messages.map(function (m, i) { return (React.createElement("div", { key: i, style: { display: "flex", justifyContent: m.role === "user" ? "flex-start" : "flex-end", flexDirection: "column", alignItems: m.role === "user" ? "flex-start" : "flex-end" } },
 React.createElement("div", { style: { maxWidth: "85%", background: m.role === "user" ? C.card : "linear-gradient(135deg,".concat(C.accent, "33,").concat(C.accent, "22)"), border: "1px solid ".concat(m.role === "user" ? C.border : AI + "44"), borderRadius: "14px", padding: "0.75rem 1rem", fontSize: "0.88rem", lineHeight: 1.6, whiteSpace: "pre-wrap", color: C.text } }, m.text),
 m.choices && pendingChoices.length > 0 && (React.createElement("div", { style: { display: "flex", flexWrap: "wrap", gap: "0.4rem", marginTop: "0.5rem", justifyContent: "flex-end" } }, m.choices.map(function (ch) { return (React.createElement("button", { key: ch.id, onClick: function () { return pickChoice(ch); }, style: { background: C.card, border: "1px solid ".concat(AI), color: AI, padding: "0.4rem 0.9rem", borderRadius: "20px", fontSize: "0.83rem", fontWeight: 600, cursor: "pointer" } }, ch.label)); }))))); }),
 loading && React.createElement("div", { style: { display: "flex", justifyContent: "flex-end" } },
 React.createElement("div", { style: { background: "linear-gradient(135deg,${C.accent}33,${C.accent}22)", border: "1px solid ".concat(AI, "44"), borderRadius: "14px", padding: "0.75rem 1rem", color: AI } }, "\u23F3 \u05D7\u05D5\u05E9\u05D1...")),
 React.createElement("div", { ref: bottomRef })),
 React.createElement("div", { style: { display: "flex", gap: "0.5rem", marginTop: "0.75rem", flexShrink: 0 } },
 React.createElement("input", { value: input, onChange: function (e) { return setInput(e.target.value); }, onKeyDown: function (e) { return e.key === "Enter" && !e.shiftKey && send(); }, placeholder: "\u05E9\u05D0\u05DC \u05E9\u05D0\u05DC\u05D4...", style: { flex: 1, background: C.card, border: "1px solid ".concat(C.border), color: C.text, padding: "0.65rem 1rem", borderRadius: "12px", fontSize: "0.88rem", outline: "none" } }),
 React.createElement("button", { onClick: send, disabled: loading || !input.trim(), style: { background: AI, color: "#fff", border: "none", padding: "0.65rem 1rem", borderRadius: "12px", fontSize: "0.9rem", cursor: "pointer", opacity: loading || !input.trim() ? 0.5 : 1 } }, "\u27A4"))));
}
function SetRow(_a) {
 var set = _a.set, onOpen = _a.onOpen, onEdit = _a.onEdit, onDelete = _a.onDelete, clsName = _a.clsName, readonly = _a.readonly;
 return (React.createElement("div", { style: { background: C.card, border: "1px solid ".concat(clsName ? "#f6ad5544" : C.border), borderRadius: "12px", padding: "0.9rem 1rem", display: "flex", alignItems: "center", gap: "1rem", flexWrap: "wrap" } },
 React.createElement("div", { onClick: onOpen, style: { flex: 1, minWidth: 0, cursor: "pointer" } },
 clsName && React.createElement("div", { style: { fontSize: "0.68rem", color: "#f6ad55", fontWeight: 600, marginBottom: "0.15rem" } },
 "\uD83C\uDFEB ",
 clsName),
 React.createElement("div", { style: { fontWeight: 600, fontSize: "0.92rem" } }, set.name),
 React.createElement("div", { style: { fontSize: "0.75rem", color: C.muted, marginTop: "0.1rem" } },
 (set.pairs || []).length,
 " \u05DE\u05D9\u05DC\u05D9\u05DD")),
 React.createElement("div", { style: { display: "flex", gap: "0.35rem", flexShrink: 0 } },
 !readonly && onEdit && React.createElement("button", { onClick: function (e) { e.stopPropagation(); onEdit(); }, style: { background: "".concat(C.accent, "22"), border: "1px solid ".concat(C.accent), color: C.accent, padding: "0.3rem 0.65rem", borderRadius: "8px", fontSize: "0.8rem", cursor: "pointer" } }, "\u270F\uFE0F \u05E2\u05E8\u05D5\u05DA"),
 !readonly && onDelete && React.createElement("button", { onClick: function (e) { e.stopPropagation(); if (window.confirm("למחוק?"))
 onDelete(); }, style: { background: "#c5303022", border: "1px solid #c53030", color: "#fc8181", padding: "0.3rem 0.65rem", borderRadius: "8px", fontSize: "0.8rem", cursor: "pointer" } }, "\uD83D\uDDD1\uFE0F"))));
}
function ClassDictation(_a) {
 var sets = _a.sets, isAdmin = _a.isAdmin, onSave = _a.onSave, onDelete = _a.onDelete, clsName = _a.clsName;
 var _b = React.useState(null), editing = _b[0], setEditing = _b[1];
 if (editing)
 return React.createElement(SetEditor, { set: editing, onSave: function (s) { onSave(s); setEditing(null); }, onBack: function () { return setEditing(null); } });
 return (React.createElement("div", null,
 React.createElement("div", { style: { display: "flex", alignItems: "center", gap: "0.75rem", marginBottom: "1rem", flexWrap: "wrap" } },
 React.createElement("h3", { style: { fontSize: "1rem", fontWeight: 700, margin: 0 } }, "\uD83D\uDCD6 \u05E2\u05E8\u05DB\u05D5\u05EA \u05D4\u05DB\u05EA\u05D1\u05D4"),
 isAdmin && React.createElement("button", { onClick: function () { return setEditing({ id: genId(), name: "ערכה חדשה", pairs: [], createdAt: Date.now() }); }, style: { background: C.accent + "22", border: "1px solid ".concat(C.accent), color: C.accent, padding: "0.3rem 0.75rem", borderRadius: "8px", fontSize: "0.82rem", cursor: "pointer" } }, "+ \u05E2\u05E8\u05DB\u05D4 \u05D7\u05D3\u05E9\u05D4")),
 sets.length === 0 && React.createElement("div", { style: { textAlign: "center", padding: "2rem", color: C.muted } },
 "\u05D0\u05D9\u05DF \u05E2\u05E8\u05DB\u05D5\u05EA \u05E2\u05D3\u05D9\u05D9\u05DF",
 isAdmin ? " — לחץ + כדי ליצור" : ""),
 React.createElement("div", { style: { display: "flex", flexDirection: "column", gap: "0.6rem" } }, sets.map(function (set) { return (React.createElement("div", { key: set.id, style: { background: C.card, border: "1px solid ".concat(C.border), borderRadius: "12px", padding: "0.9rem 1rem", display: "flex", alignItems: "center", gap: "1rem", flexWrap: "wrap" } },
 React.createElement("div", { style: { flex: 1 } },
 React.createElement("div", { style: { fontWeight: 600 } }, set.name),
 React.createElement("div", { style: { fontSize: "0.75rem", color: C.muted } },
 (set.pairs || []).length,
 " \u05DE\u05D9\u05DC\u05D9\u05DD")),
 React.createElement("div", { style: { display: "flex", gap: "0.35rem", flexWrap: "wrap" } },
 isAdmin && React.createElement("button", { onClick: function () { return setEditing(__assign({}, set)); }, style: { background: "".concat(C.accent, "22"), border: "1px solid ".concat(C.accent), color: C.accent, padding: "0.3rem 0.65rem", borderRadius: "8px", fontSize: "0.8rem", cursor: "pointer" } }, "\u270F\uFE0F \u05E2\u05E8\u05D5\u05DA"),
 isAdmin && React.createElement("button", { onClick: function () { if (window.confirm("למחוק?"))
 onDelete(set.id); }, style: { background: "#c5303022", border: "1px solid #c53030", color: "#fc8181", padding: "0.3rem 0.65rem", borderRadius: "8px", fontSize: "0.8rem", cursor: "pointer" } }, "\uD83D\uDDD1\uFE0F")))); }))));
}
function AILearnMode(_a) {
 var _this = this;
 var set = _a.set, onBack = _a.onBack, user = _a.user;
 var _b = React.useState([]), messages = _b[0], setMessages = _b[1];
 var _c = React.useState(""), input = _c[0], setInput = _c[1];
 var _d = React.useState(false), loading = _d[0], setLoading = _d[1];
 var _e = React.useState(false), started = _e[0], setStarted = _e[1];
 var bottomRef = React.useRef(null);
 var AI = "#b393d3";
 var gradeStr = (user === null || user === void 0 ? void 0 : user.grade) ? "כיתה " + user.grade : "";
 var SYSTEM = "אתה מורה מקצועי. עזור לתלמיד ללמוד ערכת מילים בעברית." + (gradeStr ? "\\n" + getGradeInstructions(user) : "") + "\\nערכה: " + set.name + "\\nמילים: " + ((set.pairs || []).map(function (p) { return p.en + "=" + p.he; }).join(", ")) + "\\nשאל שאלה אחת בכל פעם, חכה לתשובה, ותן משוב.";
 var call = function (msgs) { return __awaiter(_this, void 0, void 0, function () { var raw, _a; return __generator(this, function (_b) {
 switch (_b.label) {
 case 0:
 setLoading(true);
 _b.label = 1;
 case 1:
 _b.trys.push([1, 3, 4, 5]);
 return [4 , callAI({ system: SYSTEM, messages: msgs.map(function (m) { return ({ role: m.role, content: m.text }); }), max_tokens: 500 })];
 case 2:
 raw = _b.sent();
 return [2 , raw.replace(/#{1,6}\s?/g, "").replace(/\*\*(.+?)\*\*/g, "").replace(/\*(.+?)\*/g, "").replace(/^\s*[-•]\s/gm, "• ").trim()];
 case 3:
 _a = _b.sent();
 return [2 , "שגיאה בחיבור."];
 case 4:
 setLoading(false);
 return [7 ];
 case 5: return [2 ];
 }
 }); }); };
 var start = function () { return __awaiter(_this, void 0, void 0, function () { var t; return __generator(this, function (_a) {
 switch (_a.label) {
 case 0:
 setStarted(true);
 return [4 , call([{ role: "user", text: "התחל ללמד אותי" }])];
 case 1:
 t = _a.sent();
 setMessages([{ role: "assistant", text: t }]);
 return [2 ];
 }
 }); }); };
 var send = function () { return __awaiter(_this, void 0, void 0, function () { var m, t; return __generator(this, function (_a) {
 switch (_a.label) {
 case 0:
 if (!input.trim() || loading)
 return [2 ];
 m = __spreadArray(__spreadArray([], messages, true), [{ role: "user", text: input.trim() }], false);
 setMessages(m);
 setInput("");
 return [4 , call(m)];
 case 1:
 t = _a.sent();
 setMessages(function (x) { return __spreadArray(__spreadArray([], x, true), [{ role: "assistant", text: t }], false); });
 return [2 ];
 }
 }); }); };
 React.useEffect(function () { var _a; return (_a = bottomRef.current) === null || _a === void 0 ? void 0 : _a.scrollIntoView({ behavior: "smooth" }); }, [messages, loading]);
 if (!started)
 return (React.createElement("div", null,
 React.createElement("div", { style: { display: "flex", alignItems: "center", gap: "0.75rem", marginBottom: "1.5rem" } },
 React.createElement("button", { onClick: onBack, style: { background: "transparent", border: "1px solid ".concat(C.border), color: C.muted, padding: "0.35rem 0.7rem", borderRadius: "8px", fontSize: "0.85rem", cursor: "pointer" } }, "\u2190 \u05D7\u05D6\u05E8\u05D4"),
 React.createElement("h2", { style: { fontSize: "1.1rem", fontWeight: 700, margin: 0 } }, "\uD83E\uDD16 \u05DC\u05DE\u05D9\u05D3\u05D4 \u05E2\u05DD AI")),
 React.createElement("div", { style: { background: "linear-gradient(135deg,${C.accent}33,${C.accent}22)", border: "2px solid ".concat(AI, "44"), borderRadius: "20px", padding: "2rem", textAlign: "center" } },
 React.createElement("div", { style: { fontSize: "3rem", marginBottom: "0.75rem" } }, "\uD83E\uDD16"),
 React.createElement("div", { style: { fontSize: "1.2rem", fontWeight: 700, color: AI, marginBottom: "0.5rem" } }, "\u05DE\u05D5\u05E8\u05D4 AI"),
 React.createElement("div", { style: { background: C.border + "44", borderRadius: "12px", padding: "0.85rem 1rem", marginBottom: "1.5rem", textAlign: "right" } },
 React.createElement("div", { style: { fontWeight: 700 } }, set.name),
 React.createElement("div", { style: { fontSize: "0.8rem", color: C.muted, marginTop: "0.2rem" } },
 (set.pairs || []).length,
 " \u05DE\u05D9\u05DC\u05D9\u05DD")),
 React.createElement("button", { onClick: start, style: { background: "linear-gradient(135deg,#553c9a,#b393d3)", color: "#fff", border: "none", padding: "0.75rem 2rem", borderRadius: "12px", fontSize: "1rem", fontWeight: 700, cursor: "pointer" } }, "\uD83D\uDE80 \u05D4\u05EA\u05D7\u05DC \u05DC\u05DC\u05DE\u05D5\u05D3!"))));
 return (React.createElement("div", { style: { display: "flex", flexDirection: "column", height: "calc(100vh - 120px)", maxHeight: "700px" } },
 React.createElement("div", { style: { display: "flex", alignItems: "center", gap: "0.6rem", marginBottom: "0.75rem", flexShrink: 0 } },
 React.createElement("button", { onClick: onBack, style: { background: "transparent", border: "1px solid ".concat(C.border), color: C.muted, padding: "0.35rem 0.7rem", borderRadius: "8px", fontSize: "0.85rem", cursor: "pointer" } }, "\u2190 \u05D7\u05D6\u05E8\u05D4"),
 React.createElement("span", { style: { fontWeight: 700, color: AI } },
 "\uD83E\uDD16 ",
 set.name)),
 React.createElement("div", { style: { flex: 1, overflowY: "auto", display: "flex", flexDirection: "column", gap: "0.75rem", padding: "0.5rem 0" } },
 messages.map(function (m, i) { return (React.createElement("div", { key: i, style: { display: "flex", justifyContent: m.role === "user" ? "flex-start" : "flex-end" } },
 React.createElement("div", { style: { maxWidth: "85%", background: m.role === "user" ? C.card : "linear-gradient(135deg,${C.accent}33,${C.accent}22)", border: "1px solid ".concat(m.role === "user" ? C.border : AI + "44"), borderRadius: "14px", padding: "0.75rem 1rem", fontSize: "0.88rem", lineHeight: 1.6, whiteSpace: "pre-wrap", color: C.text } }, m.text))); }),
 loading && React.createElement("div", { style: { display: "flex", justifyContent: "flex-end" } },
 React.createElement("div", { style: { background: "linear-gradient(135deg,${C.accent}33,${C.accent}22)", border: "1px solid ".concat(AI, "44"), borderRadius: "14px", padding: "0.75rem 1rem", color: AI } }, "\u23F3 \u05D7\u05D5\u05E9\u05D1...")),
 React.createElement("div", { ref: bottomRef })),
 React.createElement("div", { style: { display: "flex", gap: "0.5rem", marginTop: "0.75rem", flexShrink: 0 } },
 React.createElement("input", { value: input, onChange: function (e) { return setInput(e.target.value); }, onKeyDown: function (e) { return e.key === "Enter" && !e.shiftKey && send(); }, placeholder: "\u05EA\u05E9\u05D5\u05D1\u05D4...", style: { flex: 1, background: C.card, border: "1px solid ".concat(C.border), color: C.text, padding: "0.65rem 1rem", borderRadius: "12px", fontSize: "0.88rem", outline: "none" } }),
 React.createElement("button", { onClick: send, disabled: loading || !input.trim(), style: { background: AI, color: "#fff", border: "none", padding: "0.65rem 1rem", borderRadius: "12px", fontSize: "0.9rem", cursor: "pointer", opacity: loading || !input.trim() ? 0.5 : 1 } }, "\u27A4"))));
}
function ItemList(_a) {
 var _b = _a.items, items = _b === void 0 ? [] : _b, onSave = _a.onSave, title = _a.title, readOnly = _a.readOnly, _c = _a.checks, checks = _c === void 0 ? {} : _c, onCheck = _a.onCheck, showCheck = _a.showCheck, isTests = _a.isTests;
 var _d = React.useState(false), editing = _d[0], setEditing = _d[1];
 var _e = React.useState(items || []), list = _e[0], setList = _e[1];
 React.useEffect(function () { setList(items || []); }, [JSON.stringify(items)]);
 var _f = React.useState(""), newTitle = _f[0], setNewTitle = _f[1];
 var _g = React.useState(""), newDate = _g[0], setNewDate = _g[1];
 var _h = React.useState(""), newNote = _h[0], setNewNote = _h[1];
 var _j = React.useState(""), newTopics = _j[0], setNewTopics = _j[1];
 var _k = React.useState(""), newSubject = _k[0], setNewSubject = _k[1];
 var _l = React.useState(null), editingItem = _l[0], setEditingItem = _l[1]; 
 var startEditItem = function (item) { return setEditingItem(__assign({}, item)); };
 var saveEditItem = function () {
 if (!editingItem)
 return;
 setList(function (x) { return x.map(function (i) { return i.id === editingItem.id ? __assign(__assign({}, i), editingItem) : i; }); });
 setEditingItem(null);
 var updated = list.map(function (i) { return i.id === editingItem.id ? __assign(__assign({}, i), editingItem) : i; });
 onSave && onSave(updated);
 };
 var save = function () { onSave && onSave(list); setEditing(false); };
 var add = function () { if (!newTitle.trim())
 return; var item = { id: genId(), title: newTitle.trim(), dueDate: newDate, note: newNote, topics: isTests ? newTopics : undefined, done: false }; setList(function (x) { return __spreadArray(__spreadArray([], x, true), [item], false); }); setNewTitle(""); setNewDate(""); setNewNote(""); setNewTopics(""); };
 var del = function (id) { return setList(function (x) { return x.filter(function (i) { return i.id !== id; }); }); };
 var inp = { background: C.card, border: "1px solid ".concat(C.border), color: C.text, padding: "0.55rem 0.75rem", borderRadius: "8px", fontSize: "0.85rem", outline: "none", width: "100%" };
 return (React.createElement("div", null,
 React.createElement("div", { style: { display: "flex", alignItems: "center", gap: "0.75rem", marginBottom: "1rem", flexWrap: "wrap" } },
 React.createElement("h3", { style: { fontSize: "1rem", fontWeight: 700, margin: 0 } }, title),
 !readOnly && !editing && React.createElement("button", { onClick: function () { return setEditing(true); }, style: { background: "".concat(C.accent, "22"), border: "1px solid ".concat(C.accent), color: C.accent, padding: "0.3rem 0.75rem", borderRadius: "8px", fontSize: "0.82rem", cursor: "pointer" } }, "\u270F\uFE0F \u05E2\u05E8\u05D5\u05DA"),
 editing && React.createElement(React.Fragment, null,
 React.createElement("button", { onClick: save, style: { background: C.green, color: "#fff", border: "none", padding: "0.3rem 0.75rem", borderRadius: "8px", fontSize: "0.82rem", cursor: "pointer" } }, "\uD83D\uDCBE \u05E9\u05DE\u05D5\u05E8"),
 React.createElement("button", { onClick: function () { setList(items || []); setEditing(false); }, style: { background: "transparent", border: "1px solid ".concat(C.border), color: C.muted, padding: "0.3rem 0.75rem", borderRadius: "8px", fontSize: "0.82rem", cursor: "pointer" } }, "\u05D1\u05D9\u05D8\u05D5\u05DC"))),
 editing && (React.createElement("div", { style: { background: C.card, border: "1px solid ".concat(C.border), borderRadius: "12px", padding: "0.85rem", marginBottom: "1rem", display: "flex", flexDirection: "column", gap: "0.5rem" } },
 React.createElement("input", { style: inp, placeholder: "\u05DB\u05D5\u05EA\u05E8\u05EA", value: newTitle, onChange: function (e) { return setNewTitle(e.target.value); }, onKeyDown: function (e) { return e.key === "Enter" && add(); } }),
 isTests && React.createElement("input", { style: inp, placeholder: "\u05DE\u05E7\u05E6\u05D5\u05E2 (\u05DC\u05DE\u05E9\u05DC: \u05DE\u05EA\u05DE\u05D8\u05D9\u05E7\u05D4, \u05D0\u05E0\u05D2\u05DC\u05D9\u05EA, \u05D4\u05D9\u05E1\u05D8\u05D5\u05E8\u05D9\u05D4)", value: newSubject, onChange: function (e) { return setNewSubject(e.target.value); } }),
 isTests && React.createElement("input", { style: inp, placeholder: "\u05E0\u05D5\u05E9\u05D0\u05D9\u05DD (\u05DC\u05DE\u05E9\u05DC: \u05E4\u05E8\u05E7\u05D9\u05DD 3-5)", value: newTopics, onChange: function (e) { return setNewTopics(e.target.value); } }),
 React.createElement("input", { type: "date", style: inp, value: newDate, onChange: function (e) { return setNewDate(e.target.value); } }),
 React.createElement("input", { style: inp, placeholder: "\u05D4\u05E2\u05E8\u05D4 (\u05D0\u05D5\u05E4\u05E6\u05D9\u05D5\u05E0\u05DC\u05D9)", value: newNote, onChange: function (e) { return setNewNote(e.target.value); } }),
 React.createElement("button", { onClick: add, style: { background: C.accent, color: "#fff", border: "none", padding: "0.5rem", borderRadius: "8px", fontSize: "0.85rem", fontWeight: 600, cursor: "pointer" } }, "+ \u05D4\u05D5\u05E1\u05E3"))),
 list.length === 0 && React.createElement("div", { style: { textAlign: "center", padding: "2rem", color: C.muted, fontSize: "0.85rem" } },
 "\u05D0\u05D9\u05DF \u05E4\u05E8\u05D9\u05D8\u05D9\u05DD",
 !readOnly ? " — לחץ ערוך כדי להוסיף" : ""),
 React.createElement("div", { style: { display: "flex", flexDirection: "column", gap: "0.5rem" } }, list.filter(function (item) {
 if (isTests && item.dueDate) {
 var today = new Date().toISOString().split("T")[0];
 return item.dueDate >= today;
 }
 return true;
 }).map(function (item) {
 var checked = checks[item.id];
 var d = item.dueDate ? Math.ceil((new Date(item.dueDate) - new Date()) / (1000 * 60 * 60 * 24)) : null;
 return (React.createElement("div", { key: item.id, style: { background: C.card, border: "1px solid ".concat(checked ? "#48bb7844" : C.border), borderRadius: "12px", padding: "0.75rem 1rem", display: "flex", alignItems: "flex-start", gap: "0.75rem", opacity: checked ? 0.65 : 1 } },
 showCheck && React.createElement("input", { type: "checkbox", checked: !!checked, onChange: function (e) { return onCheck && onCheck(item.id, e.target.checked); }, style: { marginTop: "0.2rem", width: "16px", height: "16px", cursor: "pointer", accentColor: C.accent } }),
 React.createElement("div", { style: { flex: 1, minWidth: 0 } }, editingItem && editingItem.id === item.id ? (React.createElement("div", { style: { display: "flex", flexDirection: "column", gap: "0.4rem" } },
 React.createElement("input", { value: editingItem.title, onChange: function (e) { return setEditingItem(function (x) { return (__assign(__assign({}, x), { title: e.target.value })); }); }, style: { background: C.bg, border: "1px solid ".concat(C.accent), color: C.text, padding: "0.35rem 0.5rem", borderRadius: "6px", fontSize: "0.85rem", outline: "none" }, placeholder: "\u05DB\u05D5\u05EA\u05E8\u05EA" }),
 isTests && React.createElement("input", { value: editingItem.subject || "", onChange: function (e) { return setEditingItem(function (x) { return (__assign(__assign({}, x), { subject: e.target.value })); }); }, style: { background: C.bg, border: "1px solid ".concat(C.border), color: C.text, padding: "0.35rem 0.5rem", borderRadius: "6px", fontSize: "0.82rem", outline: "none" }, placeholder: "\u05DE\u05E7\u05E6\u05D5\u05E2" }),
 isTests && React.createElement("input", { value: editingItem.topics || "", onChange: function (e) { return setEditingItem(function (x) { return (__assign(__assign({}, x), { topics: e.target.value })); }); }, style: { background: C.bg, border: "1px solid ".concat(C.border), color: C.text, padding: "0.35rem 0.5rem", borderRadius: "6px", fontSize: "0.82rem", outline: "none" }, placeholder: "\u05E0\u05D5\u05E9\u05D0\u05D9\u05DD" }),
 React.createElement("input", { type: "date", value: editingItem.dueDate || "", onChange: function (e) { return setEditingItem(function (x) { return (__assign(__assign({}, x), { dueDate: e.target.value })); }); }, style: { background: C.bg, border: "1px solid ".concat(C.border), color: C.text, padding: "0.35rem 0.5rem", borderRadius: "6px", fontSize: "0.82rem", outline: "none" } }),
 React.createElement("input", { value: editingItem.note || "", onChange: function (e) { return setEditingItem(function (x) { return (__assign(__assign({}, x), { note: e.target.value })); }); }, style: { background: C.bg, border: "1px solid ".concat(C.border), color: C.text, padding: "0.35rem 0.5rem", borderRadius: "6px", fontSize: "0.82rem", outline: "none" }, placeholder: "\u05D4\u05E2\u05E8\u05D4" }),
 React.createElement("div", { style: { display: "flex", gap: "0.4rem" } },
 React.createElement("button", { onClick: saveEditItem, style: { flex: 1, background: C.accent, color: "#fff", border: "none", padding: "0.3rem", borderRadius: "6px", fontSize: "0.8rem", cursor: "pointer" } }, "\u2705 \u05E9\u05DE\u05D5\u05E8"),
 React.createElement("button", { onClick: function () { return setEditingItem(null); }, style: { background: "transparent", border: "1px solid ".concat(C.border), color: C.muted, padding: "0.3rem 0.5rem", borderRadius: "6px", fontSize: "0.8rem", cursor: "pointer" } }, "\u05D1\u05D9\u05D8\u05D5\u05DC")))) : (React.createElement(React.Fragment, null,
 React.createElement("div", { style: { fontWeight: 600, fontSize: "0.92rem", textDecoration: checked ? "line-through" : "none" } }, item.title),
 item.subject && React.createElement("div", { style: { fontSize: "0.78rem", color: "#63b3ed", marginTop: "0.15rem" } },
 "\uD83D\uDCDA ",
 item.subject),
 item.topics && React.createElement("div", { style: { fontSize: "0.78rem", color: "#f6855a", marginTop: "0.15rem" } },
 "\uD83D\uDCCB ",
 item.topics),
 item.dueDate && React.createElement("div", { style: { fontSize: "0.78rem", color: d !== null && d <= 2 ? "#fc8181" : d !== null && d <= 5 ? "#f6ad55" : C.muted, marginTop: "0.15rem" } },
 "\uD83D\uDCC5 ",
 item.dueDate,
 d !== null ? " (עוד " + d + " ימים)" : ""),
 item.note && React.createElement("div", { style: { fontSize: "0.78rem", color: C.muted, marginTop: "0.1rem" } }, item.note),
 !readOnly && React.createElement("button", { onClick: function () { return startEditItem(item); }, style: { marginTop: "0.35rem", background: "transparent", border: "1px solid ".concat(C.border), color: C.muted, padding: "0.15rem 0.5rem", borderRadius: "6px", fontSize: "0.75rem", cursor: "pointer" } }, "\u270F\uFE0F \u05E2\u05E8\u05D5\u05DA")))),
 editing && !editingItem && React.createElement("button", { onClick: function () { return del(item.id); }, style: { background: "transparent", border: "none", color: "#fc8181", cursor: "pointer", fontSize: "1rem", padding: 0, flexShrink: 0 } }, "\u2715")));
 }))));
}
function DoneList(_a) {
 var sections = _a.sections, onUncheck = _a.onUncheck;
 var done = sections.map(function (s) { return (__assign(__assign({}, s), { items: (s.items || []).filter(function (i) { var _a; return (_a = s.checks) === null || _a === void 0 ? void 0 : _a[i.id]; }) })); }).filter(function (s) { return s.items.length > 0; });
 if (done.length === 0)
 return React.createElement("div", { style: { textAlign: "center", padding: "3rem", color: C.muted } }, "\u05D0\u05D9\u05DF \u05E4\u05E8\u05D9\u05D8\u05D9\u05DD \u05E9\u05D1\u05D5\u05E6\u05E2\u05D5 \u05E2\u05D3\u05D9\u05D9\u05DF \u2728");
 return (React.createElement("div", { style: { display: "flex", flexDirection: "column", gap: "1.25rem" } }, done.map(function (s) { return (React.createElement("div", { key: s.title },
 React.createElement("div", { style: { fontSize: "0.82rem", color: s.color, fontWeight: 700, marginBottom: "0.5rem" } }, s.title),
 s.items.map(function (item) { return (React.createElement("div", { key: item.id, style: { background: C.card, border: "1px solid ".concat(s.color, "33"), borderRadius: "10px", padding: "0.65rem 1rem", display: "flex", alignItems: "center", gap: "0.75rem", marginBottom: "0.4rem", opacity: 0.7 } },
 React.createElement("span", { style: { color: s.color } }, "\u2713"),
 React.createElement("span", { style: { flex: 1, textDecoration: "line-through", fontSize: "0.88rem" } }, item.title),
 React.createElement("button", { onClick: function () { return onUncheck(s.title === "שיעורי בית" ? "homework" : s.title === "עבודות" ? "works" : "tests", item.id); }, style: { background: "transparent", border: "1px solid ".concat(C.border), color: C.muted, padding: "0.2rem 0.5rem", borderRadius: "6px", fontSize: "0.75rem", cursor: "pointer" } }, "\u05E9\u05D7\u05D6\u05E8"))); }))); })));
}
function Schedule(_a) {
 var _b;
 var _c = _a.data, data = _c === void 0 ? {} : _c, onSave = _a.onSave, editable = _a.editable, _d = _a.userChecks, userChecks = _d === void 0 ? {} : _d, onUserCheck = _a.onUserCheck;
 var _e = React.useState(false), editing = _e[0], setEditing = _e[1];
 var _f = React.useState(null), rows = _f[0], setRows = _f[1];
 var DEF_HOURS = Array.from({ length: 12 }, function (_, i) { return "".concat(7 + i, ":00"); });
 var makeRows = function () { return DEF_HOURS.map(function (h, i) { return ({ id: "r" + i, label: "שיעור " + (i + 1), from: h, to: "".concat(8 + i, ":00") }); }); };
 var schedule = rows || (((_b = data === null || data === void 0 ? void 0 : data.rows) === null || _b === void 0 ? void 0 : _b.length) > 0 ? data.rows : makeRows());
 var days = (data === null || data === void 0 ? void 0 : data.days) || {};
 var _g = React.useState(days), localDays = _g[0], setLocalDays = _g[1];
 var _h = React.useState(schedule), localRows = _h[0], setLocalRows = _h[1];
 React.useEffect(function () {
 var _a;
 setLocalDays((data === null || data === void 0 ? void 0 : data.days) || {});
 setLocalRows(((_a = data === null || data === void 0 ? void 0 : data.rows) === null || _a === void 0 ? void 0 : _a.length) > 0 ? data.rows : makeRows());
 }, [JSON.stringify(data)]);
 var _j = React.useState(false), saved = _j[0], setSaved = _j[1];
 var save = function () {
 onSave && onSave({ rows: localRows, days: localDays });
 setEditing(false);
 setSaved(true);
 setTimeout(function () { return setSaved(false); }, 2000);
 };
 var inp = { background: C.card, border: "1px solid ".concat(C.border), color: C.text, padding: "0.3rem 0.4rem", borderRadius: "6px", fontSize: "0.8rem", outline: "none" };
 var todayDay = DAYS[new Date().getDay() === 0 ? 6 : new Date().getDay() - 1];
 return (React.createElement("div", null,
 React.createElement("div", { style: { display: "flex", alignItems: "center", gap: "0.75rem", marginBottom: "1rem", flexWrap: "wrap" } },
 React.createElement("h3", { style: { fontSize: "1rem", fontWeight: 700, margin: 0 } }, "\uD83D\uDDD3\uFE0F \u05DC\u05D5\u05D7 \u05E9\u05E2\u05D5\u05EA"),
 saved && React.createElement("span", { style: { fontSize: "0.78rem", color: C.green } }, "\u2705 \u05E0\u05E9\u05DE\u05E8!"),
 editable && !editing && React.createElement("button", { onClick: function () { return setEditing(true); }, style: { background: "".concat(C.accent, "22"), border: "1px solid ".concat(C.accent), color: C.accent, padding: "0.3rem 0.75rem", borderRadius: "8px", fontSize: "0.82rem", cursor: "pointer" } }, "\u270F\uFE0F \u05E2\u05E8\u05D5\u05DA"),
 editing && React.createElement(React.Fragment, null,
 React.createElement("button", { onClick: save, style: { background: C.green, color: "#fff", border: "none", padding: "0.3rem 0.75rem", borderRadius: "8px", fontSize: "0.82rem", cursor: "pointer" } }, "\uD83D\uDCBE \u05E9\u05DE\u05D5\u05E8"),
 React.createElement("button", { onClick: function () { return setEditing(false); }, style: { background: "transparent", border: "1px solid ".concat(C.border), color: C.muted, padding: "0.3rem 0.75rem", borderRadius: "8px", fontSize: "0.82rem", cursor: "pointer" } }, "\u05D1\u05D9\u05D8\u05D5\u05DC"))),
 React.createElement("div", { style: { overflowX: "auto" } },
 React.createElement("table", { style: { width: "100%", borderCollapse: "collapse", fontSize: "0.8rem", minWidth: "500px" } },
 React.createElement("thead", null,
 React.createElement("tr", { style: { borderBottom: "2px solid ".concat(C.border) } },
 React.createElement("th", { style: { padding: "0.5rem", textAlign: "right", color: C.muted, fontWeight: 600, width: "100px" } }, "\u05E9\u05E2\u05D5\u05EA"),
 DAYS.map(function (d) { return React.createElement("th", { key: d, style: { padding: "0.5rem", textAlign: "center", color: d === todayDay ? C.accent : C.muted, fontWeight: d === todayDay ? 700 : 400 } }, d); }))),
 React.createElement("tbody", null, localRows.map(function (row, ri) { return (React.createElement("tr", { key: row.id, style: { borderBottom: "1px solid ".concat(C.border, "33") } },
 React.createElement("td", { style: { padding: "0.4rem 0.5rem", color: C.muted, whiteSpace: "nowrap" } }, editing ? (React.createElement("div", { style: { display: "flex", gap: "0.2rem", alignItems: "center" } },
 React.createElement("input", { style: __assign(__assign({}, inp), { width: "52px" }), value: row.from, onChange: function (e) { return setLocalRows(function (rs) { return rs.map(function (r, i) { return i === ri ? __assign(__assign({}, r), { from: e.target.value }) : r; }); }); } }),
 React.createElement("span", null, "-"),
 React.createElement("input", { style: __assign(__assign({}, inp), { width: "52px" }), value: row.to, onChange: function (e) { return setLocalRows(function (rs) { return rs.map(function (r, i) { return i === ri ? __assign(__assign({}, r), { to: e.target.value }) : r; }); }); } }))) : React.createElement("span", null,
 row.from,
 "\u2013",
 row.to)),
 DAYS.map(function (day) {
 var key = day + "_" + row.id;
 var val = (localDays[day] || {})[row.id] || "";
 var checked = userChecks[key];
 return (React.createElement("td", { key: day, style: { padding: "0.3rem", textAlign: "center" } }, editing ? (React.createElement("input", { style: __assign(__assign({}, inp), { width: "100%", textAlign: "center" }), value: val, onChange: function (e) { var nd = __assign({}, localDays); if (!nd[day])
 nd[day] = {}; nd[day][row.id] = e.target.value; setLocalDays(nd); }, placeholder: "\u2014" })) : (val ? React.createElement("div", { style: { background: checked ? C.green + "22" : C.accent + "18", border: "1px solid ".concat(checked ? C.green : C.accent, "33"), borderRadius: "6px", padding: "0.2rem 0.3rem", cursor: "pointer", textDecoration: checked ? "line-through" : "none", color: checked ? C.green : C.text, fontSize: "0.78rem" }, onClick: function () { return onUserCheck && onUserCheck(key, !checked); } }, val) : React.createElement("span", { style: { color: C.border } }, "\u2014"))));
 }))); }))))));
}
function SetEditor(_a) {
 var _this = this;
 var set = _a.set, onSave = _a.onSave, onBack = _a.onBack;
 var _b = React.useState(set.name || ""), name = _b[0], setName = _b[1];
 var _c = React.useState(set.pairs || []), pairs = _c[0], setPairs = _c[1];
 var _d = React.useState(""), newEn = _d[0], setNewEn = _d[1];
 var _e = React.useState(""), newHe = _e[0], setNewHe = _e[1];
 var _f = React.useState([]), suggestions = _f[0], setSuggestions = _f[1];
 var _g = React.useState(false), loadingSug = _g[0], setLoadingSug = _g[1];
 var _h = React.useState(null), sugField = _h[0], setSugField = _h[1]; 
 var sugTimerRef = React.useRef(null);
 var inp = { background: C.card, border: "1px solid ".concat(C.border), color: C.text, padding: "0.55rem 0.75rem", borderRadius: "8px", fontSize: "0.88rem", outline: "none" };
 var addPair = function () { if (!newEn.trim() || !newHe.trim())
 return; setPairs(function (x) { return __spreadArray(__spreadArray([], x, true), [{ id: genId(), en: newEn.trim(), he: newHe.trim() }], false); }); setNewEn(""); setNewHe(""); setSuggestions([]); };
 var delPair = function (id) { return setPairs(function (x) { return x.filter(function (p) { return p.id !== id; }); }); };
 var save = function () { return onSave(__assign(__assign({}, set), { name: name, pairs: pairs, updatedAt: Date.now() })); };
 var fetchSuggestions = function (word, toLang) { return __awaiter(_this, void 0, void 0, function () {
 var langPair, res, data, main, mainScore, matches, isHebrew_1, isEnglish_1, isRightScript_1, goodMatches, mainOk, opts, e_5;
 var _a, _b;
 return __generator(this, function (_c) {
 switch (_c.label) {
 case 0:
 if (!word || word.trim().length < 2) {
 setSuggestions([]);
 return [2 ];
 }
 setLoadingSug(true);
 setSugField(toLang);
 _c.label = 1;
 case 1:
 _c.trys.push([1, 4, , 5]);
 langPair = toLang === "he" ? "en|he" : "he|en";
 return [4 , fetch("https://api.mymemory.translated.net/get?q=".concat(encodeURIComponent(word), "&langpair=").concat(langPair))];
 case 2:
 res = _c.sent();
 return [4 , res.json()];
 case 3:
 data = _c.sent();
 main = ((_a = data.responseData) === null || _a === void 0 ? void 0 : _a.translatedText) || "";
 mainScore = ((_b = data.responseData) === null || _b === void 0 ? void 0 : _b.match) || 0;
 matches = data.matches || [];
 isHebrew_1 = function (s) { return /[\u05D0-\u05EA]/.test(s); };
 isEnglish_1 = function (s) { return /^[a-zA-Z\s\-]+$/.test(s); };
 isRightScript_1 = function (s) { return toLang === "he" ? isHebrew_1(s) : isEnglish_1(s); };
 goodMatches = matches
 .filter(function (m) { return m.quality >= 70 && m.translation && isRightScript_1(m.translation); })
 .map(function (m) { return m.translation.trim(); });
 mainOk = mainScore >= 0.5 && main && isRightScript_1(main) && main.toLowerCase() !== word.toLowerCase();
 opts = __spreadArray(__spreadArray([], (mainOk ? [main] : []), true), goodMatches, true).filter(function (s) { return s.length > 0 && s.length < 40 && !s.includes("PLEASE") && !s.includes("LIMIT"); })
 .map(function (s) { return s.trim(); })
 .filter(function (s, i, arr) { return arr.indexOf(s) === i; })
 .slice(0, 4);
 setSuggestions(opts); 
 return [3 , 5];
 case 4:
 e_5 = _c.sent();
 setSuggestions([]);
 return [3 , 5];
 case 5:
 setLoadingSug(false);
 return [2 ];
 }
 });
 }); };
 var handleEnChange = function (val) {
 setNewEn(val);
 clearTimeout(sugTimerRef.current);
 if (val.trim().length >= 2) {
 sugTimerRef.current = setTimeout(function () { return fetchSuggestions(val, "he"); }, 600);
 }
 else {
 setSuggestions([]);
 }
 };
 var handleHeChange = function (val) {
 setNewHe(val);
 clearTimeout(sugTimerRef.current);
 if (val.trim().length >= 2) {
 sugTimerRef.current = setTimeout(function () { return fetchSuggestions(val, "en"); }, 600);
 }
 else {
 setSuggestions([]);
 }
 };
 return (React.createElement("div", null,
 React.createElement("div", { style: { display: "flex", alignItems: "center", gap: "0.75rem", marginBottom: "1.5rem", flexWrap: "wrap" } },
 React.createElement("button", { onClick: onBack, style: { background: "transparent", border: "1px solid ".concat(C.border), color: C.muted, padding: "0.35rem 0.7rem", borderRadius: "8px", fontSize: "0.85rem", cursor: "pointer" } }, "\u2190 \u05D7\u05D6\u05E8\u05D4"),
 React.createElement("h2", { style: { fontSize: "1.1rem", fontWeight: 700, margin: 0, flex: 1 } }, "\u270F\uFE0F \u05E2\u05E8\u05D9\u05DB\u05EA \u05E2\u05E8\u05DB\u05D4"),
 React.createElement("button", { onClick: save, style: { background: C.green, color: "#fff", border: "none", padding: "0.42rem 1rem", borderRadius: "8px", fontSize: "0.85rem", fontWeight: 600, cursor: "pointer" } }, "\uD83D\uDCBE \u05E9\u05DE\u05D5\u05E8")),
 React.createElement("input", { style: __assign(__assign({}, inp), { width: "100%", marginBottom: "1rem", fontSize: "1rem", fontWeight: 600 }), placeholder: "\u05E9\u05DD \u05D4\u05E2\u05E8\u05DB\u05D4", value: name, onChange: function (e) { return setName(e.target.value); } }),
 React.createElement("div", { style: { background: C.card, border: "1px solid ".concat(C.border), borderRadius: "12px", padding: "0.85rem", marginBottom: "0.25rem", display: "flex", gap: "0.5rem", flexWrap: "wrap" } },
 React.createElement("div", { style: { flex: 1, minWidth: "120px", position: "relative" } },
 React.createElement("input", { style: __assign(__assign({}, inp), { width: "100%", boxSizing: "border-box" }), placeholder: "English", value: newEn, onChange: function (e) { return handleEnChange(e.target.value); }, onKeyDown: function (e) { return e.key === "Enter" && addPair(); } })),
 React.createElement("div", { style: { flex: 1, minWidth: "120px", position: "relative" } },
 React.createElement("input", { style: __assign(__assign({}, inp), { width: "100%", boxSizing: "border-box" }), placeholder: "\u05E2\u05D1\u05E8\u05D9\u05EA", value: newHe, onChange: function (e) { return handleHeChange(e.target.value); }, onKeyDown: function (e) { return e.key === "Enter" && addPair(); } })),
 React.createElement("button", { onClick: addPair, style: { background: C.accent, color: "#fff", border: "none", padding: "0.55rem 1rem", borderRadius: "8px", fontSize: "0.85rem", fontWeight: 600, cursor: "pointer", whiteSpace: "nowrap" } }, "+ \u05D4\u05D5\u05E1\u05E3")),
 (suggestions.length > 0 || loadingSug) && (React.createElement("div", { style: { background: C.card, border: "1px solid ".concat(C.border), borderRadius: "10px", padding: "0.5rem 0.75rem", marginBottom: "1rem", display: "flex", flexWrap: "wrap", gap: "0.4rem", alignItems: "center" } },
 React.createElement("span", { style: { fontSize: "0.75rem", color: C.muted, marginLeft: "0.25rem" } }, loadingSug ? "⏳ מחפש תרגומים..." : "💡 הצעות:"),
 suggestions.map(function (s, i) { return (React.createElement("button", { key: i, onClick: function () { if (sugField === "he")
 setNewHe(s);
 else
 setNewEn(s); setSuggestions([]); }, style: { background: C.accent + "22", border: "1px solid ".concat(C.accent, "55"), color: C.accent, padding: "0.25rem 0.65rem", borderRadius: "20px", fontSize: "0.82rem", cursor: "pointer", fontWeight: 600 } }, s)); }))),
 (suggestions.length === 0 && !loadingSug) && React.createElement("div", { style: { marginBottom: "1rem" } }),
 pairs.length === 0 && React.createElement("div", { style: { textAlign: "center", padding: "2rem", color: C.muted } }, "\u05D0\u05D9\u05DF \u05DE\u05D9\u05DC\u05D9\u05DD \u05E2\u05D3\u05D9\u05D9\u05DF"),
 React.createElement("div", { style: { display: "flex", flexDirection: "column", gap: "0.4rem" } }, pairs.map(function (p, i) { return (React.createElement("div", { key: p.id, style: { background: C.card, border: "1px solid ".concat(C.border), borderRadius: "10px", padding: "0.6rem 1rem", display: "flex", alignItems: "center", gap: "1rem" } },
 React.createElement("span", { style: { color: C.muted, fontSize: "0.8rem", minWidth: "1.5rem" } },
 i + 1,
 "."),
 React.createElement("span", { style: { flex: 1, fontWeight: 500 } }, p.en),
 React.createElement("span", { style: { color: C.muted } }, "\u2192"),
 React.createElement("span", { style: { flex: 1, color: C.accent } }, p.he),
 React.createElement("button", { onClick: function () { return delPair(p.id); }, style: { background: "transparent", border: "none", color: "#fc8181", cursor: "pointer", fontSize: "1rem", padding: 0 } }, "\u2715"))); }))));
}
function LearnMode(_a) {
 var set = _a.set, settings = _a.settings, onBack = _a.onBack, user = _a.user;
 var pairs = set.pairs || [];
 var getQ = function (p) { return settings.direction === "en_to_he" ? p.en : settings.direction === "he_to_en" ? p.he : [p.en, p.he][Math.floor(Math.random() * 2)]; };
 var getA = function (p) { return settings.direction === "en_to_he" ? p.he : settings.direction === "he_to_en" ? p.en : (getQ(p) === p.en ? p.he : p.en); };
 var _b = React.useState(0), idx = _b[0], setIdx = _b[1];
 var _c = React.useState(false), flipped = _c[0], setFlipped = _c[1];
 var _d = React.useState(false), done = _d[0], setDone = _d[1];
 var p = pairs[idx];
 var next = function () { if (idx + 1 >= pairs.length) {
 setDone(true);
 }
 else {
 setIdx(function (i) { return i + 1; });
 setFlipped(false);
 } };
 var prev = function () { if (idx > 0) {
 setIdx(function (i) { return i - 1; });
 setFlipped(false);
 } };
 if (pairs.length === 0)
 return React.createElement("div", { style: { textAlign: "center", padding: "3rem", color: C.muted } },
 React.createElement("button", { onClick: onBack }, "\u05D7\u05D6\u05E8\u05D4"));
 if (done)
 return (React.createElement("div", { style: { textAlign: "center", padding: "3rem" } },
 React.createElement("div", { style: { fontSize: "3rem", marginBottom: "1rem" } }, "\uD83C\uDF89"),
 React.createElement("div", { style: { fontSize: "1.3rem", fontWeight: 700, marginBottom: "1rem" } }, "\u05E1\u05D9\u05D9\u05DE\u05EA \u05D0\u05EA \u05D4\u05E2\u05E8\u05DB\u05D4!"),
 React.createElement("div", { style: { display: "flex", gap: "0.75rem", justifyContent: "center", flexWrap: "wrap" } },
 React.createElement("button", { onClick: function () { setIdx(0); setFlipped(false); setDone(false); }, style: { background: C.accent, color: "#fff", border: "none", padding: "0.6rem 1.25rem", borderRadius: "10px", fontSize: "0.9rem", fontWeight: 600, cursor: "pointer" } }, "\uD83D\uDD04 \u05E9\u05D5\u05D1"),
 React.createElement("button", { onClick: onBack, style: { background: "transparent", border: "1px solid ".concat(C.border), color: C.text, padding: "0.6rem 1.25rem", borderRadius: "10px", fontSize: "0.9rem", cursor: "pointer" } }, "\u2190 \u05D7\u05D6\u05E8\u05D4"))));
 return (React.createElement("div", null,
 React.createElement("div", { style: { display: "flex", alignItems: "center", gap: "0.75rem", marginBottom: "1.5rem" } },
 React.createElement("button", { onClick: onBack, style: { background: "transparent", border: "1px solid ".concat(C.border), color: C.muted, padding: "0.35rem 0.7rem", borderRadius: "8px", fontSize: "0.85rem", cursor: "pointer" } }, "\u2190 \u05D7\u05D6\u05E8\u05D4"),
 React.createElement("div", { style: { flex: 1, textAlign: "center", color: C.muted, fontSize: "0.85rem" } },
 idx + 1,
 " / ",
 pairs.length)),
 React.createElement("div", { onClick: function () { return setFlipped(!flipped); }, style: { background: C.card, border: "2px solid ".concat(C.accent, "44"), borderRadius: "20px", padding: "3rem 2rem", textAlign: "center", cursor: "pointer", minHeight: "200px", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: "1rem", transition: "all 0.2s" } },
 React.createElement("div", { style: { fontSize: "1.6rem", fontWeight: 700 } }, flipped ? getA(p) : getQ(p)),
 !flipped && React.createElement("div", { style: { fontSize: "0.8rem", color: C.muted } }, "\u05DC\u05D7\u05E5 \u05DC\u05D2\u05DC\u05D5\u05EA"),
 flipped && React.createElement("div", { style: { fontSize: "1rem", color: C.accent } }, "\u2713")),
 React.createElement("div", { style: { display: "flex", gap: "0.75rem", marginTop: "1.25rem", justifyContent: "center" } },
 React.createElement("button", { onClick: prev, disabled: idx === 0, style: { background: C.card, border: "1px solid ".concat(C.border), color: C.text, padding: "0.55rem 1.4rem", borderRadius: "10px", fontSize: "0.9rem", cursor: "pointer", opacity: idx === 0 ? 0.4 : 1 } }, "\u2190 \u05D4\u05E7\u05D5\u05D3\u05DD"),
 !flipped
 ? React.createElement("button", { onClick: function () { return setFlipped(true); }, style: { background: C.accent, color: "#fff", border: "none", padding: "0.55rem 1.4rem", borderRadius: "10px", fontSize: "0.9rem", fontWeight: 600, cursor: "pointer" } }, "\u05D4\u05E6\u05D2 \u05EA\u05E9\u05D5\u05D1\u05D4")
 : React.createElement("button", { onClick: next, style: { background: C.green, color: "#fff", border: "none", padding: "0.55rem 1.4rem", borderRadius: "10px", fontSize: "0.9rem", fontWeight: 600, cursor: "pointer" } }, idx + 1 >= pairs.length ? "סיום 🎉" : "הבא →"))));
}
function DictSettings(_a) {
 var settings = _a.settings, setSettings = _a.setSettings, onReset = _a.onReset, show = _a.show, setShow = _a.setShow;
 return (React.createElement("div", { style: { position: "relative" } },
 React.createElement("button", { onClick: function () { return setShow(function (v) { return !v; }); }, style: { background: show ? C.accent + "22" : "transparent", border: "1px solid ".concat(show ? C.accent : C.border), color: show ? C.accent : C.muted, padding: "0.35rem 0.55rem", borderRadius: "8px", fontSize: "0.9rem", cursor: "pointer", lineHeight: 1 } }, "\u2699\uFE0F"),
 show && (React.createElement("div", { onClick: function (e) { return e.stopPropagation(); }, style: { position: "absolute", top: "calc(100% + 8px)", left: 0, background: C.card, border: "1px solid ".concat(C.border), borderRadius: "14px", padding: "1rem", zIndex: 100, minWidth: "200px", boxShadow: "0 8px 24px #0006", display: "flex", flexDirection: "column", gap: "0.75rem" } },
 React.createElement("div", { style: { fontSize: "0.8rem", color: C.muted, fontWeight: 700 } }, "\u2699\uFE0F \u05D4\u05D2\u05D3\u05E8\u05D5\u05EA"),
 React.createElement("div", null,
 React.createElement("div", { style: { fontSize: "0.75rem", color: C.muted, marginBottom: "0.35rem" } }, "\u05DB\u05D9\u05D5\u05D5\u05DF"),
 React.createElement("div", { style: { display: "flex", flexDirection: "column", gap: "0.3rem" } }, [["en_to_he", "אנגלית ← עברית"], ["he_to_en", "עברית ← אנגלית"], ["random", "אקראי"]].map(function (_a) {
 var val = _a[0], lbl = _a[1];
 return (React.createElement("button", { key: val, onClick: function () { return setSettings(function (s) { return (__assign(__assign({}, s), { direction: val })); }); }, style: { padding: "0.35rem 0.7rem", borderRadius: "8px", border: "1px solid ".concat(settings.direction === val ? C.accent : C.border), background: settings.direction === val ? C.accent + "33" : "transparent", color: settings.direction === val ? C.accent : C.text, fontSize: "0.82rem", cursor: "pointer", textAlign: "right" } }, lbl));
 }))),
 React.createElement("div", null,
 React.createElement("div", { style: { fontSize: "0.75rem", color: C.muted, marginBottom: "0.35rem" } }, "\u05E1\u05D3\u05E8"),
 React.createElement("div", { style: { display: "flex", flexDirection: "column", gap: "0.3rem" } }, [["ordered", "לפי הסדר"], ["random", "אקראי"]].map(function (_a) {
 var val = _a[0], lbl = _a[1];
 return (React.createElement("button", { key: val, onClick: function () { return setSettings(function (s) { return (__assign(__assign({}, s), { order: val })); }); }, style: { padding: "0.35rem 0.7rem", borderRadius: "8px", border: "1px solid ".concat((settings.order || "random") === val ? C.accent : C.border), background: (settings.order || "random") === val ? C.accent + "33" : "transparent", color: (settings.order || "random") === val ? C.accent : C.text, fontSize: "0.82rem", cursor: "pointer", textAlign: "right" } }, lbl));
 }))),
 React.createElement("button", { onClick: function () { onReset(); setShow(false); }, style: { background: "#fc818122", border: "1px solid #fc8181", color: "#fc8181", padding: "0.4rem 0.7rem", borderRadius: "8px", fontSize: "0.82rem", cursor: "pointer", fontWeight: 600 } }, "\uD83D\uDD04 \u05D0\u05D9\u05E4\u05D5\u05E1")))));
}
function ListenAndWrite(_a) {
 var set = _a.set, settings = _a.settings, setSettings = _a.setSettings, onBack = _a.onBack;
 var pairs = set.pairs || [];
 var shuffle = function (a) { return __spreadArray([], a, true).sort(function () { return Math.random() - 0.5; }); };
 var _b = React.useState(function () { return shuffle(__spreadArray([], pairs, true)); }), queue = _b[0], setQueue = _b[1];
 var _c = React.useState(0), idx = _c[0], setIdx = _c[1];
 var _d = React.useState(""), answer = _d[0], setAnswer = _d[1];
 var _e = React.useState(false), submitted = _e[0], setSubmitted = _e[1];
 var _f = React.useState(null), correct = _f[0], setCorrect = _f[1];
 var _g = React.useState(0), score = _g[0], setScore = _g[1];
 var _h = React.useState(false), done = _h[0], setDone = _h[1];
 var _j = React.useState(false), speaking = _j[0], setSpeaking = _j[1];
 var _k = React.useState([]), retryQueue = _k[0], setRetryQueue = _k[1];
 var _l = React.useState(1), round = _l[0], setRound = _l[1];
 var _m = React.useState(false), showSet = _m[0], setShowSet = _m[1];
 var inputRef = React.useRef(null);
 var p = queue[idx];
 var wordToSpeak = settings.direction === "he_to_en" ? p === null || p === void 0 ? void 0 : p.he : p === null || p === void 0 ? void 0 : p.en;
 var correctAns = settings.direction === "he_to_en" ? p === null || p === void 0 ? void 0 : p.en : p === null || p === void 0 ? void 0 : p.he;
 var speakLang = settings.direction === "he_to_en" ? "he-IL" : "en-US";
 var speak = function () {
 if (!wordToSpeak || !window.speechSynthesis)
 return;
 window.speechSynthesis.cancel();
 var u = new SpeechSynthesisUtterance(wordToSpeak);
 u.lang = speakLang;
 u.rate = 0.75;
 u.pitch = 1.0;
 u.volume = 1.0;
 if (speakLang.startsWith("en")) {
 var voices = window.speechSynthesis.getVoices();
 var preferred = voices.find(function (v) { return v.lang === "en-US" && v.name.includes("Google US English"); }) ||
 voices.find(function (v) { return v.lang === "en-US" && v.name.includes("Google"); }) ||
 voices.find(function (v) { return v.lang === "en-US" && v.name.includes("Samantha"); }) ||
 voices.find(function (v) { return v.lang === "en-US" && v.name.includes("Alex"); }) ||
 voices.find(function (v) { return v.lang === "en-US" && !v.name.toLowerCase().includes("compact"); }) ||
 voices.find(function (v) { return v.lang.startsWith("en-US"); }) ||
 voices.find(function (v) { return v.lang.startsWith("en"); });
 if (preferred)
 u.voice = preferred;
 }
 u.onstart = function () { return setSpeaking(true); };
 u.onend = function () { return setSpeaking(false); };
 window.speechSynthesis.speak(u);
 };
 React.useEffect(function () { var _a; speak(); (_a = inputRef.current) === null || _a === void 0 ? void 0 : _a.focus(); }, [idx, queue]);
 React.useEffect(function () { return function () { var _a; return (_a = window.speechSynthesis) === null || _a === void 0 ? void 0 : _a.cancel(); }; }, []);
 var submit = function () {
 if (!answer.trim())
 return;
 var isCorrect = answer.trim().toLowerCase() === (correctAns === null || correctAns === void 0 ? void 0 : correctAns.toLowerCase());
 setCorrect(isCorrect);
 setSubmitted(true);
 if (isCorrect)
 setScore(function (s) { return s + 1; });
 else
 setRetryQueue(function (q) { return __spreadArray(__spreadArray([], q, true), [p], false); });
 };
 var next = function () {
 if (idx + 1 >= queue.length) {
 if (retryQueue.length > 0) {
 setQueue(shuffle(__spreadArray([], retryQueue, true)));
 setRetryQueue([]);
 setIdx(0);
 setRound(function (r) { return r + 1; });
 setAnswer("");
 setSubmitted(false);
 setCorrect(null);
 }
 else {
 setDone(true);
 }
 }
 else {
 setIdx(function (i) { return i + 1; });
 setAnswer("");
 setSubmitted(false);
 setCorrect(null);
 }
 };
 if (pairs.length === 0)
 return React.createElement("div", { style: { textAlign: "center", padding: "3rem", color: C.muted } },
 React.createElement("button", { onClick: onBack }, "\u05D7\u05D6\u05E8\u05D4"));
 if (done)
 return (React.createElement("div", { style: { textAlign: "center", padding: "2rem" } },
 React.createElement("div", { style: { fontSize: "3rem", marginBottom: "1rem" } }, score / pairs.length >= 0.8 ? "🎉" : "📚"),
 React.createElement("div", { style: { fontSize: "1.4rem", fontWeight: 800, color: C.text, marginBottom: "0.4rem" } },
 score,
 " / ",
 pairs.length),
 round > 1 && React.createElement("div", { style: { fontSize: "0.82rem", color: C.accent, marginBottom: "0.4rem", fontWeight: 600 } },
 "\u05E2\u05D1\u05E8\u05EA ",
 round,
 " \u05E1\u05D1\u05D1\u05D9\u05DD!"),
 React.createElement("div", { style: { color: C.muted, marginBottom: "1.5rem" } }, score / pairs.length >= 0.8 ? "מצוין!" : score / pairs.length >= 0.5 ? "טוב, המשך להתאמן" : "כדאי לחזור שוב"),
 React.createElement("div", { style: { display: "flex", gap: "0.75rem", justifyContent: "center" } },
 React.createElement("button", { onClick: function () { setQueue(shuffle(__spreadArray([], pairs, true))); setIdx(0); setScore(0); setDone(false); setRound(1); setRetryQueue([]); setAnswer(""); setSubmitted(false); setCorrect(null); }, style: { background: C.accent, color: "#fff", border: "none", padding: "0.65rem 1.5rem", borderRadius: "10px", fontWeight: 700, cursor: "pointer" } }, "\uD83D\uDD04 \u05E9\u05D5\u05D1"),
 React.createElement("button", { onClick: onBack, style: { background: "transparent", border: "1px solid ".concat(C.border), color: C.muted, padding: "0.65rem 1.25rem", borderRadius: "10px", cursor: "pointer" } }, "\u2190 \u05D7\u05D6\u05E8\u05D4"))));
 return (React.createElement("div", { onClick: function () { return showSet && setShowSet(false); } },
 React.createElement("div", { style: { display: "flex", alignItems: "center", gap: "0.75rem", marginBottom: "1rem" } },
 React.createElement("button", { onClick: onBack, style: { background: "transparent", border: "1px solid ".concat(C.border), color: C.muted, padding: "0.35rem 0.7rem", borderRadius: "8px", fontSize: "0.85rem", cursor: "pointer" } }, "\u2190 \u05D7\u05D6\u05E8\u05D4"),
 React.createElement("div", { style: { flex: 1, textAlign: "center", color: C.muted, fontSize: "0.85rem" } },
 idx + 1,
 "/",
 queue.length,
 " \u00B7 \u2713 ",
 score,
 round > 1 && React.createElement("span", { style: { color: C.accent, marginRight: "0.5rem" } },
 " \u05E1\u05D1\u05D1 ",
 round)),
 React.createElement(DictSettings, { settings: settings, setSettings: setSettings, onReset: function () { setQueue(shuffle(__spreadArray([], pairs, true))); setIdx(0); setScore(0); setDone(false); setRound(1); setRetryQueue([]); setAnswer(""); setSubmitted(false); setCorrect(null); }, show: showSet, setShow: setShowSet })),
 React.createElement("div", { style: { height: "4px", background: C.border, borderRadius: "999px", marginBottom: "1.5rem" } },
 React.createElement("div", { style: { height: "100%", width: ((idx / queue.length) * 100) + "%", background: C.accent, borderRadius: "999px", transition: "width 0.3s" } })),
 React.createElement("div", { style: { textAlign: "center", marginBottom: "1.5rem" } },
 React.createElement("button", { onClick: speak, style: { background: speaking ? C.accent + "33" : C.card, border: "2px solid ".concat(speaking ? C.accent : C.border), borderRadius: "50%", width: "90px", height: "90px", fontSize: "2.2rem", cursor: "pointer", transition: "all 0.15s", display: "inline-flex", alignItems: "center", justifyContent: "center" } }, speaking ? "🔊" : "🔈"),
 React.createElement("div", { style: { fontSize: "0.78rem", color: C.muted, marginTop: "0.6rem" } }, speaking ? "מקריא..." : "לחץ להאזנה")),
 React.createElement("input", { ref: inputRef, value: answer, onChange: function (e) { return setAnswer(e.target.value); }, onKeyDown: function (e) { if (e.key === "Enter") {
 if (!submitted)
 submit();
 else
 next();
 } }, disabled: submitted, placeholder: settings.direction === "he_to_en" ? "כתוב את התרגום לאנגלית..." : "כתוב את התרגום לעברית...", style: { width: "100%", background: submitted ? (correct ? "#48bb7822" : "#fc818122") : C.card, border: "2px solid ".concat(submitted ? (correct ? C.green : "#fc8181") : C.border), color: C.text, padding: "0.9rem 1rem", borderRadius: "12px", fontSize: "1rem", outline: "none", boxSizing: "border-box", textAlign: "center", transition: "all 0.2s" } }),
 submitted && (React.createElement("div", { style: { marginTop: "0.75rem", background: correct ? C.green + "22" : "#fc818122", border: "1px solid ".concat(correct ? C.green : "#fc8181"), borderRadius: "10px", padding: "0.65rem 1rem", textAlign: "center" } },
 React.createElement("div", { style: { fontWeight: 700, fontSize: "1rem", color: correct ? C.green : "#fc8181", marginBottom: "0.4rem" } }, correct ? "✓ נכון!" : "✗ לא נכון"),
 React.createElement("div", { style: { fontSize: "0.92rem", color: C.text, fontWeight: 600 } }, p === null || p === void 0 ? void 0 : p.he),
 React.createElement("div", { style: { fontSize: "0.85rem", color: C.muted, marginTop: "0.2rem" } },
 "= ", p === null || p === void 0 ? void 0 :
 p.en),
 !correct && React.createElement("div", { style: { fontSize: "0.82rem", color: "#fc8181", marginTop: "0.3rem" } },
 "\u05D4\u05EA\u05E9\u05D5\u05D1\u05D4 \u05E9\u05DC\u05DA: ",
 answer))),
 React.createElement("div", { style: { display: "flex", gap: "0.75rem", marginTop: "1rem" } },
 !submitted ? (React.createElement("button", { onClick: submit, style: { flex: 1, background: C.accent, color: "#fff", border: "none", padding: "0.7rem", borderRadius: "12px", fontSize: "0.95rem", fontWeight: 600, cursor: "pointer" } }, "\u05D1\u05D3\u05D5\u05E7 \u2713")) : (React.createElement("button", { onClick: next, style: { flex: 1, background: C.green, color: "#fff", border: "none", padding: "0.7rem", borderRadius: "12px", fontSize: "0.95rem", fontWeight: 600, cursor: "pointer" } }, idx + 1 >= queue.length && retryQueue.length === 0 ? "סיום 🎉" : "הבא →")),
 React.createElement("button", { onClick: speak, style: { background: "transparent", border: "1px solid ".concat(C.border), color: C.muted, padding: "0.7rem 1rem", borderRadius: "12px", fontSize: "1rem", cursor: "pointer" } }, "\uD83D\uDD0A"))));
}
function DictationFlashcards(_a) {
 var set = _a.set, onBack = _a.onBack, settings = _a.settings, setSettings = _a.setSettings;
 var pairs = (set.pairs || []);
 var shuffle = function (a) { return __spreadArray([], a, true).sort(function () { return Math.random() - 0.5; }); };
 var buildOrder = function () { return (settings.order || "random") === "random" ? shuffle(pairs.map(function (_, i) { return i; })) : pairs.map(function (_, i) { return i; }); };
 var _b = React.useState(0), idx = _b[0], setIdx = _b[1];
 var _c = React.useState(false), flipped = _c[0], setFlipped = _c[1];
 var _d = React.useState(function () { return buildOrder(); }), order = _d[0], setOrder = _d[1];
 var _e = React.useState(false), showSet = _e[0], setShowSet = _e[1];
 var _f = React.useState(false), autoMode = _f[0], setAutoMode = _f[1];
 var autoRef = React.useRef(null);
 var getQ = function (p) { return settings.direction === "he_to_en" ? p.he : p.en; };
 var getA = function (p) { return settings.direction === "he_to_en" ? p.en : p.he; };
 var getLangQ = function () { return settings.direction === "he_to_en" ? "he-IL" : "en-US"; };
 var getLangA = function () { return settings.direction === "he_to_en" ? "en-US" : "he-IL"; };
 var speak = function (text, lang, onDone) {
 if (!window.speechSynthesis) {
 onDone && onDone();
 return;
 }
 window.speechSynthesis.cancel();
 var u = new SpeechSynthesisUtterance(text);
 u.lang = lang;
 u.rate = 0.75;
 u.pitch = 1.0;
 u.volume = 1.0;
 if (lang.startsWith("en")) {
 var voices = window.speechSynthesis.getVoices();
 var preferred = voices.find(function (v) { return v.lang === "en-US" && v.name.includes("Google US English"); }) ||
 voices.find(function (v) { return v.lang === "en-US" && v.name.includes("Google"); }) ||
 voices.find(function (v) { return v.lang === "en-US" && v.name.includes("Samantha"); }) ||
 voices.find(function (v) { return v.lang === "en-US" && v.name.includes("Alex"); }) ||
 voices.find(function (v) { return v.lang === "en-US" && !v.name.toLowerCase().includes("compact"); }) ||
 voices.find(function (v) { return v.lang.startsWith("en-US"); }) ||
 voices.find(function (v) { return v.lang.startsWith("en"); });
 if (preferred)
 u.voice = preferred;
 }
 u.onend = function () { return onDone && onDone(); };
 window.speechSynthesis.speak(u);
 };
 var reset = function () { setOrder(buildOrder()); setIdx(0); setFlipped(false); stopAuto(); };
 React.useEffect(function () { setOrder(buildOrder()); setIdx(0); setFlipped(false); stopAuto(); }, [settings.order, settings.direction]);
 React.useEffect(function () { return function () { var _a; (_a = window.speechSynthesis) === null || _a === void 0 ? void 0 : _a.cancel(); clearTimeout(autoRef.current); }; }, []);
 var stopAuto = function () { var _a; setAutoMode(false); (_a = window.speechSynthesis) === null || _a === void 0 ? void 0 : _a.cancel(); clearTimeout(autoRef.current); };
 var runAutoCard = function (currentIdx, currentOrder) {
 var p = pairs[currentOrder[currentIdx]];
 if (!p) {
 stopAuto();
 return;
 }
 setFlipped(false);
 speak(getQ(p), getLangQ(), function () {
 autoRef.current = setTimeout(function () {
 setFlipped(true);
 speak(getA(p), getLangA(), function () {
 autoRef.current = setTimeout(function () {
 var nextIdx = currentIdx + 1;
 if (nextIdx < currentOrder.length) {
 setIdx(nextIdx);
 runAutoCard(nextIdx, currentOrder);
 }
 else {
 stopAuto();
 }
 }, 1200);
 });
 }, 1500);
 });
 };
 var toggleAuto = function () {
 if (autoMode) {
 stopAuto();
 return;
 }
 setAutoMode(true);
 runAutoCard(idx, order);
 };
 if (pairs.length === 0)
 return React.createElement("div", { style: { textAlign: "center", padding: "3rem", color: C.muted } },
 React.createElement("button", { onClick: onBack }, "\u05D7\u05D6\u05E8\u05D4"));
 var p = pairs[order[idx]];
 return (React.createElement("div", { onClick: function () { return showSet && setShowSet(false); } },
 React.createElement("div", { style: { display: "flex", alignItems: "center", gap: "0.75rem", marginBottom: "1.5rem" } },
 React.createElement("button", { onClick: function () { stopAuto(); onBack(); }, style: { background: "transparent", border: "1px solid ".concat(C.border), color: C.muted, padding: "0.35rem 0.7rem", borderRadius: "8px", fontSize: "0.85rem", cursor: "pointer" } }, "\u2190 \u05D7\u05D6\u05E8\u05D4"),
 React.createElement("div", { style: { flex: 1, textAlign: "center", color: C.muted, fontSize: "0.85rem" } },
 idx + 1,
 " / ",
 pairs.length),
 React.createElement(DictSettings, { settings: settings, setSettings: setSettings, onReset: reset, show: showSet, setShow: setShowSet })),
 React.createElement("div", { style: { position: "relative", marginBottom: "1.5rem" } },
 React.createElement("div", { onClick: function () { if (!autoMode) {
 setFlipped(function (v) { return !v; });
 } }, style: { minHeight: "200px", background: flipped ? C.accent + "22" : C.card, border: "2px solid ".concat(flipped ? C.accent : C.border), borderRadius: "20px", padding: "2.5rem 1.5rem", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", cursor: autoMode ? "default" : "pointer", textAlign: "center", transition: "all 0.2s" } },
 React.createElement("div", { style: { fontSize: "0.75rem", color: C.muted, marginBottom: "0.75rem" } }, autoMode ? "🔊 מצב אוטו..." : flipped ? "תרגום" : "לחץ לראות תרגום"),
 React.createElement("div", { style: { fontSize: "1.5rem", fontWeight: 800, color: flipped ? C.accent : C.text } }, flipped ? getA(p) : getQ(p))),
 React.createElement("button", { onClick: function (e) { e.stopPropagation(); speak(flipped ? getA(p) : getQ(p), flipped ? getLangA() : getLangQ(), null); }, style: { position: "absolute", top: "0.6rem", left: "0.6rem", background: "transparent", border: "none", fontSize: "1.2rem", cursor: "pointer", color: C.muted, padding: "0.25rem", lineHeight: 1, borderRadius: "6px" }, title: "\u05D4\u05E9\u05DE\u05E2 \u05DE\u05D9\u05DC\u05D4" }, "\uD83D\uDD0A")),
 React.createElement("div", { style: { display: "flex", gap: "0.6rem", marginBottom: "0.75rem" } },
 React.createElement("button", { onClick: function () { if (!autoMode) {
 setIdx(function (i) { return Math.max(0, i - 1); });
 setFlipped(false);
 } }, disabled: idx === 0 || autoMode, style: { flex: 1, padding: "0.65rem", borderRadius: "10px", border: "1px solid ".concat(C.border), background: "transparent", color: idx === 0 || autoMode ? C.muted : C.text, cursor: idx === 0 || autoMode ? "default" : "pointer" } }, "\u2190 \u05D4\u05E7\u05D5\u05D3\u05DE\u05EA"),
 React.createElement("button", { onClick: function () { if (!autoMode && idx + 1 < pairs.length) {
 setIdx(function (i) { return i + 1; });
 setFlipped(false);
 } }, disabled: idx + 1 >= pairs.length || autoMode, style: { flex: 1, padding: "0.65rem", borderRadius: "10px", border: "1px solid ".concat(C.border), background: "transparent", color: idx + 1 >= pairs.length || autoMode ? C.muted : C.text, cursor: idx + 1 >= pairs.length || autoMode ? "default" : "pointer" } }, "\u05D4\u05D1\u05D0\u05D4 \u2192")),
 React.createElement("button", { onClick: toggleAuto, style: { width: "100%", padding: "0.65rem", borderRadius: "10px", border: "1px solid ".concat(autoMode ? C.accent : C.border), background: autoMode ? C.accent + "22" : "transparent", color: autoMode ? C.accent : C.text, cursor: "pointer", fontWeight: autoMode ? 700 : 400, fontSize: "0.9rem", display: "flex", alignItems: "center", justifyContent: "center", gap: "0.5rem" } }, autoMode ? "⏹️ עצור אוטו" : "▶️ אוטו — מקריא ומציג לבד"),
 React.createElement("div", { style: { display: "flex", gap: "0.35rem", justifyContent: "center", marginTop: "1rem", flexWrap: "wrap" } }, pairs.map(function (_, i) { return (React.createElement("div", { key: i, onClick: function () { if (!autoMode) {
 setIdx(i);
 setFlipped(false);
 } }, style: { width: "10px", height: "10px", borderRadius: "50%", background: i === idx ? C.accent : C.border, cursor: autoMode ? "default" : "pointer" } })); }))));
}
function DictationExam(_a) {
 var set = _a.set, settings = _a.settings, setSettings = _a.setSettings, onBack = _a.onBack;
 var pairs = set.pairs || [];
 var getQ = function (p) { return settings.direction === "he_to_en" ? p.he : p.en; };
 var getA = function (p) { return settings.direction === "he_to_en" ? p.en : p.he; };
 var _b = React.useState(function () { return pairs.map(function () { return ""; }); }), answers = _b[0], setAnswers = _b[1];
 var _c = React.useState(false), submitted = _c[0], setSubmitted = _c[1];
 var _d = React.useState(0), currentIdx = _d[0], setCurrentIdx = _d[1];
 var _e = React.useState(false), showExamSet = _e[0], setShowExamSet = _e[1];
 var inputRef = React.useRef(null);
 React.useEffect(function () { if (inputRef.current)
 inputRef.current.focus(); }, [currentIdx]);
 if (pairs.length === 0)
 return React.createElement("div", { style: { textAlign: "center", padding: "3rem", color: C.muted } },
 React.createElement("button", { onClick: onBack }, "\u05D7\u05D6\u05E8\u05D4"));
 var score = pairs.filter(function (p, i) { return answers[i].trim().toLowerCase() === getA(p).toLowerCase(); }).length;
 if (submitted)
 return (React.createElement("div", null,
 React.createElement("div", { style: { display: "flex", alignItems: "center", gap: "0.75rem", marginBottom: "1.5rem" } },
 React.createElement("button", { onClick: onBack, style: { background: "transparent", border: "1px solid ".concat(C.border), color: C.muted, padding: "0.35rem 0.7rem", borderRadius: "8px", fontSize: "0.85rem", cursor: "pointer" } }, "\u2190 \u05D7\u05D6\u05E8\u05D4"),
 React.createElement("h2", { style: { flex: 1, fontSize: "1.15rem", fontWeight: 700, margin: 0, color: C.text } }, "\u05EA\u05D5\u05E6\u05D0\u05D5\u05EA \u05D4\u05DE\u05D1\u05D7\u05DF")),
 React.createElement("div", { style: { textAlign: "center", padding: "1.25rem", background: score / pairs.length >= 0.8 ? C.green + "22" : score / pairs.length >= 0.5 ? "#f6ad5522" : "#fc818122", border: "1px solid ".concat(score / pairs.length >= 0.8 ? C.green : score / pairs.length >= 0.5 ? "#f6ad55" : "#fc8181"), borderRadius: "16px", marginBottom: "1.5rem" } },
 React.createElement("div", { style: { fontSize: "2.5rem", marginBottom: "0.5rem" } }, score / pairs.length >= 0.8 ? "🎉" : score / pairs.length >= 0.5 ? "📚" : "💪"),
 React.createElement("div", { style: { fontSize: "1.4rem", fontWeight: 800, color: C.text } },
 score,
 " / ",
 pairs.length),
 React.createElement("div", { style: { color: C.muted, fontSize: "0.88rem", marginTop: "0.25rem" } }, score / pairs.length >= 0.8 ? "מצוין!" : score / pairs.length >= 0.5 ? "טוב, המשך להתאמן" : "כדאי לחזור שוב")),
 React.createElement("div", { style: { display: "flex", flexDirection: "column", gap: "0.6rem" } }, pairs.map(function (p, i) {
 var correct = answers[i].trim().toLowerCase() === getA(p).toLowerCase();
 return (React.createElement("div", { key: i, style: { display: "flex", alignItems: "center", gap: "0.75rem", padding: "0.65rem 0.9rem", background: correct ? C.green + "15" : "#fc818115", border: "1px solid ".concat(correct ? C.green + "55" : "#fc818155"), borderRadius: "10px" } },
 React.createElement("span", { style: { fontSize: "1.1rem" } }, correct ? "✓" : "✗"),
 React.createElement("div", { style: { flex: 1 } },
 React.createElement("div", { style: { fontWeight: 700, fontSize: "0.88rem", color: C.text } }, getQ(p)),
 !correct && React.createElement("div", { style: { fontSize: "0.78rem", color: C.muted } },
 "\u05DB\u05EA\u05D1\u05EA: ",
 React.createElement("span", { style: { color: "#fc8181" } }, answers[i] || "(לא ענית)"),
 " \u00B7 \u05E0\u05DB\u05D5\u05DF: ",
 React.createElement("span", { style: { color: C.green, fontWeight: 700 } }, getA(p))))));
 })),
 React.createElement("button", { onClick: function () { setAnswers(pairs.map(function () { return ""; })); setSubmitted(false); setCurrentIdx(0); }, style: { width: "100%", marginTop: "1.25rem", background: C.accent, color: "#fff", border: "none", padding: "0.7rem", borderRadius: "12px", fontSize: "0.95rem", fontWeight: 600, cursor: "pointer" } }, "\uD83D\uDD04 \u05E0\u05E1\u05D4 \u05E9\u05D5\u05D1")));
 var p = pairs[currentIdx];
 var progress = (currentIdx / pairs.length) * 100;
 return (React.createElement("div", null,
 React.createElement("div", { style: { display: "flex", alignItems: "center", gap: "0.75rem", marginBottom: "1rem" } },
 React.createElement("button", { onClick: onBack, style: { background: "transparent", border: "1px solid ".concat(C.border), color: C.muted, padding: "0.35rem 0.7rem", borderRadius: "8px", fontSize: "0.85rem", cursor: "pointer" } }, "\u2190 \u05D7\u05D6\u05E8\u05D4"),
 React.createElement("div", { style: { flex: 1, textAlign: "center", color: C.muted, fontSize: "0.85rem" } },
 currentIdx + 1,
 " / ",
 pairs.length),
 React.createElement(ExamSettings, { settings: settings, setSettings: setSettings, onReset: function () { setAnswers(pairs.map(function () { return ""; })); setSubmitted(false); setCurrentIdx(0); }, show: showExamSet, setShow: setShowExamSet })),
 React.createElement("div", { style: { height: "4px", background: C.border, borderRadius: "999px", marginBottom: "1.5rem" } },
 React.createElement("div", { style: { height: "100%", width: progress + "%", background: C.accent, borderRadius: "999px", transition: "width 0.3s" } })),
 React.createElement("div", { style: { background: C.card, border: "1px solid ".concat(C.border), borderRadius: "16px", padding: "1.75rem", textAlign: "center", marginBottom: "1.25rem" } },
 React.createElement("div", { style: { fontSize: "0.78rem", color: C.muted, marginBottom: "0.5rem" } }, settings.direction === "he_to_en" ? "תרגם לאנגלית" : "תרגם לעברית"),
 React.createElement("div", { style: { fontSize: "1.5rem", fontWeight: 800, color: C.text } }, getQ(p))),
 React.createElement("input", { ref: inputRef, value: answers[currentIdx], onChange: function (e) { return setAnswers(function (prev) { var n = __spreadArray([], prev, true); n[currentIdx] = e.target.value; return n; }); }, onKeyDown: function (e) {
 if (e.key === "Enter") {
 if (currentIdx + 1 < pairs.length)
 setCurrentIdx(function (i) { return i + 1; });
 else
 setSubmitted(true);
 }
 }, placeholder: "\u05DB\u05EA\u05D5\u05D1 \u05D0\u05EA \u05D4\u05EA\u05E9\u05D5\u05D1\u05D4...", style: { width: "100%", background: C.card, border: "1px solid ".concat(C.border), color: C.text, padding: "0.85rem 1rem", borderRadius: "12px", fontSize: "1rem", outline: "none", boxSizing: "border-box", textAlign: "center" } }),
 React.createElement("div", { style: { display: "flex", gap: "0.6rem", marginTop: "1rem" } },
 currentIdx > 0 && React.createElement("button", { onClick: function () { return setCurrentIdx(function (i) { return i - 1; }); }, style: { flex: 1, background: "transparent", border: "1px solid ".concat(C.border), color: C.text, padding: "0.65rem", borderRadius: "10px", fontSize: "0.9rem", cursor: "pointer" } }, "\u2190 \u05D4\u05E7\u05D5\u05D3\u05DD"),
 React.createElement("button", { onClick: function () { if (currentIdx + 1 < pairs.length)
 setCurrentIdx(function (i) { return i + 1; });
 else
 setSubmitted(true); }, style: { flex: 2, background: currentIdx + 1 >= pairs.length ? C.accent : "transparent", border: "1px solid ".concat(currentIdx + 1 >= pairs.length ? C.accent : C.border), color: currentIdx + 1 >= pairs.length ? "#fff" : C.text, padding: "0.65rem", borderRadius: "10px", fontSize: "0.9rem", fontWeight: currentIdx + 1 >= pairs.length ? 700 : 400, cursor: "pointer" } }, currentIdx + 1 >= pairs.length ? "סיום וראה תוצאות ✓" : "הבא →"))));
}
var QMSettings = DictSettings;
var ExamSettings = DictSettings;
function QuizMode(_a) {
 var set = _a.set, settings = _a.settings, setSettings = _a.setSettings, onBack = _a.onBack, user = _a.user;
 var pairs = set.pairs || [];
 var getQ = function (p) { return settings.direction === "en_to_he" ? p.en : settings.direction === "he_to_en" ? p.he : [p.en, p.he][Math.floor(Math.random() * 2)]; };
 var getA = function (p) { return settings.direction === "en_to_he" ? p.he : settings.direction === "he_to_en" ? p.en : (getQ(p) === p.en ? p.he : p.en); };
 var shuffle = function (a) { return __spreadArray([], a, true).sort(function () { return Math.random() - 0.5; }); };
 var _b = React.useState(function () { return shuffle(__spreadArray([], pairs, true)); }), queue = _b[0], setQueue = _b[1];
 var _c = React.useState([]), retryQueue = _c[0], setRetryQueue = _c[1];
 var _d = React.useState(0), idx = _d[0], setIdx = _d[1];
 var _e = React.useState(false), showQMSet = _e[0], setShowQMSet = _e[1];
 var _f = React.useState(""), answer = _f[0], setAnswer = _f[1];
 var _g = React.useState(false), submitted = _g[0], setSubmitted = _g[1];
 var _h = React.useState(null), correct = _h[0], setCorrect = _h[1];
 var _j = React.useState(0), score = _j[0], setScore = _j[1];
 var _k = React.useState(false), done = _k[0], setDone = _k[1];
 var _l = React.useState([]), options = _l[0], setOptions = _l[1];
 var _m = React.useState(1), round = _m[0], setRound = _m[1];
 var p = queue[idx];
 React.useEffect(function () {
 if (settings.mode === "multiple" && p) {
 var correctAns = getA(p);
 var wrong = shuffle(pairs.filter(function (x) { return x.id !== p.id; })).slice(0, 3).map(function (x) { return settings.direction === "en_to_he" ? x.he : settings.direction === "he_to_en" ? x.en : (getQ(p) === p.en ? x.he : x.en); });
 setOptions(shuffle(__spreadArray([correctAns], wrong, true)));
 }
 setAnswer("");
 setSubmitted(false);
 setCorrect(null);
 }, [idx, p === null || p === void 0 ? void 0 : p.id, queue]);
 var submit = function () {
 if (!answer.trim() && settings.mode !== "multiple")
 return;
 var a = getA(p);
 var isCorrect = settings.mode === "multiple" ? answer === a : answer.trim().toLowerCase() === a.toLowerCase();
 setCorrect(isCorrect);
 setSubmitted(true);
 if (isCorrect)
 setScore(function (s) { return s + 1; });
 else
 setRetryQueue(function (q) { return __spreadArray(__spreadArray([], q, true), [p], false); });
 };
 var next = function () {
 if (idx + 1 >= queue.length) {
 if (retryQueue.length > 0) {
 setQueue(shuffle(__spreadArray([], retryQueue, true)));
 setRetryQueue([]);
 setIdx(0);
 setRound(function (r) { return r + 1; });
 }
 else {
 setDone(true);
 }
 }
 else {
 setIdx(function (i) { return i + 1; });
 }
 };
 if (pairs.length === 0)
 return React.createElement("div", { style: { textAlign: "center", padding: "3rem", color: C.muted } },
 React.createElement("button", { onClick: onBack }, "\u05D7\u05D6\u05E8\u05D4"));
 if (done)
 return (React.createElement("div", { style: { textAlign: "center", padding: "3rem" } },
 React.createElement("div", { style: { fontSize: "3rem", marginBottom: "1rem" } }, score / pairs.length >= 0.8 ? "🎉" : "📚"),
 React.createElement("div", { style: { fontSize: "1.3rem", fontWeight: 700, marginBottom: "0.5rem" } },
 score,
 "/",
 pairs.length,
 " \u05E0\u05DB\u05D5\u05DF"),
 round > 1 && React.createElement("div", { style: { fontSize: "0.82rem", color: C.accent, marginBottom: "0.4rem", fontWeight: 600 } },
 "\u2713 \u05E2\u05D1\u05E8\u05EA ",
 round,
 " \u05E1\u05D1\u05D1\u05D9\u05DD \u05E2\u05D3 \u05E9\u05D9\u05D3\u05E2\u05EA \u05D4\u05DB\u05DC!"),
 React.createElement("div", { style: { color: C.muted, marginBottom: "1.5rem" } }, score / pairs.length >= 0.8 ? "מצוין!" : score / pairs.length >= 0.5 ? "טוב, המשך להתאמן" : "כדאי לחזור שוב"),
 React.createElement("div", { style: { display: "flex", gap: "0.75rem", justifyContent: "center", flexWrap: "wrap" } },
 React.createElement("button", { onClick: function () { setIdx(0); setScore(0); setDone(false); }, style: { background: C.accent, color: "#fff", border: "none", padding: "0.6rem 1.25rem", borderRadius: "10px", fontSize: "0.9rem", fontWeight: 600, cursor: "pointer" } }, "\uD83D\uDD04 \u05E9\u05D5\u05D1"),
 React.createElement("button", { onClick: onBack, style: { background: "transparent", border: "1px solid ".concat(C.border), color: C.text, padding: "0.6rem 1.25rem", borderRadius: "10px", fontSize: "0.9rem", cursor: "pointer" } }, "\u2190 \u05D7\u05D6\u05E8\u05D4"))));
 return (React.createElement("div", null,
 React.createElement("div", { style: { display: "flex", alignItems: "center", gap: "0.75rem", marginBottom: "1.5rem" } },
 React.createElement("button", { onClick: onBack, style: { background: "transparent", border: "1px solid ".concat(C.border), color: C.muted, padding: "0.35rem 0.7rem", borderRadius: "8px", fontSize: "0.85rem", cursor: "pointer" } }, "\u2190 \u05D7\u05D6\u05E8\u05D4"),
 React.createElement("div", { style: { flex: 1, textAlign: "center", color: C.muted, fontSize: "0.85rem" } },
 idx + 1,
 "/",
 queue.length,
 " \u00B7 \u2713 ",
 score),
 round > 1 && React.createElement("div", { style: { background: C.accent + "22", color: C.accent, fontSize: "0.75rem", fontWeight: 700, padding: "0.2rem 0.6rem", borderRadius: "20px" } },
 "\uD83D\uDD04 \u05E1\u05D1\u05D1 ",
 round),
 React.createElement(QMSettings, { settings: settings, setSettings: setSettings, onReset: function () { setQueue(shuffle(__spreadArray([], pairs, true))); setRetryQueue([]); setIdx(0); setScore(0); setDone(false); setRound(1); }, show: showQMSet, setShow: setShowQMSet })),
 React.createElement("div", { style: { background: C.card, border: "1px solid ".concat(C.border), borderRadius: "16px", padding: "1.5rem", textAlign: "center", marginBottom: "1.25rem" } },
 React.createElement("div", { style: { fontSize: "1.4rem", fontWeight: 700 } }, getQ(p))),
 settings.mode === "multiple" ? (React.createElement("div", { style: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.6rem", marginBottom: "1rem" } }, options.map(function (opt) { return (React.createElement("button", { key: opt, onClick: function () { if (!submitted) {
 setAnswer(opt);
 setTimeout(function () { var isC = opt === getA(p); setCorrect(isC); setSubmitted(true); if (isC)
 setScore(function (s) { return s + 1; }); }, 0);
 } }, style: { background: submitted ? (opt === getA(p) ? C.green + "33" : opt === answer && !correct ? "#fc818133" : C.card) : C.card, border: "1px solid ".concat(submitted ? (opt === getA(p) ? C.green : opt === answer && !correct ? "#fc8181" : C.border) : C.border), color: C.text, padding: "0.75rem", borderRadius: "12px", fontSize: "0.9rem", cursor: "pointer", fontWeight: submitted && opt === getA(p) ? 700 : 400 } }, opt)); }))) : (React.createElement("div", { style: { marginBottom: "1rem" } },
 React.createElement("input", { value: answer, onChange: function (e) { return setAnswer(e.target.value); }, onKeyDown: function (e) { return e.key === "Enter" && !submitted && submit(); }, disabled: submitted, placeholder: "\u05D4\u05DB\u05E0\u05E1 \u05EA\u05E9\u05D5\u05D1\u05D4...", style: { background: C.card, border: "2px solid ".concat(submitted ? (correct ? C.green : "#fc8181") : C.border), color: C.text, padding: "0.75rem 1rem", borderRadius: "12px", fontSize: "1rem", outline: "none", width: "100%", textAlign: "center" } }))),
 submitted && React.createElement("div", { style: { background: correct ? C.green + "22" : "#fc818122", border: "1px solid ".concat(correct ? C.green : "#fc8181"), borderRadius: "12px", padding: "0.75rem 1rem", textAlign: "center", marginBottom: "1rem", fontWeight: 600, color: correct ? C.green : "#fc8181" } }, correct ? "✓ נכון!" : "✗ לא נכון — התשובה: " + getA(p)),
 (!submitted && settings.mode !== "multiple") && React.createElement("button", { onClick: submit, style: { width: "100%", background: C.accent, color: "#fff", border: "none", padding: "0.7rem", borderRadius: "12px", fontSize: "0.95rem", fontWeight: 600, cursor: "pointer" } }, "\u05D1\u05D3\u05D5\u05E7"),
 submitted && React.createElement("button", { onClick: next, style: { width: "100%", background: C.green, color: "#fff", border: "none", padding: "0.7rem", borderRadius: "12px", fontSize: "0.95rem", fontWeight: 600, cursor: "pointer" } }, idx + 1 >= pairs.length ? "סיום 🎉" : "הבא →")));
}
function GradesTracker(_a) {
 var user = _a.user, saveUser = _a.saveUser;
 var grades = user.gradesData || {};
 var _b = React.useState(""), newSubject = _b[0], setNewSubject = _b[1];
 var _c = React.useState(""), newGrade = _c[0], setNewGrade = _c[1];
 var _d = React.useState(""), newLabel = _d[0], setNewLabel = _d[1];
 var _e = React.useState(null), selectedSubject = _e[0], setSelectedSubject = _e[1];
 var _f = React.useState(false), showAddSubject = _f[0], setShowAddSubject = _f[1];
 var _g = React.useState(""), newSubjectName = _g[0], setNewSubjectName = _g[1];
 var _h = React.useState(""), goalInput = _h[0], setGoalInput = _h[1];
 var _j = React.useState(false), showSummary = _j[0], setShowSummary = _j[1];
 var saveGrades = function (data) { return saveUser(__assign(__assign({}, user), { gradesData: data })); };
 var addSubject = function () {
 var _a;
 if (!newSubjectName.trim())
 return;
 var key = newSubjectName.trim();
 if (grades[key])
 return;
 saveGrades(__assign(__assign({}, grades), (_a = {}, _a[key] = { entries: [], goal: null }, _a)));
 setNewSubjectName("");
 setShowAddSubject(false);
 setSelectedSubject(key);
 };
 var addEntry = function (subject) {
 var _a;
 var g = parseFloat(newGrade);
 if (!newGrade || isNaN(g) || g < 0 || g > 100)
 return;
 var entry = { id: genId(), label: newLabel.trim() || "ציון", grade: g, date: Date.now() };
 var subj = grades[subject] || { entries: [], goal: null };
 var updated = __assign(__assign({}, grades), (_a = {}, _a[subject] = __assign(__assign({}, subj), { entries: __spreadArray(__spreadArray([], (subj.entries || []), true), [entry], false) }), _a));
 saveGrades(updated);
 setNewGrade("");
 setNewLabel("");
 };
 var deleteEntry = function (subject, id) {
 var _a;
 var subj = grades[subject];
 saveGrades(__assign(__assign({}, grades), (_a = {}, _a[subject] = __assign(__assign({}, subj), { entries: (subj.entries || []).filter(function (e) { return e.id !== id; }) }), _a)));
 };
 var setGoal = function (subject) {
 var _a;
 var g = parseFloat(goalInput);
 if (isNaN(g) || g < 0 || g > 100)
 return;
 saveGrades(__assign(__assign({}, grades), (_a = {}, _a[subject] = __assign(__assign({}, grades[subject]), { goal: g }), _a)));
 setGoalInput("");
 };
 var deleteSubject = function (subject) {
 var copy = __assign({}, grades);
 delete copy[subject];
 saveGrades(copy);
 if (selectedSubject === subject)
 setSelectedSubject(null);
 };
 var getAvg = function (entries) {
 if (!entries || entries.length === 0)
 return null;
 return Math.round(entries.reduce(function (s, e) { return s + e.grade; }, 0) / entries.length * 10) / 10;
 };
 var getTrend = function (entries) {
 if (!entries || entries.length < 2)
 return null;
 var last3 = entries.slice(-3);
 var first = last3[0].grade, last = last3[last3.length - 1].grade;
 return last - first;
 };
 var getColor = function (g) { return g >= 90 ? "#48bb78" : g >= 75 ? C.accent : g >= 60 ? "#f6ad55" : "#fc8181"; };
 var subjects = Object.keys(grades);
 var inp = { background: C.card, border: "1px solid ".concat(C.border), color: C.text, padding: "0.45rem 0.7rem", borderRadius: "8px", fontSize: "0.85rem", outline: "none" };
 var selected = selectedSubject && grades[selectedSubject];
 return (React.createElement("div", { style: { display: "flex", flexDirection: "column", gap: "1rem" } },
 React.createElement("div", { style: { display: "flex", flexWrap: "wrap", gap: "0.5rem", alignItems: "center" } },
 subjects.map(function (s) {
 var avg = getAvg(grades[s].entries);
 var trend = getTrend(grades[s].entries);
 var isActive = selectedSubject === s;
 return (React.createElement("button", { key: s, onClick: function () { return setSelectedSubject(isActive ? null : s); }, style: { padding: "0.45rem 0.85rem", borderRadius: "12px", border: "1px solid ".concat(isActive ? C.accent : C.border), background: isActive ? C.accent + "22" : "transparent", color: isActive ? C.accent : C.text, cursor: "pointer", display: "flex", alignItems: "center", gap: "0.4rem", fontSize: "0.88rem", fontWeight: isActive ? 700 : 400 } },
 React.createElement("span", null, s),
 avg !== null && React.createElement("span", { style: { background: getColor(avg), color: "#fff", borderRadius: "8px", padding: "0.05rem 0.4rem", fontSize: "0.75rem", fontWeight: 700 } }, avg),
 trend !== null && React.createElement("span", { style: { fontSize: "0.72rem", color: trend > 0 ? "#48bb78" : trend < 0 ? "#fc8181" : C.muted } }, trend > 0 ? "↑" : trend < 0 ? "↓" : "→")));
 }),
 showAddSubject ? (React.createElement("div", { style: { display: "flex", gap: "0.4rem", alignItems: "center" } },
 React.createElement("input", { style: __assign(__assign({}, inp), { width: "120px" }), placeholder: "\u05E9\u05DD \u05DE\u05E7\u05E6\u05D5\u05E2", value: newSubjectName, onChange: function (e) { return setNewSubjectName(e.target.value); }, onKeyDown: function (e) { return e.key === "Enter" && addSubject(); }, autoFocus: true }),
 React.createElement("button", { onClick: addSubject, style: { background: C.accent, color: "#fff", border: "none", borderRadius: "8px", padding: "0.45rem 0.7rem", cursor: "pointer", fontSize: "0.82rem" } }, "\u05D4\u05D5\u05E1\u05E3"),
 React.createElement("button", { onClick: function () { return setShowAddSubject(false); }, style: { background: "transparent", border: "1px solid ".concat(C.border), color: C.muted, borderRadius: "8px", padding: "0.45rem 0.7rem", cursor: "pointer", fontSize: "0.82rem" } }, "\u2715"))) : (React.createElement("button", { onClick: function () { return setShowAddSubject(true); }, style: { padding: "0.45rem 0.85rem", borderRadius: "12px", border: "1px dashed ".concat(C.border), background: "transparent", color: C.muted, cursor: "pointer", fontSize: "0.85rem" } }, "+ \u05DE\u05E7\u05E6\u05D5\u05E2")),
 subjects.length > 0 && (React.createElement("button", { onClick: function () { return setShowSummary(function (v) { return !v; }); }, style: { padding: "0.45rem 0.85rem", borderRadius: "12px", border: "1px solid ".concat(showSummary ? C.accent : C.border), background: showSummary ? C.accent + "22" : "transparent", color: showSummary ? C.accent : C.muted, cursor: "pointer", fontSize: "0.85rem", fontWeight: showSummary ? 700 : 400 } }, "\uD83D\uDCC8 \u05E1\u05D9\u05DB\u05D5\u05DD \u05DB\u05DC\u05DC\u05D9"))),
 showSummary && subjects.length > 0 && (function () {
 var subjData = subjects.map(function (s) {
 var entries = grades[s].entries || [];
 var avg = entries.length > 0 ? Math.round(entries.reduce(function (a, e) { return a + e.grade; }, 0) / entries.length * 10) / 10 : null;
 var trend = getTrend(entries);
 var goal = grades[s].goal;
 return { name: s, avg: avg, trend: trend, goal: goal, count: entries.length };
 }).filter(function (s) { return s.avg !== null; });
 var overallAvg = subjData.length > 0 ? Math.round(subjData.reduce(function (a, s) { return a + s.avg; }, 0) / subjData.length * 10) / 10 : null;
 var best = subjData.length > 0 ? subjData.reduce(function (a, b) { return b.avg > a.avg ? b : a; }) : null;
 var worst = subjData.length > 0 ? subjData.reduce(function (a, b) { return b.avg < a.avg ? b : a; }) : null;
 var improving = subjData.filter(function (s) { return s.trend > 0; }).length;
 return (React.createElement("div", { style: { background: C.card, borderRadius: "16px", border: "1px solid ".concat(C.border), overflow: "hidden" } },
 React.createElement("div", { style: { padding: "1rem", borderBottom: "1px solid ".concat(C.border), display: "flex", gap: "0.75rem", flexWrap: "wrap" } },
 React.createElement("div", { style: { flex: 1, minWidth: "120px", textAlign: "center", padding: "0.6rem", background: overallAvg ? getColor(overallAvg) + "18" : "transparent", borderRadius: "12px", border: "1px solid ".concat(overallAvg ? getColor(overallAvg) + "44" : C.border) } },
 React.createElement("div", { style: { fontSize: "2rem", fontWeight: 800, color: overallAvg ? getColor(overallAvg) : C.muted } }, overallAvg || "—"),
 React.createElement("div", { style: { fontSize: "0.75rem", color: C.muted, marginTop: "0.1rem" } }, "\u05DE\u05DE\u05D5\u05E6\u05E2 \u05DB\u05DC\u05DC\u05D9")),
 best && React.createElement("div", { style: { flex: 1, minWidth: "100px", textAlign: "center", padding: "0.6rem", background: "#48bb7818", borderRadius: "12px", border: "1px solid #48bb7844" } },
 React.createElement("div", { style: { fontSize: "1.3rem", fontWeight: 700, color: "#48bb78" } }, best.avg),
 React.createElement("div", { style: { fontSize: "0.72rem", color: C.muted } },
 "\uD83C\uDFC6 ",
 best.name)),
 worst && worst.name !== (best === null || best === void 0 ? void 0 : best.name) && React.createElement("div", { style: { flex: 1, minWidth: "100px", textAlign: "center", padding: "0.6rem", background: "#fc818118", borderRadius: "12px", border: "1px solid #fc818144" } },
 React.createElement("div", { style: { fontSize: "1.3rem", fontWeight: 700, color: "#fc8181" } }, worst.avg),
 React.createElement("div", { style: { fontSize: "0.72rem", color: C.muted } },
 "\uD83D\uDCAA ",
 worst.name)),
 improving > 0 && React.createElement("div", { style: { flex: 1, minWidth: "100px", textAlign: "center", padding: "0.6rem", background: C.accent + "18", borderRadius: "12px", border: "1px solid ".concat(C.accent, "44") } },
 React.createElement("div", { style: { fontSize: "1.3rem", fontWeight: 700, color: C.accent } }, improving),
 React.createElement("div", { style: { fontSize: "0.72rem", color: C.muted } }, "\uD83D\uDCC8 \u05DE\u05E7\u05E6\u05D5\u05E2\u05D5\u05EA \u05D1\u05E2\u05DC\u05D9\u05D9\u05D4"))),
 React.createElement("div", { style: { padding: "0.5rem 0" } }, subjData.sort(function (a, b) { return b.avg - a.avg; }).map(function (s) {
 var pct = Math.min(s.avg, 100);
 var goalPct = s.goal ? Math.min(s.goal, 100) : null;
 return (React.createElement("div", { key: s.name, style: { padding: "0.5rem 1rem", borderBottom: "1px solid ".concat(C.border, "22") } },
 React.createElement("div", { style: { display: "flex", alignItems: "center", gap: "0.5rem", marginBottom: "0.3rem" } },
 React.createElement("span", { style: { flex: 1, fontWeight: 600, fontSize: "0.88rem", color: C.text } }, s.name),
 React.createElement("span", { style: { fontSize: "0.75rem", color: C.muted } },
 s.count,
 " \u05E6\u05D9\u05D5\u05E0\u05D9\u05DD"),
 s.trend !== null && React.createElement("span", { style: { fontSize: "0.75rem", fontWeight: 600, color: s.trend > 0 ? "#48bb78" : s.trend < 0 ? "#fc8181" : C.muted } }, s.trend > 0 ? "\u2191+".concat(Math.round(s.trend * 10) / 10) : s.trend < 0 ? "\u2193".concat(Math.round(s.trend * 10) / 10) : "→"),
 React.createElement("span", { style: { fontWeight: 800, fontSize: "0.95rem", color: getColor(s.avg), minWidth: "32px", textAlign: "left" } }, s.avg)),
 React.createElement("div", { style: { position: "relative", height: "8px", background: C.border, borderRadius: "10px", overflow: "visible" } },
 React.createElement("div", { style: { height: "100%", width: "".concat(pct, "%"), background: getColor(s.avg), borderRadius: "10px", transition: "width 0.4s" } }),
 goalPct && React.createElement("div", { style: { position: "absolute", top: "-3px", left: "".concat(goalPct, "%"), transform: "translateX(-50%)", fontSize: "0.65rem", color: C.accent, lineHeight: 1 } }, "\uD83C\uDFAF")),
 s.goal && React.createElement("div", { style: { fontSize: "0.7rem", color: s.avg >= s.goal ? "#48bb78" : "#f6ad55", marginTop: "0.2rem", textAlign: "left" } }, s.avg >= s.goal ? "\u2705 \u05D4\u05D2\u05E2\u05EA \u05DC\u05D9\u05E2\u05D3 ".concat(s.goal) : "\u05D9\u05E2\u05D3: ".concat(s.goal, " \u2014 \u05D7\u05E1\u05E8 ").concat(Math.round((s.goal - s.avg) * 10) / 10, " \u05E0\u05E7\u05D5\u05D3\u05D5\u05EA"))));
 }))));
 })(),
 selectedSubject && selected && (React.createElement("div", { style: { background: C.card, borderRadius: "16px", border: "1px solid ".concat(C.border), overflow: "hidden" } },
 React.createElement("div", { style: { padding: "0.85rem 1rem", borderBottom: "1px solid ".concat(C.border), display: "flex", alignItems: "center", gap: "0.75rem" } },
 React.createElement("div", { style: { flex: 1 } },
 React.createElement("div", { style: { fontWeight: 700, fontSize: "1rem", color: C.text } }, selectedSubject),
 (function () {
 var avg = getAvg(selected.entries);
 var trend = getTrend(selected.entries);
 var goal = selected.goal;
 return avg !== null && (React.createElement("div", { style: { display: "flex", gap: "0.75rem", marginTop: "0.2rem", alignItems: "center", flexWrap: "wrap" } },
 React.createElement("span", { style: { fontSize: "0.82rem", color: C.muted } },
 "\u05DE\u05DE\u05D5\u05E6\u05E2: ",
 React.createElement("b", { style: { color: getColor(avg), fontSize: "0.95rem" } }, avg)),
 trend !== null && React.createElement("span", { style: { fontSize: "0.78rem", color: trend > 0 ? "#48bb78" : trend < 0 ? "#fc8181" : C.muted } },
 trend > 0 ? "📈 עולה" : "📉 יורד",
 " (",
 trend > 0 ? "+" : "",
 Math.round(trend * 10) / 10,
 " \u05E0\u05E7\u05D5\u05D3\u05D5\u05EA)"),
 goal && React.createElement("span", { style: { fontSize: "0.78rem", color: avg >= goal ? "#48bb78" : "#f6ad55" } },
 "\u05D9\u05E2\u05D3: ",
 goal,
 " ",
 avg >= goal ? "✅" : "(\u05D7\u05E1\u05E8 ".concat(Math.round((goal - avg) * 10) / 10, ")"))));
 })()),
 React.createElement("div", { style: { display: "flex", gap: "0.4rem", alignItems: "center" } },
 React.createElement("input", { style: __assign(__assign({}, inp), { width: "60px", textAlign: "center" }), placeholder: "\u05D9\u05E2\u05D3", value: goalInput, onChange: function (e) { return setGoalInput(e.target.value); }, onKeyDown: function (e) { return e.key === "Enter" && setGoal(selectedSubject); } }),
 React.createElement("button", { onClick: function () { return setGoal(selectedSubject); }, style: { background: "transparent", border: "1px solid ".concat(C.border), color: C.muted, borderRadius: "8px", padding: "0.35rem 0.5rem", cursor: "pointer", fontSize: "0.75rem" } }, "\u05E7\u05D1\u05E2")),
 React.createElement("button", { onClick: function () { return deleteSubject(selectedSubject); }, style: { background: "transparent", border: "none", color: "#fc8181", cursor: "pointer", fontSize: "0.9rem", padding: "0.25rem" } }, "\uD83D\uDDD1\uFE0F")),
 (function () {
 var avg = getAvg(selected.entries);
 var goal = selected.goal;
 if (avg === null)
 return null;
 return (React.createElement("div", { style: { padding: "0.5rem 1rem", borderBottom: "1px solid ".concat(C.border) } },
 React.createElement("div", { style: { height: "10px", background: C.border, borderRadius: "10px", overflow: "hidden" } },
 React.createElement("div", { style: { height: "100%", width: "".concat(Math.min(avg, 100), "%"), background: "linear-gradient(90deg,".concat(getColor(avg), ",").concat(getColor(avg), "bb)"), borderRadius: "10px", transition: "width 0.4s" } })),
 goal && (React.createElement("div", { style: { position: "relative", height: "8px", marginTop: "2px" } },
 React.createElement("div", { style: { position: "absolute", left: "".concat(Math.min(goal, 100), "%"), top: 0, transform: "translateX(-50%)", fontSize: "0.6rem", color: C.accent } }, "\uD83C\uDFAF")))));
 })(),
 selected.entries && selected.entries.length > 1 && (React.createElement("div", { style: { padding: "0.75rem 1rem", borderBottom: "1px solid ".concat(C.border), display: "flex", alignItems: "flex-end", gap: "4px", height: "70px" } }, selected.entries.map(function (e, i) {
 var h = Math.max(8, (e.grade / 100) * 50);
 return (React.createElement("div", { key: e.id, style: { flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: "2px", cursor: "pointer" }, title: "".concat(e.label, ": ").concat(e.grade) },
 React.createElement("div", { style: { fontSize: "0.6rem", color: getColor(e.grade), fontWeight: 700 } }, e.grade),
 React.createElement("div", { style: { width: "100%", height: "".concat(h, "px"), background: getColor(e.grade), borderRadius: "3px 3px 0 0", opacity: 0.85 } })));
 }))),
 React.createElement("div", { style: { padding: "0.75rem 1rem", borderBottom: "1px solid ".concat(C.border), display: "flex", gap: "0.5rem", alignItems: "center" } },
 React.createElement("input", { style: __assign(__assign({}, inp), { flex: 2 }), placeholder: "\u05EA\u05D9\u05D0\u05D5\u05E8 (\u05DC\u05DE\u05E9\u05DC: \u05DE\u05D1\u05D7\u05DF \u05E4\u05E8\u05E7 3)", value: newLabel, onChange: function (e) { return setNewLabel(e.target.value); }, onKeyDown: function (e) { return e.key === "Enter" && addEntry(selectedSubject); } }),
 React.createElement("input", { style: __assign(__assign({}, inp), { width: "65px", textAlign: "center" }), type: "number", min: "0", max: "100", placeholder: "\u05E6\u05D9\u05D5\u05DF", value: newGrade, onChange: function (e) { return setNewGrade(e.target.value); }, onKeyDown: function (e) { return e.key === "Enter" && addEntry(selectedSubject); } }),
 React.createElement("button", { onClick: function () { return addEntry(selectedSubject); }, style: { background: C.accent, color: "#fff", border: "none", borderRadius: "8px", padding: "0.45rem 0.8rem", cursor: "pointer", fontWeight: 600, fontSize: "0.85rem" } }, "+ \u05D4\u05D5\u05E1\u05E3")),
 React.createElement("div", { style: { maxHeight: "220px", overflowY: "auto" } },
 (!selected.entries || selected.entries.length === 0) && (React.createElement("div", { style: { padding: "1.2rem", textAlign: "center", color: C.muted, fontSize: "0.85rem" } }, "\u05D0\u05D9\u05DF \u05E6\u05D9\u05D5\u05E0\u05D9\u05DD \u05E2\u05D3\u05D9\u05D9\u05DF \u2014 \u05D4\u05D5\u05E1\u05E3 \u05D0\u05EA \u05D4\u05E8\u05D0\u05E9\u05D5\u05DF!")),
 (selected.entries || []).slice().reverse().map(function (e, i, arr) {
 var prev = arr[i + 1];
 var diff = prev ? e.grade - prev.grade : null;
 return (React.createElement("div", { key: e.id, style: { display: "flex", alignItems: "center", padding: "0.55rem 1rem", borderBottom: "1px solid ".concat(C.border, "22"), gap: "0.75rem" } },
 React.createElement("div", { style: { width: "38px", height: "38px", borderRadius: "50%", background: getColor(e.grade) + "22", border: "2px solid ".concat(getColor(e.grade)), display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 } },
 React.createElement("span", { style: { fontWeight: 800, fontSize: "0.85rem", color: getColor(e.grade) } }, e.grade)),
 React.createElement("div", { style: { flex: 1, minWidth: 0 } },
 React.createElement("div", { style: { fontWeight: 600, fontSize: "0.88rem", color: C.text, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" } }, e.label),
 React.createElement("div", { style: { fontSize: "0.73rem", color: C.muted } }, new Date(e.date).toLocaleDateString("he-IL"))),
 diff !== null && (React.createElement("span", { style: { fontSize: "0.78rem", fontWeight: 600, color: diff > 0 ? "#48bb78" : diff < 0 ? "#fc8181" : C.muted } }, diff > 0 ? "+".concat(diff) : diff === 0 ? "—" : diff)),
 React.createElement("button", { onClick: function () { return deleteEntry(selectedSubject, e.id); }, style: { background: "transparent", border: "none", color: C.muted, cursor: "pointer", padding: "0.2rem", fontSize: "0.8rem", opacity: 0.6 } }, "\u2715")));
 })))),
 subjects.length === 0 && !showAddSubject && (React.createElement("div", { style: { textAlign: "center", padding: "2rem", color: C.muted } },
 React.createElement("div", { style: { fontSize: "2rem", marginBottom: "0.5rem" } }, "\uD83D\uDCCA"),
 React.createElement("div", { style: { fontWeight: 600, marginBottom: "0.25rem" } }, "\u05E2\u05E7\u05D5\u05D1 \u05D0\u05D7\u05E8 \u05D4\u05E6\u05D9\u05D5\u05E0\u05D9\u05DD \u05E9\u05DC\u05DA"),
 React.createElement("div", { style: { fontSize: "0.82rem" } }, "\u05D4\u05D5\u05E1\u05E3 \u05DE\u05E7\u05E6\u05D5\u05E2 \u05DB\u05D3\u05D9 \u05DC\u05D4\u05EA\u05D7\u05D9\u05DC")))));
}
function AuthWrap(_a) {
 var children = _a.children;
 return (React.createElement("div", { style: { minHeight: "100vh", background: C.bg, display: "flex", alignItems: "center", justifyContent: "center", padding: "1rem" } },
 React.createElement("div", { style: { width: "100%", maxWidth: "400px", background: C.card, border: "1px solid ".concat(C.border), borderRadius: "20px", padding: "2rem", display: "flex", flexDirection: "column", gap: "1rem" } }, children)));
}
function Login(_a) {
 var onLogin = _a.onLogin, onRegister = _a.onRegister, onForgot = _a.onForgot;
 var _b = React.useState(""), u = _b[0], setU = _b[1];
 var _c = React.useState(""), p = _c[0], setP = _c[1];
 var _d = React.useState(""), err = _d[0], setErr = _d[1];
 var inp = { background: C.card, border: "1px solid ".concat(C.border), color: C.text, padding: "0.7rem 1rem", borderRadius: "8px", fontSize: "0.93rem", width: "100%", outline: "none" };
 var go = function () { var users = ls.get("users") || {}; var found = Object.values(users).find(function (x) { return x.username === u && x.password === p; }); if (found)
 onLogin(found);
 else
 setErr("שם משתמש או סיסמא שגויים"); };
 return (React.createElement(AuthWrap, null,
 React.createElement("div", { style: { fontSize: "2.5rem", textAlign: "center" } }, "\uD83D\uDCDA"),
 React.createElement("h1", { style: { textAlign: "center", fontSize: "1.55rem", fontWeight: 800 } }, "StudyTime"),
 React.createElement("input", { style: inp, placeholder: "\u05E9\u05DD \u05DE\u05E9\u05EA\u05DE\u05E9", value: u, onChange: function (e) { return setU(e.target.value); }, onKeyDown: function (e) { return e.key === "Enter" && go(); } }),
 React.createElement("input", { type: "password", style: inp, placeholder: "\u05E1\u05D9\u05E1\u05DE\u05D0", value: p, onChange: function (e) { return setP(e.target.value); }, onKeyDown: function (e) { return e.key === "Enter" && go(); } }),
 err && React.createElement("div", { style: { color: C.red, fontSize: "0.85rem", textAlign: "center" } }, err),
 React.createElement("button", { onClick: go, style: { background: C.accent, color: "#fff", border: "none", padding: "0.7rem", borderRadius: "8px", fontSize: "0.93rem", fontWeight: 600, cursor: "pointer" } }, "\u05DB\u05E0\u05D9\u05E1\u05D4"),
 React.createElement("div", { style: { display: "flex", gap: "0.5rem", justifyContent: "center", flexWrap: "wrap" } },
 React.createElement("button", { onClick: onRegister, style: { background: "transparent", color: C.accent, border: "none", fontSize: "0.85rem", cursor: "pointer" } }, "\u05D4\u05E8\u05E9\u05DE\u05D4"))));
}
function Register(_a) {
 var onRegister = _a.onRegister, onBack = _a.onBack;
 var _b = React.useState(""), u = _b[0], setU = _b[1];
 var _c = React.useState(""), p = _c[0], setP = _c[1];
 var _d = React.useState(""), p2 = _d[0], setP2 = _d[1];
 var _e = React.useState(""), grade = _e[0], setGrade = _e[1];
 var _f = React.useState(""), err = _f[0], setErr = _f[1];
 var inp = { background: C.card, border: "1px solid ".concat(C.border), color: C.text, padding: "0.7rem 1rem", borderRadius: "8px", fontSize: "0.93rem", width: "100%", outline: "none" };
 var grades = [["ה", 5], ["ו", 6], ["ז", 7], ["ח", 8], ["ט", 9], ["י", 10], ["יא", 11], ["יב", 12]];
 var go = function () {
 if (!u.trim()) {
 setErr("הכנס שם משתמש");
 return;
 }
 if (p.length < 4) {
 setErr("סיסמא חייבת להיות לפחות 4 תווים");
 return;
 }
 if (p !== p2) {
 setErr("הסיסמאות לא תואמות");
 return;
 }
 if (!grade) {
 setErr("בחר כיתה");
 return;
 }
 var users = ls.get("users") || {};
 if (Object.values(users).find(function (x) { return x.username === u; })) {
 setErr("שם משתמש כבר קיים");
 return;
 }
 var nu = { id: genId(), username: u.trim(), password: p, grade: grade[0], gradeNum: grade[1], role: "student", personal: { homework: [], works: [], tests: [], schedule: {} }, classChecks: {}, gradesData: {}, createdAt: Date.now(), lastLogin: Date.now() };
 users[nu.id] = nu;
 ls.set("users", users);
 syncUserToSupabase(nu);
 onRegister(nu);
 };
 return (React.createElement(AuthWrap, null,
 React.createElement("div", { style: { fontSize: "2.5rem", textAlign: "center" } }, "\uD83D\uDCDA"),
 React.createElement("h1", { style: { textAlign: "center", fontSize: "1.55rem", fontWeight: 800 } }, "\u05D4\u05E8\u05E9\u05DE\u05D4"),
 React.createElement("input", { style: inp, placeholder: "\u05E9\u05DD \u05DE\u05E9\u05EA\u05DE\u05E9", value: u, onChange: function (e) { return setU(e.target.value); } }),
 React.createElement("input", { type: "password", style: inp, placeholder: "\u05E1\u05D9\u05E1\u05DE\u05D0", value: p, onChange: function (e) { return setP(e.target.value); } }),
 React.createElement("input", { type: "password", style: inp, placeholder: "\u05D0\u05D9\u05DE\u05D5\u05EA \u05E1\u05D9\u05E1\u05DE\u05D0", value: p2, onChange: function (e) { return setP2(e.target.value); } }),
 React.createElement("div", null,
 React.createElement("div", { style: { fontSize: "0.85rem", color: C.muted, marginBottom: "0.5rem", fontWeight: 600 } }, "\uD83C\uDFEB \u05D1\u05D0\u05D9\u05D6\u05D4 \u05DB\u05D9\u05EA\u05D4 \u05D0\u05EA\u05D4?"),
 React.createElement("div", { style: { display: "flex", flexWrap: "wrap", gap: "0.4rem" } }, grades.map(function (_a) {
 var lbl = _a[0], num = _a[1];
 var active = grade && grade[0] === lbl;
 return (React.createElement("button", { key: lbl, onClick: function () { return setGrade([lbl, num]); }, style: { padding: "0.42rem 0.85rem", borderRadius: "10px", border: "1px solid " + (active ? C.accent : C.border), background: active ? C.accent + "33" : "transparent", color: active ? C.accent : C.muted, fontSize: "0.88rem", fontWeight: active ? 700 : 400, cursor: "pointer" } }, "כיתה " + lbl));
 })),
 grade && React.createElement("div", { style: { fontSize: "0.75rem", color: C.muted, marginTop: "0.4rem" } },
 "\u05DB\u05D9\u05EA\u05D4 ",
 grade[0],
 " \u05E0\u05D1\u05D7\u05E8\u05D4 \u2713")),
 err && React.createElement("div", { style: { color: C.red, fontSize: "0.85rem", textAlign: "center" } }, err),
 React.createElement("button", { onClick: go, style: { background: C.accent, color: "#fff", border: "none", padding: "0.7rem", borderRadius: "8px", fontSize: "0.93rem", fontWeight: 600, cursor: "pointer" } }, "\u05D4\u05D9\u05E8\u05E9\u05DD"),
 React.createElement("button", { onClick: onBack, style: { background: "transparent", color: C.text, border: "1px solid ".concat(C.border), padding: "0.7rem", borderRadius: "8px", fontSize: "0.93rem", cursor: "pointer" } }, "\u05D7\u05D6\u05E8\u05D4")));
}
function ForgotPassword(_a) {
 var onBack = _a.onBack;
 var _b = React.useState(""), u = _b[0], setU = _b[1];
 var _c = React.useState(""), msg = _c[0], setMsg = _c[1];
 var inp = { background: C.card, border: "1px solid ".concat(C.border), color: C.text, padding: "0.7rem 1rem", borderRadius: "8px", fontSize: "0.93rem", width: "100%", outline: "none" };
 var go = function () { var users = ls.get("users") || {}; var found = Object.values(users).find(function (x) { return x.username === u; }); setMsg(found ? "הסיסמא שלך היא: " + found.password : "שם משתמש לא נמצא"); };
 return (React.createElement(AuthWrap, null,
 React.createElement("div", { style: { fontSize: "2.5rem", textAlign: "center" } }, "\uD83D\uDD11"),
 React.createElement("h1", { style: { textAlign: "center", fontSize: "1.55rem", fontWeight: 800 } }, "\u05E9\u05D7\u05D6\u05D5\u05E8 \u05E1\u05D9\u05E1\u05DE\u05D0"),
 React.createElement("input", { style: inp, placeholder: "\u05E9\u05DD \u05DE\u05E9\u05EA\u05DE\u05E9", value: u, onChange: function (e) { return setU(e.target.value); }, onKeyDown: function (e) { return e.key === "Enter" && go(); } }),
 msg && React.createElement("div", { style: { color: msg.includes("לא") ? C.red : C.green, background: msg.includes("לא") ? "#2d1a1a" : "#0d2c1a", padding: "0.5rem 0.9rem", borderRadius: "8px", fontSize: "0.84rem" } }, msg),
 React.createElement("button", { onClick: go, style: { background: C.accent, color: "#fff", border: "none", padding: "0.7rem", borderRadius: "8px", fontSize: "0.93rem", fontWeight: 600, cursor: "pointer" } }, "\u05E9\u05D7\u05D6\u05E8"),
 React.createElement("button", { onClick: onBack, style: { background: "transparent", color: C.text, border: "1px solid ".concat(C.border), padding: "0.7rem", borderRadius: "8px", fontSize: "0.93rem", cursor: "pointer" } }, "\u05D7\u05D6\u05E8\u05D4")));
}
